# Getting Started with Digital Connect API

## Getting Started

### Install the Package

Install the SDK by adding the following dependency in your project's pom.xml file:

```xml
<dependency>
  <groupId>io.apimatic.sabre</groupId>
  <artifactId>digital-connect</artifactId>
  <version>1.0.0</version>
</dependency>
```

You can also view the package at:
https://mvnrepository.com/artifact/io.apimatic.sabre/digital-connect/1.0.0

### Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

| Name | Value | Description |
|  --- | --- | --- |
| default | `ENUM_DEFAULT` | **Default**  |
| mock | `MOCK` |  |

### Initialize the API Client

The following parameters are configurable for the API Client.

| Parameter | Type | Description |
|  --- | --- | --- |
| `storefront` | `String` | Storefront ID<br>*Default*: `"storefront"` |
| `applicationId` | `String` | Application ID<br>*Default*: `"application-id"` |
| `redirectUri` | `String` | Redirect URI<br>*Default*: `"redirect_uri"` |
| `userId` | `String` | EPR (a.k.a. User ID).<br>*Default*: `"user ID"` |
| `group` | `String` | PCC (a.k.a. Group).<br>*Default*: `"group"` |
| `domain` | `String` | Domain ("AA" for Travel Network customers, or your airline code for Airline Solutions customers, e.g. "LA").<br>*Default*: `"domain"` |
| `password` | `String` | Sabre APIs password.<br>*Default*: `"password"` |
| `hostAndPort` | `String` | *Default*: `"api.sabre.com"` |
| `apiContextPath` | `String` | *Default*: `"v4.2"` |
| `authContextPath` | `String` | *Default*: `"/v2/auth/token"` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.ENUM_DEFAULT`** |

The API client can be initialized as following.

```java
DigitalConnectClient client = new DigitalConnectClient.Builder()
    .storefront("storefront")
    .applicationId("application-id")
    .redirectUri("redirect_uri")
    .userId("user ID")
    .group("group")
    .domain("domain")
    .password("password")
    .environment(Environment.ENUM_DEFAULT)
    .hostAndPort("api.sabre.com")
    .apiContextPath("v4.2")
    .authContextPath("/v2/auth/token")
    .build();
```

## API Reference

### Authorization

#### Overview

##### Get instance

An instance of the `AuthorizationController` class can be accessed from the API Client.

```
AuthorizationController authorizationController = client.getAuthorizationController();
```

#### Create Token

Create a new Auth token.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AccessToken> createTokenAsync(
    final String authorization,
    final String redirectUri)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | Authorization header in Basic auth format |
| `redirectUri` | `String` | Header, Required | Redirect URI |

##### Server

`Server.AUTH`

##### Response Type

[`AccessToken`](#access-token)

##### Example Usage

```java
String authorization = "Authorization8";
String redirectUri = "redirect_uri8";

authorizationController.createTokenAsync(authorization, redirectUri).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

##### Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Authentication provider returned an error. | [`OauthProviderException`](#oauth-provider) |
| 401 | Authentication provider says client authentication failed. | [`OauthProviderException`](#oauth-provider) |

### Book Now Pay Later

#### Overview

##### Get instance

An instance of the `BookNowPayLaterController` class can be accessed from the API Client.

```
BookNowPayLaterController bookNowPayLaterController = client.getBookNowPayLaterController();
```

#### Calculate Leftover Amount

Get list of second fop payments for selected first fop

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CombinablePaymentsResult> calculateLeftoverAmountAsync(
    final FirstPayment body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FirstPayment`](#first-payment) | Body, Required | First form of payment |

##### Response Type

[`CombinablePaymentsResult`](#combinable-payments-result)

##### Example Usage

```java
FirstPayment body = new FirstPayment();

bookNowPayLaterController.calculateLeftoverAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Available Ancillaries

Returns available ancillaries.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> getAvailableAncillariesAsync()
```

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
bookNowPayLaterController.getAvailableAncillariesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Fare Rules

Retrieve Fare Rules.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FareRulesResult> getFareRulesAsync()
```

##### Response Type

[`FareRulesResult`](#fare-rules-result)

##### Example Usage

```java
bookNowPayLaterController.getFareRulesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Installments

Used when installment source in payment options service is PAYMENT_PROVIDER.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<InstallmentsResponse> getInstallmentsAsync(
    final InstallmentsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InstallmentsRequest`](#installments-request) | Body, Required | Installments request |

##### Response Type

[`InstallmentsResponse`](#installments-response)

##### Example Usage

```java
InstallmentsRequest body = new InstallmentsRequest();
body.setCardCode("AX");

bookNowPayLaterController.getInstallmentsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Insurance Offers

Get list of Insurance offers available

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<InsuranceOffers> getInsuranceOffersAsync()
```

##### Response Type

[`InsuranceOffers`](#insurance-offers)

##### Example Usage

```java
bookNowPayLaterController.getInsuranceOffersAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Seat Map

Get Seats Map for selected itinerary

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatsResult> getSeatMapAsync()
```

##### Response Type

[`SeatsResult`](#seats-result)

##### Example Usage

```java
bookNowPayLaterController.getSeatMapAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Travel Bank Details

Gets TravelBank account details like: all available funds, maximum amount could be use to pay for the trip and how it can be split between price components. It's required to be log in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TravelBankDetails> getTravelBankDetailsAsync()
```

##### Response Type

[`TravelBankDetails`](#travel-bank-details)

##### Example Usage

```java
bookNowPayLaterController.getTravelBankDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Voucher Balance

Get balance for eVoucher or Gift Card.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<GetBalanceResult> getVoucherBalanceAsync(
    final Voucher body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Voucher`](#voucher) | Body, Required | Voucher with information about voucher type, number and pin or number and expire date. |

##### Response Type

[`GetBalanceResult`](#get-balance-result)

##### Example Usage

```java
Voucher body = new Voucher();

bookNowPayLaterController.getVoucherBalanceAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### PNR Retrieval and BNPL Flow Initialization

Get PNR info and initialize BNPL

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> pNRRetrievalAndBNPLFlowInitializationAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

bookNowPayLaterController.pNRRetrievalAndBNPLFlowInitializationAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Products Price Breakdown

Get price breakdown of all products

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> productsPriceBreakdownAsync()
```

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
bookNowPayLaterController.productsPriceBreakdownAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Purchase Booking

Purchase a booking.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BookingResult> purchaseBookingAsync(
    final PaymentData body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PaymentData`](#payment-data) | Body, Required | Payment data required to purchase a booking. |

##### Response Type

[`BookingResult`](#booking-result)

##### Example Usage

```java
PaymentData body = new PaymentData();

bookNowPayLaterController.purchaseBookingAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Combinability Mapping

Returns combinability mapping. This information will allow to display proper payment methods and allow multiple forms of payment. It also provides information which products are paid separately so we can provide more flexibility to a user.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentCombinability> returnCombinabilityMappingAsync()
```

##### Response Type

[`PaymentCombinability`](#payment-combinability)

##### Example Usage

```java
bookNowPayLaterController.returnCombinabilityMappingAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Search for Ancillaries

Searches for ancillaries using provided context.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> searchForAncillariesAsync(
    final List<Object> promoSSRs,
    final AncillarySearchContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Searches for ancillaries using provided context. |
| `body` | [`AncillarySearchContext`](#ancillary-search-context) | Body, Optional | - |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
bookNowPayLaterController.searchForAncillariesAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Insurance

Select insurance offer using insurance productID

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SelectedInsurance> selectInsuranceAsync(
    final SelectInsuranceRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SelectInsuranceRequest`](#select-insurance-request) | Body, Optional | - |

##### Response Type

[`SelectedInsurance`](#selected-insurance)

##### Example Usage

```java
bookNowPayLaterController.selectInsuranceAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Seats

Selects seats for passengers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatRequestResult> selectSeatsAsync(
    final SeatRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SeatRequest`](#seat-request) | Body, Required | Select seat request |

##### Response Type

[`SeatRequestResult`](#seat-request-result)

##### Example Usage

```java
SeatRequest body = new SeatRequest();

bookNowPayLaterController.selectSeatsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Ancillaries

update ancillaries

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillaryRequestResult> updateAncillariesAsync(
    final AncillaryRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AncillaryRequest`](#ancillary-request) | Body, Required | update ancillary |

##### Response Type

[`AncillaryRequestResult`](#ancillary-request-result)

##### Example Usage

```java
AncillaryRequest body = new AncillaryRequest();

bookNowPayLaterController.updateAncillariesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Cancel and Refund

#### Overview

##### Get instance

An instance of the `CancelAndRefundController` class can be accessed from the API Client.

```
CancelAndRefundController cancelAndRefundController = client.getCancelAndRefundController();
```

#### Cancel and Refund Flow Initializataion

Get PNR info and initialize cancel

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> cancelAndRefundFlowInitializataionAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

cancelAndRefundController.cancelAndRefundFlowInitializataionAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Cancel PNR and Get Refund Information

Cancel PNR before confirmation

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CancellationResult> cancelPNRAndGetRefundInformationAsync(
    final String waiverCode,
    final String preferredRefundTarget,
    final Boolean shouldRefundEmd)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `waiverCode` | `String` | Query, Optional | Code used to waive reservation cancel fee. |
| `preferredRefundTarget` | `String` | Query, Optional | Preferred refund target type. |
| `shouldRefundEmd` | `Boolean` | Query, Optional | Flag indicating if EMDs should be refunded. |

##### Response Type

[`CancellationResult`](#cancellation-result)

##### Example Usage

```java
String waiverCode = "waiverCode=01";
String preferredRefundTarget = "preferredRefundTarget=TRAVELBANK";

cancelAndRefundController.cancelPNRAndGetRefundInformationAsync(waiverCode, preferredRefundTarget, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Confirm Cancel PNR

User confirms cancellation. Include travel bank login details if required. Proceed with cancellation and refund if applicable.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CancellationConfirmResult> confirmCancelPNRAsync(
    final CancellationConfirmationData body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CancellationConfirmationData`](#cancellation-confirmation-data) | Body, Required | Proceed with cancellation and refund |

##### Response Type

[`CancellationConfirmResult`](#cancellation-confirm-result)

##### Example Usage

```java
CancellationConfirmationData body = new CancellationConfirmationData();
body.setConfirmed(false);

cancelAndRefundController.confirmCancelPNRAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Cancel Upgrade

#### Overview

##### Get instance

An instance of the `CancelUpgradeController` class can be accessed from the API Client.

```
CancelUpgradeController cancelUpgradeController = client.getCancelUpgradeController();
```

#### Cancel Upgrade Initialization

Get PNR info for PNR cancel upgrade flow.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> cancelUpgradeInitializationAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

cancelUpgradeController.cancelUpgradeInitializationAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Cancel Upgrade Offers

Get cancel upgrade offers.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CancelUpgradeOffersResult> cancelUpgradeOffersAsync()
```

##### Response Type

[`CancelUpgradeOffersResult`](#cancel-upgrade-offers-result)

##### Example Usage

```java
cancelUpgradeController.cancelUpgradeOffersAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Products Price Breakdown

Get breakdown of selected cancel upgrade offers.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> productsPriceBreakdownAsync()
```

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
cancelUpgradeController.productsPriceBreakdownAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Cancel Upgrade Offer Selection

Update cancel upgrade offer selection.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CancelUpgradeOfferRequestResult> updateCancelUpgradeOfferSelectionAsync(
    final CancelUpgradeOfferRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CancelUpgradeOfferRequest`](#cancel-upgrade-offer-request) | Body, Required | Update cancel upgrade offers selection. |

##### Response Type

[`CancelUpgradeOfferRequestResult`](#cancel-upgrade-offer-request-result)

##### Example Usage

```java
CancelUpgradeOfferRequest body = new CancelUpgradeOfferRequest();

cancelUpgradeController.updateCancelUpgradeOfferSelectionAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Cars

#### Overview

##### Get instance

An instance of the `CarsController` class can be accessed from the API Client.

```
CarsController carsController = client.getCarsController();
```

#### Book Car

Performs the car booking for the available offer in a JSON format. The response contains the confirmation message and booked car details.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CarReservationResponse> bookCarAsync(
    final CarReservationRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CarReservationRequest`](#car-reservation-request) | Body, Required | JSON request with the selected available car details, driver details, etc. |

##### Response Type

[`CarReservationResponse`](#car-reservation-response)

##### Example Usage

```java
CarReservationRequest body = new CarReservationRequest();
body.setPnr("QQAPRG");
body.setPickUpLocation(new CarDepotLocation());
body.getPickUpLocation().setName("Jersey - Airport");
body.setDropOffLocation(new CarDepotLocation());
body.getDropOffLocation().setName("Jersey - Airport");
body.setPickUpDateTime(LocalDateTime.parse("2016-06-30T05:55:00", DateTimeFormatter.ISO_DATE_TIME));
body.setDropOffDateTime(LocalDateTime.parse("2016-06-30T05:55:00", DateTimeFormatter.ISO_DATE_TIME));
body.setDriversInfo(new DriversInfo());
body.setPricedCar(new PricedCar());

carsController.bookCarAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Car Location Search

Performs a search of car locations with the search criteria in a JSON format. The response contains a list of car locations.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CarLocationSearchResult> carLocationSearchAsync(
    final CarLocationSearch body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CarLocationSearch`](#car-location-search-1) | Body, Required | JSON request with the car location search criteria. |

##### Response Type

[`CarLocationSearchResult`](#car-location-search-result)

##### Example Usage

```java
CarLocationSearch body = new CarLocationSearch();
body.setItineraryOrigin("AUH");

carsController.carLocationSearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Car Search

Perform a search of car availability with the search criteria in a JSON format. The response contains a list of available car details with fare offerings.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CarAvailabilitySearchResponse> carSearchAsync(
    final CarAvailabilitySearch body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CarAvailabilitySearch`](#car-availability-search) | Body, Required | JSON request with car availability search criteria |

##### Response Type

[`CarAvailabilitySearchResponse`](#car-availability-search-response)

##### Example Usage

```java
CarAvailabilitySearch body = new CarAvailabilitySearch();
body.setItineraryOrigin("AUH");
body.setPickUpDetail(new CarRentalLocation());
body.setDropOffDetail(new CarRentalLocation());
body.setDriversInfo(new DriversInfo());

carsController.carSearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Change Itinerary

#### Overview

##### Get instance

An instance of the `ChangeItineraryController` class can be accessed from the API Client.

```
ChangeItineraryController changeItineraryController = client.getChangeItineraryController();
```

#### Calculate Leftover Amount

Get list of second fop payments for selected first fop

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CombinablePaymentsResult> calculateLeftoverAmountAsync(
    final FirstPayment body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FirstPayment`](#first-payment) | Body, Required | First form of payment |

##### Response Type

[`CombinablePaymentsResult`](#combinable-payments-result)

##### Example Usage

```java
FirstPayment body = new FirstPayment();

changeItineraryController.calculateLeftoverAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Change Passenger Information

Change passengers data.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PassengerUpdateResponse> changePassengerInformationAsync(
    final Passengers body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Passengers`](#passengers) | Body, Required | JSON request with passengers data |

##### Response Type

[`PassengerUpdateResponse`](#passenger-update-response)

##### Example Usage

```java
Passengers body = new Passengers();

changeItineraryController.changePassengerInformationAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Change Trip Contact Details

Change TripContactInfo data during MYB Exchange flow.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> changeTripContactDetailsAsync(
    final TripContactInfo body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`TripContactInfo`](#trip-contact-info) | Body, Optional | - |

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
changeItineraryController.changeTripContactDetailsAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Exchange Initialization

Get PNR info and initialize exchange

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Pnr> exchangeInitializationAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`Pnr`](#pnr)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

changeItineraryController.exchangeInitializationAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Fare Rules

Retrieve Fare Rules.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FareRulesResult> fareRulesAsync()
```

##### Response Type

[`FareRulesResult`](#fare-rules-result)

##### Example Usage

```java
changeItineraryController.fareRulesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Flight Search

Perform an exchange search of itineraries with the search criteria in a JSON format. The response contains a list of itineraries with fare offerings and detailed price breakdown.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AirSearchResults> flightSearchAsync(
    final AirSearchExchange body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AirSearchExchange`](#air-search-exchange) | Body, Required | JSON request with exchange search criteria. |

##### Response Type

[`AirSearchResults`](#air-search-results)

##### Example Usage

```java
AirSearchExchange body = new AirSearchExchange();
body.setSearchCriteria(new AirSearch());
body.getSearchCriteria().setCabinClass(CabinClass2.BUSINESS);
body.setExchangeType(ExchangeType.SEGMENT);

changeItineraryController.flightSearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Available Ancillaries

Returns available ancillaries.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> getAvailableAncillariesAsync(
    final List<Object> promoSSRs)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Returns available ancillaries. |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
changeItineraryController.getAvailableAncillariesAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Award Details

Gets Award payment details like: minimum and maximum amount of award points could be use to pay for the trip and how it can be split between price components. It's required to be log in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> getAwardDetailsAsync()
```

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
changeItineraryController.getAwardDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Baggage Allowance

Returns Baggage results.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BaggageDisclosure> getBaggageAllowanceAsync()
```

##### Response Type

[`BaggageDisclosure`](#baggage-disclosure)

##### Example Usage

```java
changeItineraryController.getBaggageAllowanceAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Dynamic Currency Offers

Used when the currency of the booking is different than the currency on which the passenger's credit card is based. It checks if the Credit Card is eligible for the Dynamic Currency Conversion (DCC), informs the Payment Web Service that the Digital Connect requests for the dynamic currency conversion offers and retrieves possible DCC (Dynamic Currency Conversion) offers.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<DCCOfferResponse> getDynamicCurrencyOffersAsync(
    final GetDCCOffer body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetDCCOffer`](#get-dcc-offer) | Body, Required | Selected Offer |

##### Response Type

[`DCCOfferResponse`](#dcc-offer-response)

##### Example Usage

```java
GetDCCOffer body = new GetDCCOffer();
body.setCardNumber("111111111115550");
body.setCardCode("AX");
body.setAmount(new Amount());

changeItineraryController.getDynamicCurrencyOffersAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Installments

Used when installment source in payment options service is PAYMENT_PROVIDER

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<InstallmentsResponse> getInstallmentsAsync(
    final InstallmentsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InstallmentsRequest`](#installments-request) | Body, Required | Installments request |

##### Response Type

[`InstallmentsResponse`](#installments-response)

##### Example Usage

```java
InstallmentsRequest body = new InstallmentsRequest();
body.setCardCode("AX");

changeItineraryController.getInstallmentsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Seat Map

Returns Seat Map for selected itinerary.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatsResult> getSeatMapAsync(
    final List<Object> promoSSRs)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Returns Seat Map for selected itinerary. |

##### Response Type

[`SeatsResult`](#seats-result)

##### Example Usage

```java
changeItineraryController.getSeatMapAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Travel Bank Details

Gets TravelBank account details like: all available funds, maximum amount could be use to pay for the trip and how it can be split between price components. It's required to be log in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TravelBankDetails> getTravelBankDetailsAsync()
```

##### Response Type

[`TravelBankDetails`](#travel-bank-details)

##### Example Usage

```java
changeItineraryController.getTravelBankDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Voucher Balance

Get balance for eVoucher or Gift Card.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<GetBalanceResult> getVoucherBalanceAsync(
    final Voucher body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Voucher`](#voucher) | Body, Required | Voucher with information about voucher type, number and pin or number and expire date. |

##### Response Type

[`GetBalanceResult`](#get-balance-result)

##### Example Usage

```java
Voucher body = new Voucher();

changeItineraryController.getVoucherBalanceAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Products Price Breakdown

Get prices breakdown of all products for exchange

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ExchangeBreakdownResponse> productsPriceBreakdownAsync()
```

##### Response Type

[`ExchangeBreakdownResponse`](#exchange-breakdown-response)

##### Example Usage

```java
changeItineraryController.productsPriceBreakdownAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Purchase Booking

Purchase an exchanged booking.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BookingResult> purchaseBookingAsync(
    final PaymentData body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PaymentData`](#payment-data) | Body, Required | Payment data to purchase an exchanged booking. |

##### Response Type

[`BookingResult`](#booking-result)

##### Example Usage

```java
PaymentData body = new PaymentData();

changeItineraryController.purchaseBookingAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Recalculate Product Prices

Recalculates products data based on given context

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ExchangeBreakdownResponse> recalculateProductPricesAsync(
    final ProductsContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductsContext`](#products-context) | Body, Required | Context for products |

##### Response Type

[`ExchangeBreakdownResponse`](#exchange-breakdown-response)

##### Example Usage

```java
ProductsContext body = new ProductsContext();

changeItineraryController.recalculateProductPricesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Combinability Mapping

Returns combinability mapping. This information will allow to display proper payment methods and allow multiple forms of payment. It also provides information which products are paid separatelly so we can provide mor flexibility to a user.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentCombinability> returnCombinabilityMappingAsync()
```

##### Response Type

[`PaymentCombinability`](#payment-combinability)

##### Example Usage

```java
changeItineraryController.returnCombinabilityMappingAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Search for Ancillaries

Searches for ancillaries using provided context.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> searchForAncillariesAsync(
    final List<Object> promoSSRs,
    final AncillarySearchContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Searches for ancillaries using provided context. |
| `body` | [`AncillarySearchContext`](#ancillary-search-context) | Body, Optional | - |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
changeItineraryController.searchForAncillariesAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Seat Map Preview

Seats Preview for a selected itinerary.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PreviewSeatsResult> seatMapPreviewAsync(
    final int selectFlight)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selectFlight` | `int` | Query, Required | Query parameter should be a valid basket hash value of selected flight. |

##### Response Type

[`PreviewSeatsResult`](#preview-seats-result)

##### Example Usage

```java
int selectFlight = -352284291;

changeItineraryController.seatMapPreviewAsync(selectFlight).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Flights

Selects itinerary offers for exchange

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ItineraryResult> selectFlightsAsync(
    final List<Object> selectFlights,
    final String waiverCode)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selectFlights` | `List<Object>` | Query, Required | Itinerary selected for the exchange. |
| `waiverCode` | `String` | Query, Required | Itinerary selected for the exchange. |

##### Response Type

[`ItineraryResult`](#itinerary-result)

##### Example Usage

```java
List<Object> selectFlights = new LinkedList<>();
selectFlights.add(com.sabre.digitalconnect.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"));
selectFlights.add(com.sabre.digitalconnect.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"));
selectFlights.add(com.sabre.digitalconnect.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"));
String waiverCode = "waiverCode=01";

changeItineraryController.selectFlightsAsync(selectFlights, waiverCode).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Seats

Select or exchange seats for passengers.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatRequestResult> selectSeatsAsync(
    final SeatRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SeatRequest`](#seat-request) | Body, Required | Select seat request. |

##### Response Type

[`SeatRequestResult`](#seat-request-result)

##### Example Usage

```java
SeatRequest body = new SeatRequest();

changeItineraryController.selectSeatsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Set Award Amount

Set payment award selection

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> setAwardAmountAsync(
    final AwardDetailsSelection body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AwardDetailsSelection`](#award-details-selection) | Body, Required | Award selection |

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
AwardDetailsSelection body = new AwardDetailsSelection();

changeItineraryController.setAwardAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Trip Contact Information

Returns Trip Contact Info details.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> tripContactInformationAsync()
```

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
changeItineraryController.tripContactInformationAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Ancillaries

update ancillaries

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillaryRequestResult> updateAncillariesAsync(
    final AncillaryRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AncillaryRequest`](#ancillary-request) | Body, Required | update ancillary |

##### Response Type

[`AncillaryRequestResult`](#ancillary-request-result)

##### Example Usage

```java
AncillaryRequest body = new AncillaryRequest();

changeItineraryController.updateAncillariesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Change Passenger Details

#### Overview

##### Get instance

An instance of the `ChangePassengerDetailsController` class can be accessed from the API Client.

```
ChangePassengerDetailsController changePassengerDetailsController = client.getChangePassengerDetailsController();
```

#### Change Passenger Information

Change passengers data during MYB flow.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PassengerChangeResponse> changePassengerInformationAsync(
    final String pnr,
    final Passengers body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Required | Indicator of passengers details changes in the reservation (PNR). |
| `body` | [`Passengers`](#passengers) | Body, Optional | - |

##### Response Type

[`PassengerChangeResponse`](#passenger-change-response)

##### Example Usage

```java
String pnr = "LVBIEL";

changePassengerDetailsController.changePassengerInformationAsync(pnr, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Change Trip Contact Details

Change TripContactInfo data during MYB Change Pax flow.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> changeTripContactDetailsAsync(
    final String pnr,
    final TripContactInfo body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Required | Indicator of trip contact details changes in the reservation (PNR). |
| `body` | [`TripContactInfo`](#trip-contact-info) | Body, Optional | - |

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
String pnr = "LVBIEL";

changePassengerDetailsController.changeTripContactDetailsAsync(pnr, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Configuration

#### Overview

##### Get instance

An instance of the `ConfigurationController` class can be accessed from the API Client.

```
ConfigurationController configurationController = client.getConfigurationController();
```

#### Basic Build Information

Returns basic build information

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BuildInformation> basicBuildInformationAsync()
```

##### Response Type

[`BuildInformation`](#build-information)

##### Example Usage

```java
configurationController.basicBuildInformationAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Configuration Rules

Returns information about rules applied to the service.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<RulesEvaluationResult> configurationRulesAsync(
    final String path,
    final HttpMethod httpMethod)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path` | `String` | Query, Optional | The path name for which you want to check rules (send the rules retrieval request). |
| `httpMethod` | [`HttpMethod`](#http-method) | Query, Optional | The HTTP method for which you want to check rules (send the rules retrieval request). |

##### Response Type

[`RulesEvaluationResult`](#rules-evaluation-result)

##### Example Usage

```java
String path = "path=/pnr";

configurationController.configurationRulesAsync(path, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Configuration Validation

Returns information about basic contract validation

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ResourceConfigurationDefinition> configurationValidationAsync(
    final String path,
    final HttpMethod httpMethod,
    final ConfigurationType configurationType)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path` | `String` | Query, Optional | The path name for which you want to check validation (send the validation request). |
| `httpMethod` | [`HttpMethod`](#http-method) | Query, Optional | The HTTP method for which you want to check validation (send the validation request). |
| `configurationType` | [`ConfigurationType`](#configuration-type) | Query, Optional | Type of the application validation that will be returned - default or configured. |

##### Response Type

[`ResourceConfigurationDefinition`](#resource-configuration-definition)

##### Example Usage

```java
String path = "path=/pnr";

configurationController.configurationValidationAsync(path, null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Configurations for Storefront

return all enabled services, routes etc

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ConfigurationServiceResult> configurationsForStorefrontAsync()
```

##### Response Type

[`ConfigurationServiceResult`](#configuration-service-result)

##### Example Usage

```java
configurationController.configurationsForStorefrontAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Irregular Operations

#### Overview

##### Get instance

An instance of the `IrregularOperationsController` class can be accessed from the API Client.

```
IrregularOperationsController irregularOperationsController = client.getIrregularOperationsController();
```

#### Offload Passenger

Offload - an action that changes VCR status from CKIN to OK, in order to give passengers an option to initiate an exchange or refund process, when the originally booked and checked in flight is under IROP situation (e.g. flight is cancelled or delayed).

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<OffLoadPassengerResponse> offloadPassengerAsync(
    final OffLoadPassengerRequest body,
    final String pnr)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`OffLoadPassengerRequest`](#off-load-passenger-request) | Body, Required | First flight segment that is being Offloaded. |
| `pnr` | `String` | Query, Required | Reservation code (PNR) for Offload. |

##### Response Type

[`OffLoadPassengerResponse`](#off-load-passenger-response)

##### Example Usage

```java
OffLoadPassengerRequest body = new OffLoadPassengerRequest();
String pnr = "CHIUWC";

irregularOperationsController.offloadPassengerAsync(body, pnr).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### PNR With SC or WK Status

Accept segments with SC status

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<IropResponse> pNRWithSCOrWKStatusAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`IropResponse`](#irop-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

irregularOperationsController.pNRWithSCOrWKStatusAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Manage Passenger Profile

#### Overview

##### Get instance

An instance of the `ManagePassengerProfileController` class can be accessed from the API Client.

```
ManagePassengerProfileController managePassengerProfileController = client.getManagePassengerProfileController();
```

#### Create Profile

Create a user profile

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CreateProfileResponse> createProfileAsync(
    final CreateProfileRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateProfileRequest`](#create-profile-request) | Body, Required | Profile data required to create a new user profile |

##### Response Type

[`CreateProfileResponse`](#create-profile-response)

##### Example Usage

```java
CreateProfileRequest body = new CreateProfileRequest();

managePassengerProfileController.createProfileAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Profile - Reset Password

Resets the password, valid change key must be present

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ResetPasswordResponse> profileResetPasswordAsync(
    final ResetPasswordRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ResetPasswordRequest`](#reset-password-request) | Body, Required | New password and change key required to update the password |

##### Response Type

[`ResetPasswordResponse`](#reset-password-response)

##### Example Usage

```java
ResetPasswordRequest body = new ResetPasswordRequest();

managePassengerProfileController.profileResetPasswordAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Profile - Reset Password Key

Requests for a change password key to be sent to the user's email

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ResetPasswordResponse> profileResetPasswordKeyAsync(
    final ResetPasswordKeyRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ResetPasswordKeyRequest`](#reset-password-key-request) | Body, Required | username required to retrieve the profile |

##### Response Type

[`ResetPasswordResponse`](#reset-password-response)

##### Example Usage

```java
ResetPasswordKeyRequest body = new ResetPasswordKeyRequest();

managePassengerProfileController.profileResetPasswordKeyAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve My Trips

Returns list of trips associated with a profile or logged in user

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<MyTripResponse> retrieveMyTripsAsync()
```

##### Response Type

[`MyTripResponse`](#my-trip-response)

##### Example Usage

```java
managePassengerProfileController.retrieveMyTripsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve Profile

Retrieve logged in user profile

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<RetrieveProfileResponse> retrieveProfileAsync()
```

##### Response Type

[`RetrieveProfileResponse`](#retrieve-profile-response)

##### Example Usage

```java
managePassengerProfileController.retrieveProfileAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Profile

Update an existing user profile

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpdateProfileResponse> updateProfileAsync(
    final UpdateProfileRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`UpdateProfileRequest`](#update-profile-request) | Body, Required | Profile data required to update an existing user profile |

##### Response Type

[`UpdateProfileResponse`](#update-profile-response)

##### Example Usage

```java
UpdateProfileRequest body = new UpdateProfileRequest();

managePassengerProfileController.updateProfileAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Modify Trip Options

#### Overview

##### Get instance

An instance of the `ModifyTripOptionsController` class can be accessed from the API Client.

```
ModifyTripOptionsController modifyTripOptionsController = client.getModifyTripOptionsController();
```

#### Add External Products to Cart

Adds external product to the cart.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> addExternalProductsToCartAsync(
    final AddExternalProductsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AddExternalProductsRequest`](#add-external-products-request) | Body, Required | JSON request with external product breakdown information. |

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
AddExternalProductsRequest body = new AddExternalProductsRequest();

modifyTripOptionsController.addExternalProductsToCartAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Calculate Leftover Amount

Get list of second fop payments for the selected first fop

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CombinablePaymentsResult> calculateLeftoverAmountAsync(
    final FirstPayment body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FirstPayment`](#first-payment) | Body, Required | First form of payment |

##### Response Type

[`CombinablePaymentsResult`](#combinable-payments-result)

##### Example Usage

```java
FirstPayment body = new FirstPayment();

modifyTripOptionsController.calculateLeftoverAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Change Trip Contact Details

Change TripContactInfo data during MYB MTO flow.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> changeTripContactDetailsAsync(
    final TripContactInfo body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`TripContactInfo`](#trip-contact-info) | Body, Optional | - |

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
modifyTripOptionsController.changeTripContactDetailsAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Available Ancillaries

Returns available ancillaries for the selected itinerary.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> getAvailableAncillariesAsync(
    final List<Object> promoSSRs)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Returns available ancillaries for the selected itinerary. |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
modifyTripOptionsController.getAvailableAncillariesAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Award Details

Returns list of toggles available in MTO flow. Fare slider is not applicable to MTO. Context for products needs to be set to POINTS.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> getAwardDetailsAsync()
```

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
modifyTripOptionsController.getAwardDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Baggage Allowance

Returns Baggage results.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BaggageDisclosure> getBaggageAllowanceAsync()
```

##### Response Type

[`BaggageDisclosure`](#baggage-disclosure)

##### Example Usage

```java
modifyTripOptionsController.getBaggageAllowanceAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Fare Rules

Retrieve Fare Rules.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FareRulesResult> getFareRulesAsync()
```

##### Response Type

[`FareRulesResult`](#fare-rules-result)

##### Example Usage

```java
modifyTripOptionsController.getFareRulesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Installments

Used when installment source in payment options service is PAYMENT_PROVIDER.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<InstallmentsResponse> getInstallmentsAsync(
    final InstallmentsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InstallmentsRequest`](#installments-request) | Body, Required | Installments request |

##### Response Type

[`InstallmentsResponse`](#installments-response)

##### Example Usage

```java
InstallmentsRequest body = new InstallmentsRequest();
body.setCardCode("AX");

modifyTripOptionsController.getInstallmentsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Seat Map

Returns Seat Map for selected itinerary.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatsResult> getSeatMapAsync(
    final List<Object> promoSSRs)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Returns Seat Map for selected itinerary. |

##### Response Type

[`SeatsResult`](#seats-result)

##### Example Usage

```java
modifyTripOptionsController.getSeatMapAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Travel Bank Details

Gets TravelBank account details like: all available funds, maximum amount could be use to pay for the trip and how it can be split between price components. It's required to be log in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TravelBankDetails> getTravelBankDetailsAsync()
```

##### Response Type

[`TravelBankDetails`](#travel-bank-details)

##### Example Usage

```java
modifyTripOptionsController.getTravelBankDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Voucher Balance

Get balance for eVoucher or Gift Card.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<GetBalanceResult> getVoucherBalanceAsync(
    final Voucher body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Voucher`](#voucher) | Body, Required | Voucher with information about voucher type, number and pin or number and expire date. |

##### Response Type

[`GetBalanceResult`](#get-balance-result)

##### Example Usage

```java
Voucher body = new Voucher();

modifyTripOptionsController.getVoucherBalanceAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Products Price Breakdown

Get prices breakdown of all products

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> productsPriceBreakdownAsync()
```

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
modifyTripOptionsController.productsPriceBreakdownAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Purchase Booking

purchase a booking update

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BookingResult> purchaseBookingAsync(
    final PaymentData body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PaymentData`](#payment-data) | Body, Optional | Payment data required to update a booking. |

##### Response Type

[`BookingResult`](#booking-result)

##### Example Usage

```java
modifyTripOptionsController.purchaseBookingAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Recalculate Product Prices

Recalculates products data based on given context

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> recalculateProductPricesAsync(
    final ProductsContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductsContext`](#products-context) | Body, Required | Context for products |

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
ProductsContext body = new ProductsContext();

modifyTripOptionsController.recalculateProductPricesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Remove External Products

Removes an external product from the cart.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> removeExternalProductsAsync(
    final RemoveExternalProductRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RemoveExternalProductRequest`](#remove-external-product-request) | Body, Required | JSON request with external product details. |

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
RemoveExternalProductRequest body = new RemoveExternalProductRequest();

modifyTripOptionsController.removeExternalProductsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve PNR for Ancillaries Flow

Get PNR info. for mto ancillaries flow

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> retrievePNRForAncillariesFlowAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

modifyTripOptionsController.retrievePNRForAncillariesFlowAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve PNR for Seats Flow

Get PNR info. for mto seats flow

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> retrievePNRForSeatsFlowAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

modifyTripOptionsController.retrievePNRForSeatsFlowAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Combinability Mapping

Returns combinability mapping. This information will allow to display proper payment methods and allow multiple forms of payment. It also provides information which products are paid separatelly so we can provide more flexibility to a user. Query parameter 'by' recieves combinabilityType, accepted values = product, payment

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentCombinability> returnCombinabilityMappingAsync()
```

##### Response Type

[`PaymentCombinability`](#payment-combinability)

##### Example Usage

```java
modifyTripOptionsController.returnCombinabilityMappingAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Search for Ancillaries

Searches for ancillaries using provided context.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> searchForAncillariesAsync(
    final List<Object> promoSSRs,
    final AncillarySearchContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Searches for ancillaries using provided context. |
| `body` | [`AncillarySearchContext`](#ancillary-search-context) | Body, Optional | - |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
modifyTripOptionsController.searchForAncillariesAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Seats

Selects seats for passengers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatRequestResult> selectSeatsAsync(
    final SeatRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SeatRequest`](#seat-request) | Body, Required | Select seat request. |

##### Response Type

[`SeatRequestResult`](#seat-request-result)

##### Example Usage

```java
SeatRequest body = new SeatRequest();

modifyTripOptionsController.selectSeatsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Set Award Amount

Select toggle options for ancillaries and seats. Returns current toggle selection. Setting fare slider position is not applicable to MTO.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> setAwardAmountAsync(
    final AwardDetailsSelection body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AwardDetailsSelection`](#award-details-selection) | Body, Required | Award selection |

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
AwardDetailsSelection body = new AwardDetailsSelection();

modifyTripOptionsController.setAwardAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Trip Contact Information

Returns Trip Contact Info details.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> tripContactInformationAsync()
```

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
modifyTripOptionsController.tripContactInformationAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Ancillaries

update ancillaries

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillaryRequestResult> updateAncillariesAsync(
    final AncillaryRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AncillaryRequest`](#ancillary-request) | Body, Required | update ancillary |

##### Response Type

[`AncillaryRequestResult`](#ancillary-request-result)

##### Example Usage

```java
AncillaryRequest body = new AncillaryRequest();

modifyTripOptionsController.updateAncillariesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Pnr Cancel Upgrade

#### Overview

##### Get instance

An instance of the `PnrCancelUpgradeController` class can be accessed from the API Client.

```
PnrCancelUpgradeController pnrCancelUpgradeController = client.getPnrCancelUpgradeController();
```

#### Confirm Cancel Upgrade

Confirm upgrade cancellation.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CancelUpgradeResult> confirmCancelUpgradeAsync()
```

##### Response Type

[`CancelUpgradeResult`](#cancel-upgrade-result)

##### Example Usage

```java
pnrCancelUpgradeController.confirmCancelUpgradeAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Retrieve PNR

#### Overview

##### Get instance

An instance of the `RetrievePNRController` class can be accessed from the API Client.

```
RetrievePNRController retrievePNRController = client.getRetrievePNRController();
```

#### Retrieve PNR

Get PNR info.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> retrievePNRAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

retrievePNRController.retrievePNRAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Shopping

#### Overview

##### Get instance

An instance of the `ShoppingController` class can be accessed from the API Client.

```
ShoppingController shoppingController = client.getShoppingController();
```

#### Add External Products

To add an external product to the cart

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> addExternalProductsAsync(
    final AddExternalProductsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AddExternalProductsRequest`](#add-external-products-request) | Body, Required | JSON request with external product breakdown information |

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
AddExternalProductsRequest body = new AddExternalProductsRequest();

shoppingController.addExternalProductsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Associate OB Fees Type R

Adds or removes Requested OBFees per passenger.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<OBFeeTypeRUpdateResponse> associateOBFeesTypeRAsync(
    final ObFeesTypeRChangeRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ObFeesTypeRChangeRequest`](#ob-fees-type-r-change-request) | Body, Required | JSON request with OBFee Type R data |

##### Response Type

[`OBFeeTypeRUpdateResponse`](#ob-fee-type-r-update-response)

##### Example Usage

```java
ObFeesTypeRChangeRequest body = new ObFeesTypeRChangeRequest();

shoppingController.associateOBFeesTypeRAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Calculate Leftover Amount

Get list of second fop payments for selected first fop

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CombinablePaymentsResult> calculateLeftoverAmountAsync(
    final FirstPayment body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FirstPayment`](#first-payment) | Body, Required | First form of payment |

##### Response Type

[`CombinablePaymentsResult`](#combinable-payments-result)

##### Example Usage

```java
FirstPayment body = new FirstPayment();

shoppingController.calculateLeftoverAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Change Passeger Information

Change passengers list.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PassengerUpdateResponse> changePassegerInformationAsync(
    final Passengers body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Passengers`](#passengers) | Body, Required | JSON request with passengers data |

##### Response Type

[`PassengerUpdateResponse`](#passenger-update-response)

##### Example Usage

```java
Passengers body = new Passengers();

shoppingController.changePassegerInformationAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Change Trip Contact Details

To add Trip Contact Info .

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> changeTripContactDetailsAsync(
    final TripContactInfo body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`TripContactInfo`](#trip-contact-info) | Body, Required | JSON request with Trip Contact Info data |

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
TripContactInfo body = new TripContactInfo();
body.setTripContactInfoType(TripContactInfoType.PRIVATE);

shoppingController.changeTripContactDetailsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Flight Details

Returns a list of selected legs.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ItineraryResult> flightDetailsAsync()
```

##### Response Type

[`ItineraryResult`](#itinerary-result)

##### Example Usage

```java
shoppingController.flightDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Flight Schedules

Flight schedule result

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FlightScheduleResult> flightSchedulesAsync(
    final String origin,
    final String destination,
    final RequestType requestType,
    final String departureDate)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `origin` | `String` | Query, Required | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `destination` | `String` | Query, Required | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `requestType` | [`RequestType`](#request-type) | Query, Optional | Flight schedule request type. Schedules for a day or week. |
| `departureDate` | `String` | Query, Optional | Specific scheduled departure date in the format: YYYY-MM-DD. |

##### Response Type

[`FlightScheduleResult`](#flight-schedule-result)

##### Example Usage

```java
String origin = "DFW";
String destination = "LAX";
String departureDate = "2017-01-20";

shoppingController.flightSchedulesAsync(origin, destination, null, departureDate).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Flight Search

Perform a search of itineraries with the search criteria in a JSON format. The response contains a list of itineraries with fare offerings and detailed price breakdown.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AirSearchResults> flightSearchAsync(
    final AirSearch body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AirSearch`](#air-search) | Body, Required | JSON request with search criteria |

##### Response Type

[`AirSearchResults`](#air-search-results)

##### Example Usage

```java
AirSearch body = new AirSearch();
body.setCabinClass(CabinClass2.ECONOMY);

shoppingController.flightSearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Flight Status

Flight status result

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FlightStatusResult> flightStatusAsync(
    final int flightNumber,
    final String departureDate,
    final String airlineCode,
    final String origin,
    final String destination)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `flightNumber` | `int` | Query, Required | Flight number. |
| `departureDate` | `String` | Query, Required | Specific scheduled departure date in the format: YYYY-MM-DD. |
| `airlineCode` | `String` | Query, Required | Marketing airline two letter code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). |
| `origin` | `String` | Query, Required | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `destination` | `String` | Query, Required | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |

##### Response Type

[`FlightStatusResult`](#flight-status-result)

##### Example Usage

```java
int flightNumber = 925;
String departureDate = "2017-01-20";
String airlineCode = "VA";
String origin = "DFW";
String destination = "LAX";

shoppingController.flightStatusAsync(flightNumber, departureDate, airlineCode, origin, destination).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Available Ancillaries

Returns available ancillaries.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> getAvailableAncillariesAsync(
    final List<Object> promoSSRs)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Returns available ancillaries. |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
shoppingController.getAvailableAncillariesAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Award Details

Gets Award payment details like: minimum and maximum amount of award points could be use to pay for the trip and how it can be split between price components. It's required to be log in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> getAwardDetailsAsync()
```

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
shoppingController.getAwardDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Baggage Allowance

Returns Baggage results for specific Shopping basket or For selected flight.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BaggageDisclosure> getBaggageAllowanceAsync(
    final List<Integer> shoppingBasketHashCode)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shoppingBasketHashCode` | `List<Integer>` | Query, Optional | Query parameter. It should be a valid basket hash value of the selected flight. Values supplied for this parameter are validated against the offers available. |

##### Response Type

[`BaggageDisclosure`](#baggage-disclosure)

##### Example Usage

```java
List<Integer> shoppingBasketHashCode = new LinkedList<>();
shoppingBasketHashCode.add(-1514690119);
shoppingBasketHashCode.add(-1514690119);

shoppingController.getBaggageAllowanceAsync(shoppingBasketHashCode).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Dynamic Currency Offers

Used when the currency of the booking is different than the currency on which the passenger's credit card is based. It checks if the Credit Card is eligible for the Dynamic Currency Conversion (DCC), informs the Payment Web Service that the Digital Connect requests for the dynamic currency conversion offers and retrieves possible DCC (Dynamic Currency Conversion) offers.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<DCCOfferResponse> getDynamicCurrencyOffersAsync(
    final GetDCCOffer body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetDCCOffer`](#get-dcc-offer) | Body, Required | Selected Offer |

##### Response Type

[`DCCOfferResponse`](#dcc-offer-response)

##### Example Usage

```java
GetDCCOffer body = new GetDCCOffer();
body.setCardNumber("111111111115550");
body.setCardCode("AX");
body.setAmount(new Amount());

shoppingController.getDynamicCurrencyOffersAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Fare Rules

Retrieve Fare Rules.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FareRulesResult> getFareRulesAsync()
```

##### Response Type

[`FareRulesResult`](#fare-rules-result)

##### Example Usage

```java
shoppingController.getFareRulesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Hold Options

Returns available on-hold options for the current booking.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<HoldOptionsResult> getHoldOptionsAsync()
```

##### Response Type

[`HoldOptionsResult`](#hold-options-result)

##### Example Usage

```java
shoppingController.getHoldOptionsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Installments

Used when installment source in payment options service is PAYMENT_PROVIDER. Installments are NOT available in BNPL.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<InstallmentsResponse> getInstallmentsAsync(
    final InstallmentsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InstallmentsRequest`](#installments-request) | Body, Required | Installments request |

##### Response Type

[`InstallmentsResponse`](#installments-response)

##### Example Usage

```java
InstallmentsRequest body = new InstallmentsRequest();
body.setCardCode("AX");

shoppingController.getInstallmentsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Insurance Offers

Get list of Insurance offers available

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<InsuranceOffers> getInsuranceOffersAsync()
```

##### Response Type

[`InsuranceOffers`](#insurance-offers)

##### Example Usage

```java
shoppingController.getInsuranceOffersAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Mini Fare Rules

Retrieve Mini Fare Rules.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<MiniFareRuleResult> getMiniFareRulesAsync(
    final List<Integer> shoppingBasketHashCode)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shoppingBasketHashCode` | `List<Integer>` | Query, Optional | Query parameter. It should be a valid basket hash value of selected flight. Values supplied for this parameter are validated against the offers available. |

##### Response Type

[`MiniFareRuleResult`](#mini-fare-rule-result)

##### Example Usage

```java
List<Integer> shoppingBasketHashCode = new LinkedList<>();
shoppingBasketHashCode.add(-1514690119);
shoppingBasketHashCode.add(-1514690119);

shoppingController.getMiniFareRulesAsync(shoppingBasketHashCode).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Passenger Information

Returns list of passengers.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Passengers> getPassengerInformationAsync()
```

##### Response Type

[`Passengers`](#passengers)

##### Example Usage

```java
shoppingController.getPassengerInformationAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Seat Map

Returns Seat Map for selected itinerary.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatsResult> getSeatMapAsync(
    final List<Object> promoSSRs)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Returns Seat Map for selected itinerary. |

##### Response Type

[`SeatsResult`](#seats-result)

##### Example Usage

```java
shoppingController.getSeatMapAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Travel Bank Details

Gets TravelBank account details like: all available funds, maximum amount that can be used to pay for the trip and how it can be split between price components. It's required to be logged in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TravelBankDetails> getTravelBankDetailsAsync()
```

##### Response Type

[`TravelBankDetails`](#travel-bank-details)

##### Example Usage

```java
shoppingController.getTravelBankDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Upsell Offers

get upsell result

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpsellResult> getUpsellOffersAsync()
```

##### Response Type

[`UpsellResult`](#upsell-result)

##### Example Usage

```java
shoppingController.getUpsellOffersAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Voucher Balance

Get balance for eVoucher or Gift Card.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<GetBalanceResult> getVoucherBalanceAsync(
    final Voucher body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Voucher`](#voucher) | Body, Required | Voucher with information about voucher type, number and pin or number and expire date. |

##### Response Type

[`GetBalanceResult`](#get-balance-result)

##### Example Usage

```java
Voucher body = new Voucher();

shoppingController.getVoucherBalanceAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Handle Waive Operations

Waive or unwaive OBFee.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<OBFeesWaiveResult> handleWaiveOperationsAsync(
    final WaiveOperationsRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`WaiveOperationsRequest`](#waive-operations-request) | Body, Required | Waive or unwaive OBFee |

##### Response Type

[`OBFeesWaiveResult`](#ob-fees-waive-result)

##### Example Usage

```java
WaiveOperationsRequest body = new WaiveOperationsRequest();

shoppingController.handleWaiveOperationsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Latest Flight Results

Returns latest search results.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AirSearchResults> latestFlightResultsAsync()
```

##### Response Type

[`AirSearchResults`](#air-search-results)

##### Example Usage

```java
shoppingController.latestFlightResultsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Metasearch

Selects meta itinerary offers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<MetaSearchResults> metasearchAsync(
    final MetaSearch body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`MetaSearch`](#meta-search) | Body, Required | JSON request with metasearch criteria |

##### Response Type

[`MetaSearchResults`](#meta-search-results)

##### Example Usage

```java
MetaSearch body = new MetaSearch();

shoppingController.metasearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### OB Fee Waiver Codes

Returns configured waiver codes form Ticketing Fee Waiving Reason List.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TicketingFeeWaivingReasons> oBFeeWaiverCodesAsync()
```

##### Response Type

[`TicketingFeeWaivingReasons`](#ticketing-fee-waiving-reasons)

##### Example Usage

```java
shoppingController.oBFeeWaiverCodesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Products Price Breakdown

Get prices breakdown of all products

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> productsPriceBreakdownAsync()
```

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
shoppingController.productsPriceBreakdownAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Purchase Itinerary and Create PNR

Purchase a booking.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BookingResult> purchaseItineraryAndCreatePNRAsync(
    final PaymentData body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PaymentData`](#payment-data) | Body, Required | Payment data required to purchase a booking. |

##### Response Type

[`BookingResult`](#booking-result)

##### Example Usage

```java
PaymentData body = new PaymentData();

shoppingController.purchaseItineraryAndCreatePNRAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Recalculate Product Prices

Recalculates products data based on given context

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> recalculateProductPricesAsync(
    final ProductsContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductsContext`](#products-context) | Body, Required | Context for products |

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
ProductsContext body = new ProductsContext();

shoppingController.recalculateProductPricesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Remove External Products

To remove an external product from the cart

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> removeExternalProductsAsync(
    final RemoveExternalProductRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RemoveExternalProductRequest`](#remove-external-product-request) | Body, Required | JSON request with external product detail |

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
RemoveExternalProductRequest body = new RemoveExternalProductRequest();

shoppingController.removeExternalProductsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Available OB Fees

Retrieves all available OBFees including ticketing and requested OBFees.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ObFeeBreakdownInformation> returnAvailableOBFeesAsync()
```

##### Response Type

[`ObFeeBreakdownInformation`](#ob-fee-breakdown-information)

##### Example Usage

```java
shoppingController.returnAvailableOBFeesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Available Upgrades

get upgrade result

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpgradeResult> returnAvailableUpgradesAsync()
```

##### Response Type

[`UpgradeResult`](#upgrade-result)

##### Example Usage

```java
shoppingController.returnAvailableUpgradesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Combinability Mapping

Returns combinability mapping. This information will allow to display proper payment methods and allow multiple forms of payment. It also provides information which products are paid separatelly so we can provide more flexibility to a user.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentCombinability> returnCombinabilityMappingAsync()
```

##### Response Type

[`PaymentCombinability`](#payment-combinability)

##### Example Usage

```java
shoppingController.returnCombinabilityMappingAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Returns OB Fees

Returns all currently selected OBFees in a breakdown per passenger.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ObFeeBreakdownInformation> returnsOBFeesAsync()
```

##### Response Type

[`ObFeeBreakdownInformation`](#ob-fee-breakdown-information)

##### Example Usage

```java
shoppingController.returnsOBFeesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Search for Ancillaries

Searches for ancillaries using provided context.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillariesResult> searchForAncillariesAsync(
    final List<Object> promoSSRs,
    final AncillarySearchContext body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promoSSRs` | `List<Object>` | Query, Optional | Searches for ancillaries using provided context. |
| `body` | [`AncillarySearchContext`](#ancillary-search-context) | Body, Optional | - |

##### Response Type

[`AncillariesResult`](#ancillaries-result)

##### Example Usage

```java
shoppingController.searchForAncillariesAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Seat Map Preview

Seats Preview for a selected itinerary

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PreviewSeatsResult> seatMapPreviewAsync(
    final int selectFlight)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selectFlight` | `int` | Query, Required | Query parameter. It should be a valid basket hash value of selected flight. Values supplied for this parameter are validated against the offers available. |

##### Response Type

[`PreviewSeatsResult`](#preview-seats-result)

##### Example Usage

```java
int selectFlight = -1514690119;

shoppingController.seatMapPreviewAsync(selectFlight).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Flights

Selects itinerary offers offers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ItineraryResult> selectFlightsAsync(
    final List<Object> selectFlights,
    final FlightSelectionOptions body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selectFlights` | `List<Object>` | Query, Required | Selected itinerary. |
| `body` | [`FlightSelectionOptions`](#flight-selection-options) | Body, Optional | - |

##### Response Type

[`ItineraryResult`](#itinerary-result)

##### Example Usage

```java
List<Object> selectFlights = new LinkedList<>();
selectFlights.add(com.sabre.digitalconnect.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"));
selectFlights.add(com.sabre.digitalconnect.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"));
selectFlights.add(com.sabre.digitalconnect.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"));

shoppingController.selectFlightsAsync(selectFlights, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Insurance

Select insurance offer using insurance productID

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SelectedInsurance> selectInsuranceAsync(
    final SelectInsuranceRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SelectInsuranceRequest`](#select-insurance-request) | Body, Optional | - |

##### Response Type

[`SelectedInsurance`](#selected-insurance)

##### Example Usage

```java
shoppingController.selectInsuranceAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Seats

Selects seats for passengers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatRequestResult> selectSeatsAsync(
    final SeatRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SeatRequest`](#seat-request) | Body, Required | Select seat request |

##### Response Type

[`SeatRequestResult`](#seat-request-result)

##### Example Usage

```java
SeatRequest body = new SeatRequest();

shoppingController.selectSeatsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Upgrade

update upgrade offers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpgradeRequestResult> selectUpgradeAsync(
    final UpgradeRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`UpgradeRequest`](#upgrade-request) | Body, Required | update upgrade request |

##### Response Type

[`UpgradeRequestResult`](#upgrade-request-result)

##### Example Usage

```java
UpgradeRequest body = new UpgradeRequest();

shoppingController.selectUpgradeAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Upsell Offer

update upsell offers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpsellRequestResult> selectUpsellOfferAsync(
    final UpsellRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`UpsellRequest`](#upsell-request) | Body, Required | update upsell request |

##### Response Type

[`UpsellRequestResult`](#upsell-request-result)

##### Example Usage

```java
UpsellRequest body = new UpsellRequest();

shoppingController.selectUpsellOfferAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Set Award Amount

Set payment award selection

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> setAwardAmountAsync(
    final AwardDetailsSelection body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AwardDetailsSelection`](#award-details-selection) | Body, Required | Award selection |

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
AwardDetailsSelection body = new AwardDetailsSelection();

shoppingController.setAwardAmountAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Shopping Cart

Get information about products and baggage

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ProductsCart> shoppingCartAsync()
```

##### Response Type

[`ProductsCart`](#products-cart)

##### Example Usage

```java
shoppingController.shoppingCartAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Submit On-Hold Purchase

Place booking on hold for a specific duration, usually with a fee paid by a credit card. Hold Option ID is required along with payment details.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BookingResult> submitOnHoldPurchaseAsync(
    final HoldPayment body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`HoldPayment`](#hold-payment) | Body, Required | Payment data and Hold Option Id required to purchase a booking. |

##### Response Type

[`BookingResult`](#booking-result)

##### Example Usage

```java
HoldPayment body = new HoldPayment();

shoppingController.submitOnHoldPurchaseAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Trip Contact Information

Returns Trip Contact Info details.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<TripContactInfo> tripContactInformationAsync()
```

##### Response Type

[`TripContactInfo`](#trip-contact-info)

##### Example Usage

```java
shoppingController.tripContactInformationAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Ancillaries

update ancillaries

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AncillaryRequestResult> updateAncillariesAsync(
    final AncillaryRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AncillaryRequest`](#ancillary-request) | Body, Required | update ancillary |

##### Response Type

[`AncillaryRequestResult`](#ancillary-request-result)

##### Example Usage

```java
AncillaryRequest body = new AncillaryRequest();

shoppingController.updateAncillariesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### The Frequent Flyer Login and Profile Display

#### Overview

##### Get instance

An instance of the `TheFrequentFlyerLoginAndProfileDisplayController` class can be accessed from the API Client.

```
TheFrequentFlyerLoginAndProfileDisplayController theFrequentFlyerLoginAndProfileDisplayController = client.getTheFrequentFlyerLoginAndProfileDisplayController();
```

#### Login

Authenticate user in current conversation

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<LoginResultHolder> loginAsync(
    final LoginCredentials body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`LoginCredentials`](#login-credentials) | Body, Required | Login credentials |

##### Response Type

[`LoginResultHolder`](#login-result-holder)

##### Example Usage

```java
LoginCredentials body = new LoginCredentials();

theFrequentFlyerLoginAndProfileDisplayController.loginAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Logout

Logs out logged in user

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> logoutAsync()
```

##### Response Type

`void`

##### Example Usage

```java
theFrequentFlyerLoginAndProfileDisplayController.logoutAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve Login Result

Retrieve authenticated user's information

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<LoginResult> retrieveLoginResultAsync()
```

##### Response Type

[`LoginResult`](#login-result)

##### Example Usage

```java
theFrequentFlyerLoginAndProfileDisplayController.retrieveLoginResultAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Travel Agency

#### Overview

##### Get instance

An instance of the `TravelAgencyController` class can be accessed from the API Client.

```
TravelAgencyController travelAgencyController = client.getTravelAgencyController();
```

#### Agency Login

Authenticate agency in current conversation

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgencyLoginResultHolder> agencyLoginAsync(
    final AgencyLoginCredentials body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AgencyLoginCredentials`](#agency-login-credentials) | Body, Required | Agency Login credentials |

##### Response Type

[`AgencyLoginResultHolder`](#agency-login-result-holder)

##### Example Usage

```java
AgencyLoginCredentials body = new AgencyLoginCredentials();

travelAgencyController.agencyLoginAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agency Logout

Logs out the agency user

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> agencyLogoutAsync()
```

##### Response Type

`void`

##### Example Usage

```java
travelAgencyController.agencyLogoutAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agency Profile- Reset Password

Resets the password, valid change key must be present

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgencyResetPasswordResponse> agencyProfileResetPasswordAsync(
    final AgencyResetPasswordRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AgencyResetPasswordRequest`](#agency-reset-password-request) | Body, Required | New password and change key required to update the password |

##### Response Type

[`AgencyResetPasswordResponse`](#agency-reset-password-response)

##### Example Usage

```java
AgencyResetPasswordRequest body = new AgencyResetPasswordRequest();

travelAgencyController.agencyProfileResetPasswordAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agency Profile- Reset Password Key

Requests for a change password key to be sent to the user's email

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgencyResetPasswordResponse> agencyProfileResetPasswordKeyAsync(
    final AgencyResetPasswordKeyRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AgencyResetPasswordKeyRequest`](#agency-reset-password-key-request) | Body, Required | loginID required to retrieve the profile |

##### Response Type

[`AgencyResetPasswordResponse`](#agency-reset-password-response)

##### Example Usage

```java
AgencyResetPasswordKeyRequest body = new AgencyResetPasswordKeyRequest();

travelAgencyController.agencyProfileResetPasswordKeyAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agent Login

Authenticates agent in the current conversation.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgentLoginResponse> agentLoginAsync(
    final AgentLoginCredentials body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AgentLoginCredentials`](#agent-login-credentials) | Body, Required | Agent login credentials. |

##### Response Type

[`AgentLoginResponse`](#agent-login-response)

##### Example Usage

```java
AgentLoginCredentials body = new AgentLoginCredentials();

travelAgencyController.agentLoginAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agent Logout

Logs out the agent user.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<Void> agentLogoutAsync()
```

##### Response Type

`void`

##### Example Usage

```java
travelAgencyController.agentLogoutAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agent Profile- Reset Password

Resets the password, valid change key must be present.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgencyResetPasswordResponse> agentProfileResetPasswordAsync(
    final AgencyResetPasswordRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AgencyResetPasswordRequest`](#agency-reset-password-request) | Body, Required | New password and change key required to update the password. |

##### Response Type

[`AgencyResetPasswordResponse`](#agency-reset-password-response)

##### Example Usage

```java
AgencyResetPasswordRequest body = new AgencyResetPasswordRequest();

travelAgencyController.agentProfileResetPasswordAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Agent Profile- Reset Password Key

Requests for a change password key to be sent to the agent's email.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgencyResetPasswordResponse> agentProfileResetPasswordKeyAsync(
    final AgencyResetPasswordKeyRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AgencyResetPasswordKeyRequest`](#agency-reset-password-key-request) | Body, Required | loginID required to retrieve the profile. |

##### Response Type

[`AgencyResetPasswordResponse`](#agency-reset-password-response)

##### Example Usage

```java
AgencyResetPasswordKeyRequest body = new AgencyResetPasswordKeyRequest();

travelAgencyController.agentProfileResetPasswordKeyAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Create Agency Profile

Create a agency profile

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CreateAgencyProfileResponse> createAgencyProfileAsync(
    final CreateAgencyProfileRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateAgencyProfileRequest`](#create-agency-profile-request) | Body, Required | Profile data required to create a new agency profile |

##### Response Type

[`CreateAgencyProfileResponse`](#create-agency-profile-response)

##### Example Usage

```java
CreateAgencyProfileRequest body = new CreateAgencyProfileRequest();

travelAgencyController.createAgencyProfileAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Create Agent Profile

Creates an agent profile.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<CreateAgentProfileResponse> createAgentProfileAsync(
    final CreateAgentProfileRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateAgentProfileRequest`](#create-agent-profile-request) | Body, Required | Profile data required to create a new agent profile. |

##### Response Type

[`CreateAgentProfileResponse`](#create-agent-profile-response)

##### Example Usage

```java
CreateAgentProfileRequest body = new CreateAgentProfileRequest();

travelAgencyController.createAgentProfileAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve Agency Login Result

Retrieve authenticated agency user's information

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgencyLoginResult> retrieveAgencyLoginResultAsync()
```

##### Response Type

[`AgencyLoginResult`](#agency-login-result)

##### Example Usage

```java
travelAgencyController.retrieveAgencyLoginResultAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve Agency Profile

Retrieves logged in agency profile.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<RetrieveAgencyProfileResponse> retrieveAgencyProfileAsync()
```

##### Response Type

[`RetrieveAgencyProfileResponse`](#retrieve-agency-profile-response)

##### Example Usage

```java
travelAgencyController.retrieveAgencyProfileAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve Agent Login Result

Retrieves authenticated agent's information.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgentLoginResult> retrieveAgentLoginResultAsync()
```

##### Response Type

[`AgentLoginResult`](#agent-login-result)

##### Example Usage

```java
travelAgencyController.retrieveAgentLoginResultAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Retrieve Agent Profile

Retrieves an agent profile.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<RetrieveAgentProfileResponse> retrieveAgentProfileAsync(
    final String id)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Query, Required | Agent's ID required to retrieve profile. |

##### Response Type

[`RetrieveAgentProfileResponse`](#retrieve-agent-profile-response)

##### Example Usage

```java
String id = "id=300034639085";

travelAgencyController.retrieveAgentProfileAsync(id).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Search Agent Profile

Searches for agency's agents.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AgentsSearchResponse> searchAgentProfileAsync(
    final String firstName,
    final String lastName,
    final Integer pageNumber,
    final Integer elementsPerPage)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `String` | Query, Optional | Requested agent's first name. |
| `lastName` | `String` | Query, Optional | Requested agent's last name. |
| `pageNumber` | `Integer` | Query, Optional | Contains pagination related metadata. Page number and number of elements per page should be expressed as positive integers. |
| `elementsPerPage` | `Integer` | Query, Optional | Contains pagination related metadata. Page number and number of elements per page should be expressed as positive integers. |

##### Response Type

[`AgentsSearchResponse`](#agents-search-response)

##### Example Usage

```java
String firstName = "firstName=John";
String lastName = "lastName=Smith";
Integer pageNumber = 1;
Integer elementsPerPage = 30;

travelAgencyController.searchAgentProfileAsync(firstName, lastName, pageNumber, elementsPerPage).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Agency Profile

Update an existing user profile

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpdateAgencyProfileResponse> updateAgencyProfileAsync(
    final UpdateAgencyProfileRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`UpdateAgencyProfileRequest`](#update-agency-profile-request) | Body, Required | Profile data required to update an existing user profile |

##### Response Type

[`UpdateAgencyProfileResponse`](#update-agency-profile-response)

##### Example Usage

```java
UpdateAgencyProfileRequest body = new UpdateAgencyProfileRequest();

travelAgencyController.updateAgencyProfileAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Agent Profile

Updates an agent profile.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpdateAgentProfileResponse> updateAgentProfileAsync(
    final UpdateAgentProfileRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`UpdateAgentProfileRequest`](#update-agent-profile-request) | Body, Required | Profile data required to update an existing agent profile. |

##### Response Type

[`UpdateAgentProfileResponse`](#update-agent-profile-response)

##### Example Usage

```java
UpdateAgentProfileRequest body = new UpdateAgentProfileRequest();

travelAgencyController.updateAgentProfileAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

### Upgrade

#### Overview

##### Get instance

An instance of the `UpgradeController` class can be accessed from the API Client.

```
UpgradeController upgradeController = client.getUpgradeController();
```

#### Get Award Details

Gets Award payment details like: minimum and maximum amount of award points could be use to pay for the trip and how it can be split between price components. It's required to be log in.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<AwardDetails> getAwardDetailsAsync()
```

##### Response Type

[`AwardDetails`](#award-details)

##### Example Usage

```java
upgradeController.getAwardDetailsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Fare Rules

Retrieve Fare Rules.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<FareRulesResult> getFareRulesAsync()
```

##### Response Type

[`FareRulesResult`](#fare-rules-result)

##### Example Usage

```java
upgradeController.getFareRulesAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Seat Map

Get Seats Map for segments selected to be upgraded

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatsResult> getSeatMapAsync()
```

##### Response Type

[`SeatsResult`](#seats-result)

##### Example Usage

```java
upgradeController.getSeatMapAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Get Upgrade Offer

Get PNR upgrade offers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpgradeOffersResult> getUpgradeOfferAsync()
```

##### Response Type

[`UpgradeOffersResult`](#upgrade-offers-result)

##### Example Usage

```java
upgradeController.getUpgradeOfferAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Products Price Breakdown

Get prices breakdown of all products

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BreakdownResponse> productsPriceBreakdownAsync()
```

##### Response Type

[`BreakdownResponse`](#breakdown-response)

##### Example Usage

```java
upgradeController.productsPriceBreakdownAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Purchase Booking

purchase a booking upgrade

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<BookingResult> purchaseBookingAsync(
    final PaymentData body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PaymentData`](#payment-data) | Body, Optional | Payment data required to purchase a booking upgrade. |

##### Response Type

[`BookingResult`](#booking-result)

##### Example Usage

```java
upgradeController.purchaseBookingAsync(null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Return Combinability Mapping

Returns combinability mapping. This information will allow to display proper payment methods. It also provides information which products are paid separately so we can provide more flexibility to user.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PaymentCombinability> returnCombinabilityMappingAsync()
```

##### Response Type

[`PaymentCombinability`](#payment-combinability)

##### Example Usage

```java
upgradeController.returnCombinabilityMappingAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Select Seats

Selects seats for passengers

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<SeatRequestResult> selectSeatsAsync(
    final SeatRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SeatRequest`](#seat-request) | Body, Required | Select seat request |

##### Response Type

[`SeatRequestResult`](#seat-request-result)

##### Example Usage

```java
SeatRequest body = new SeatRequest();

upgradeController.selectSeatsAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Update Ancillaries

Update PNR upgrade offer

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<UpgradeOfferRequestResult> updateAncillariesAsync(
    final UpgradeOfferRequest body)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`UpgradeOfferRequest`](#upgrade-offer-request) | Body, Required | update upgrade offer |

##### Response Type

[`UpgradeOfferRequestResult`](#upgrade-offer-request-result)

##### Example Usage

```java
UpgradeOfferRequest body = new UpgradeOfferRequest();

upgradeController.updateAncillariesAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

#### Upgrade Flow Initialization

Get PNR info. for PNR upgrade flow

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<PnrRetrieveResponse> upgradeFlowInitializationAsync(
    final String pnr,
    final String firstName,
    final String lastName,
    final String email,
    final Boolean fareRulesRequired)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pnr` | `String` | Query, Optional | Reservation code (PNR). |
| `firstName` | `String` | Query, Optional | Passenger's first name. |
| `lastName` | `String` | Query, Optional | Passenger's last name. |
| `email` | `String` | Query, Optional | Passenger's email. |
| `fareRulesRequired` | `Boolean` | Query, Optional | Flag indicating if fare rules retrieval is required or not. |

##### Response Type

[`PnrRetrieveResponse`](#pnr-retrieve-response)

##### Example Usage

```java
String pnr = "pnr=LVBIEL";
String firstName = "firstName=John";
String lastName = "lastName=Smith";
String email = "email=SS@D.PL";

upgradeController.upgradeFlowInitializationAsync(pnr, firstName, lastName, email, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Model Reference

### Structures

* [Abstract Additional Product Information](#abstract-additional-product-information)
* [Abstract Ancillary SSR](#abstract-ancillary-ssr)
* [Abstract Ancillary Structured Text](#abstract-ancillary-structured-text)
* [Abstract Property Definition](#abstract-property-definition)
* [Accept New Segment Result](#accept-new-segment-result)
* [Access Token](#access-token)
* [Account Balance Info](#account-balance-info)
* [Account Info](#account-info)
* [Accounting Refund](#accounting-refund)
* [Add External Products Request](#add-external-products-request)
* [Additional Details](#additional-details)
* [Additional Payment Details](#additional-payment-details)
* [Address](#address)
* [Address Details](#address-details)
* [Administrator Details](#administrator-details)
* [Advisory](#advisory)
* [Afop Client Detail](#afop-client-detail)
* [Afop Detail](#afop-detail)
* [Afop Refund](#afop-refund)
* [Agency Contact Details](#agency-contact-details)
* [Agency Contact Info](#agency-contact-info)
* [Agency Credit Limit Info](#agency-credit-limit-info)
* [Agency Info](#agency-info)
* [Agency Login Credentials](#agency-login-credentials)
* [Agency Login Result](#agency-login-result)
* [Agency Login Result Holder](#agency-login-result-holder)
* [Agency Profile](#agency-profile)
* [Agency Reset Password Key Request](#agency-reset-password-key-request)
* [Agency Reset Password Request](#agency-reset-password-request)
* [Agency Reset Password Response](#agency-reset-password-response)
* [Agent Agency Info](#agent-agency-info)
* [Agent Contact Details](#agent-contact-details)
* [Agent Contact Info](#agent-contact-info)
* [Agent Info](#agent-info)
* [Agent Login Credentials](#agent-login-credentials)
* [Agent Login Response](#agent-login-response)
* [Agent Login Result](#agent-login-result)
* [Agent Profile](#agent-profile)
* [Agents Search Response](#agents-search-response)
* [Air Custom Pricing](#air-custom-pricing)
* [Air Itinerary Discount](#air-itinerary-discount)
* [Air Search](#air-search)
* [Air Search Exchange](#air-search-exchange)
* [Air Search Results](#air-search-results)
* [Alternate Search Suggestions](#alternate-search-suggestions)
* [Alternative Form of Payment](#alternative-form-of-payment)
* [Alternative Form of Payment Details](#alternative-form-of-payment-details)
* [Amount](#amount)
* [Amount Discount](#amount-discount)
* [Ancillaries Result](#ancillaries-result)
* [Ancillary](#ancillary)
* [Ancillary Configuration](#ancillary-configuration)
* [Ancillary Failed Travel Part](#ancillary-failed-travel-part)
* [Ancillary Group](#ancillary-group)
* [Ancillary Inventory Failure Details](#ancillary-inventory-failure-details)
* [Ancillary Keyword Property Definition](#ancillary-keyword-property-definition)
* [Ancillary Operation](#ancillary-operation)
* [Ancillary Operation Result](#ancillary-operation-result)
* [Ancillary Override Price](#ancillary-override-price)
* [Ancillary Passenger](#ancillary-passenger)
* [Ancillary Price](#ancillary-price)
* [Ancillary Property Definition](#ancillary-property-definition)
* [Ancillary Request](#ancillary-request)
* [Ancillary Request Result](#ancillary-request-result)
* [Ancillary Search Context](#ancillary-search-context)
* [Ancillary Special Service](#ancillary-special-service)
* [Ancillary SSR Description](#ancillary-ssr-description)
* [Ancillary Structured Texts](#ancillary-structured-texts)
* [Api Price](#api-price)
* [Award Ancillary Toggle](#award-ancillary-toggle)
* [Award Ancillary Toggle Option](#award-ancillary-toggle-option)
* [Award Ancillary Toggle Selection](#award-ancillary-toggle-selection)
* [Award Details](#award-details)
* [Award Details Selection](#award-details-selection)
* [Award Fare Slider](#award-fare-slider)
* [Award Money Tick](#award-money-tick)
* [Award Payment](#award-payment)
* [Award Refund](#award-refund)
* [Baggage Allowance Def](#baggage-allowance-def)
* [Baggage Allowance Restriction](#baggage-allowance-restriction)
* [Baggage Disclosure](#baggage-disclosure)
* [Baggage Restriction](#baggage-restriction)
* [Baggage Size Limit](#baggage-size-limit)
* [Baggage Weight Limit](#baggage-weight-limit)
* [Billing Data](#billing-data)
* [Booking Result](#booking-result)
* [Brand Label](#brand-label)
* [Branded Fare Itinerary Offer Mapping](#branded-fare-itinerary-offer-mapping)
* [Branded Results](#branded-results)
* [Breakdown Element](#breakdown-element)
* [Breakdown Element Assignment](#breakdown-element-assignment)
* [Breakdown Response](#breakdown-response)
* [Build Information](#build-information)
* [Bundle Item](#bundle-item)
* [Bundle Prices](#bundle-prices)
* [Business Loyalty](#business-loyalty)
* [Cabin](#cabin)
* [Cancel Upgrade Offer Operation](#cancel-upgrade-offer-operation)
* [Cancel Upgrade Offer Operation Result](#cancel-upgrade-offer-operation-result)
* [Cancel Upgrade Offer Request](#cancel-upgrade-offer-request)
* [Cancel Upgrade Offer Request Result](#cancel-upgrade-offer-request-result)
* [Cancel Upgrade Offers Result](#cancel-upgrade-offers-result)
* [Cancel Upgrade Result](#cancel-upgrade-result)
* [Cancellation Confirm Result](#cancellation-confirm-result)
* [Cancellation Confirmation Data](#cancellation-confirmation-data)
* [Cancellation Payment Data](#cancellation-payment-data)
* [Cancellation Result](#cancellation-result)
* [Capacity](#capacity)
* [Car Availability Search](#car-availability-search)
* [Car Availability Search Response](#car-availability-search-response)
* [Car Depot Location](#car-depot-location)
* [Car Details Summary](#car-details-summary)
* [Car Features](#car-features)
* [Car Info Model](#car-info-model)
* [Car Location Id](#car-location-id)
* [Car Location Search](#car-location-search-1)
* [Car Location Search Result](#car-location-search-result)
* [Car Offer](#car-offer)
* [Car Payment Summary](#car-payment-summary)
* [Car Rental Area](#car-rental-area)
* [Car Rental Location](#car-rental-location)
* [Car Reservation](#car-reservation)
* [Car Reservation Request](#car-reservation-request)
* [Car Reservation Response](#car-reservation-response)
* [Car Reservation Summary](#car-reservation-summary)
* [Card Details](#card-details)
* [Cards Authorization Failure Details](#cards-authorization-failure-details)
* [Carry on Baggage](#carry-on-baggage)
* [Checked in Baggage](#checked-in-baggage)
* [Checked in Baggage Allowance](#checked-in-baggage-allowance)
* [Collect Additional Data Info](#collect-additional-data-info)
* [Collect Additional Data Return](#collect-additional-data-return)
* [Combinable Payments Result](#combinable-payments-result)
* [Company Details](#company-details)
* [Configuration Service Result](#configuration-service-result)
* [Confirmation ID](#confirmation-id)
* [Connection Information](#connection-information)
* [Consent](#consent)
* [Contact](#contact)
* [Contact Details](#contact-details)
* [Context Info](#context-info)
* [Contextual Validation Info](#contextual-validation-info)
* [Coupon](#coupon)
* [Create Agency Profile Request](#create-agency-profile-request)
* [Create Agency Profile Response](#create-agency-profile-response)
* [Create Agent Profile Request](#create-agent-profile-request)
* [Create Agent Profile Response](#create-agent-profile-response)
* [Create Profile Request](#create-profile-request)
* [Create Profile Response](#create-profile-response)
* [Credit Card](#credit-card)
* [Credit Card Refund](#credit-card-refund)
* [DCC Document Detail](#dcc-document-detail)
* [DCC Offer Response](#dcc-offer-response)
* [DCC Passenger Document Detail](#dcc-passenger-document-detail)
* [DCC Payment Offer](#dcc-payment-offer)
* [Deal Discount](#deal-discount)
* [Direct Debit](#direct-debit)
* [Discount](#discount)
* [Discount Info](#discount-info)
* [Distance](#distance)
* [Distance Restriction](#distance-restriction)
* [Document](#document)
* [Document Details](#document-details)
* [Document Payment Details](#document-payment-details)
* [Driver](#driver)
* [Drivers Info](#drivers-info)
* [Embargo Information](#embargo-information)
* [Excess Baggage](#excess-baggage)
* [Exchange Breakdown Response](#exchange-breakdown-response)
* [External Login Data](#external-login-data)
* [External Product](#external-product)
* [Fare Basis Rules](#fare-basis-rules)
* [Fare Family](#fare-family)
* [Fare Rule](#fare-rule)
* [Fare Rules Result](#fare-rules-result)
* [First Payment](#first-payment)
* [Fixed Base Fare](#fixed-base-fare)
* [Flight](#flight)
* [Flight Ancillaries](#flight-ancillaries)
* [Flight Ancillary](#flight-ancillary)
* [Flight Info](#flight-info)
* [Flight Leg Info](#flight-leg-info)
* [Flight Schedule](#flight-schedule)
* [Flight Schedule Result](#flight-schedule-result)
* [Flight Selection Options](#flight-selection-options)
* [Flight Status Info](#flight-status-info)
* [Flight Status Result](#flight-status-result)
* [Fop Refund Data](#fop-refund-data)
* [Fraud Check Result](#fraud-check-result)
* [Fraud Net Data](#fraud-net-data)
* [Free Baggage Allowance](#free-baggage-allowance)
* [Frequent Flyer](#frequent-flyer)
* [Frequent Flyer Details](#frequent-flyer-details)
* [Frequent Flyer Member Info](#frequent-flyer-member-info)
* [General Sales Tax Data](#general-sales-tax-data)
* [Get Balance Result](#get-balance-result)
* [Get DCC Offer](#get-dcc-offer)
* [Hobby](#hobby)
* [Hold Option](#hold-option)
* [Hold Options Result](#hold-options-result)
* [Hold Payment](#hold-payment)
* [Hotel Reservation Summary](#hotel-reservation-summary)
* [Installment](#installment)
* [Installment Details](#installment-details)
* [Installment Option](#installment-option)
* [Installments Request](#installments-request)
* [Installments Response](#installments-response)
* [Insurance Information](#insurance-information)
* [Insurance Offer](#insurance-offer)
* [Insurance Offers](#insurance-offers)
* [Irop Response](#irop-response)
* [Itinerary](#itinerary)
* [Itinerary Information](#itinerary-information)
* [Itinerary Part](#itinerary-part)
* [Itinerary Part Brands](#itinerary-part-brands)
* [Itinerary Result](#itinerary-result)
* [Keyword Property Definition](#keyword-property-definition)
* [List Message Details](#list-message-details)
* [Location](#location)
* [Login Credentials](#login-credentials)
* [Login Result](#login-result)
* [Login Result Holder](#login-result-holder)
* [Login Travel Bank Details](#login-travel-bank-details)
* [Loyalty Details](#loyalty-details)
* [Marketing Text](#marketing-text)
* [Message](#message)
* [Message Details](#message-details)
* [Meta Search](#meta-search)
* [Meta Search Air Custom Pricing](#meta-search-air-custom-pricing)
* [Meta Search Itinerary Part](#meta-search-itinerary-part)
* [Meta Search Results](#meta-search-results)
* [Mini Fare Rule Result](#mini-fare-rule-result)
* [Monetary Modifier](#monetary-modifier)
* [My Trip Response](#my-trip-response)
* [Ob Fee](#ob-fee)
* [Ob Fee Breakdown Element](#ob-fee-breakdown-element)
* [Ob Fee Breakdown Information](#ob-fee-breakdown-information)
* [OB Fee Type R Update Response](#ob-fee-type-r-update-response)
* [OB Fee Type R Update Result](#ob-fee-type-r-update-result)
* [Ob Fees Type R Change Request](#ob-fees-type-r-change-request)
* [OB Fees Type R Operation](#ob-fees-type-r-operation)
* [OB Fees Waive Result](#ob-fees-waive-result)
* [Object Config](#object-config)
* [Occupation](#occupation)
* [Off Load Passenger Request](#off-load-passenger-request)
* [Off Load Passenger Response](#off-load-passenger-response)
* [Offer](#offer)
* [Offer Information](#offer-information)
* [Offer Without Price](#offer-without-price)
* [Old Ancillary](#old-ancillary)
* [Old Paid Seat](#old-paid-seat)
* [Operating Day](#operating-day)
* [Override Tax Price](#override-tax-price)
* [Page](#page)
* [Page Agent Profile](#page-agent-profile)
* [Passenger](#passenger)
* [Passenger Allowance](#passenger-allowance)
* [Passenger Baggage Disclosure](#passenger-baggage-disclosure)
* [Passenger Baggage Info](#passenger-baggage-info)
* [Passenger Change Response](#passenger-change-response)
* [Passenger Details](#passenger-details)
* [Passenger Document Info](#passenger-document-info)
* [Passenger Fare Rule](#passenger-fare-rule)
* [Passenger Info](#passenger-info)
* [Passenger Name](#passenger-name)
* [Passenger Offer](#passenger-offer)
* [Passenger Seat Map](#passenger-seat-map)
* [Passenger Segment Key](#passenger-segment-key)
* [Passenger Update Response](#passenger-update-response)
* [Passenger Upgrade Offer Price](#passenger-upgrade-offer-price)
* [Passenger Upgrade Price](#passenger-upgrade-price)
* [Passenger Visa Info](#passenger-visa-info)
* [Passenger With Features](#passenger-with-features)
* [Passengers](#passengers)
* [Pax Type Ob Fees Availability](#pax-type-ob-fees-availability)
* [Pay Pal](#pay-pal)
* [Pay Pal Refund](#pay-pal-refund)
* [Payment](#payment)
* [Payment Combinability](#payment-combinability)
* [Payment Data](#payment-data)
* [Payment Info](#payment-info)
* [Payment Options Result](#payment-options-result)
* [Payment Product](#payment-product)
* [Payment Product Combinability](#payment-product-combinability)
* [Payment Query Installment Details](#payment-query-installment-details)
* [Payment Query Installment Option](#payment-query-installment-option)
* [Paypal Redirect Info](#paypal-redirect-info)
* [Penalty](#penalty)
* [Penalty Fees](#penalty-fees)
* [Percentage Discount](#percentage-discount)
* [Percentage Modifier](#percentage-modifier)
* [Personal Details](#personal-details)
* [Phone](#phone)
* [Pnr](#pnr)
* [Pnr Payment](#pnr-payment)
* [Pnr Retrieve Response](#pnr-retrieve-response)
* [Pnr Selected Seat](#pnr-selected-seat)
* [Poli](#poli)
* [Poli Redirect Info](#poli-redirect-info)
* [Preferences](#preferences)
* [Preview Seats Result](#preview-seats-result)
* [Price Modifier](#price-modifier)
* [Priced Car](#priced-car)
* [Priced Itinerary Exchange Charge](#priced-itinerary-exchange-charge)
* [Prices](#prices)
* [Product Breakdown](#product-breakdown)
* [Product Payment](#product-payment)
* [Product Payment Combinability](#product-payment-combinability)
* [Products Cart](#products-cart)
* [Products Context](#products-context)
* [Profile Input](#profile-input)
* [Property Definition](#property-definition)
* [Provider Type](#provider-type)
* [Pseudo City](#pseudo-city)
* [Queue Placement Data](#queue-placement-data)
* [Queue Placement Failure Details](#queue-placement-failure-details)
* [Received 3 Rd Party Data](#received-3-rd-party-data)
* [Redirect Data](#redirect-data)
* [Redirect Info](#redirect-info)
* [Redirect Url Data](#redirect-url-data)
* [Refund Data Model](#refund-data-model)
* [Refund Document Info](#refund-document-info)
* [Refund Target](#refund-target)
* [Remark](#remark)
* [Remark Addition Failure Details](#remark-addition-failure-details)
* [Remarks and SS Rs](#remarks-and-ss-rs)
* [Remote Payment](#remote-payment)
* [Remove External Product Request](#remove-external-product-request)
* [Rental Rate](#rental-rate)
* [Required Properties](#required-properties)
* [Reset Password Key Request](#reset-password-key-request)
* [Reset Password Request](#reset-password-request)
* [Reset Password Response](#reset-password-response)
* [Resource Configuration Definition](#resource-configuration-definition)
* [Result Mapping](#result-mapping)
* [Retail Payment](#retail-payment)
* [Retail Reference](#retail-reference)
* [Retained Offer](#retained-offer)
* [Retrieve Agency Profile Response](#retrieve-agency-profile-response)
* [Retrieve Agent Profile Response](#retrieve-agent-profile-response)
* [Retrieve Profile Response](#retrieve-profile-response)
* [Route](#route)
* [Rule Information](#rule-information)
* [Rules](#rules)
* [Rules Evaluation](#rules-evaluation)
* [Rules Evaluation Result](#rules-evaluation-result)
* [Search Itinerary Part](#search-itinerary-part)
* [Search Result Meta Data](#search-result-meta-data)
* [Seat](#seat)
* [Seat Map](#seat-map)
* [Seat Operation](#seat-operation)
* [Seat Operation Result](#seat-operation-result)
* [Seat Price](#seat-price)
* [Seat Request](#seat-request)
* [Seat Request Result](#seat-request-result)
* [Seat Row](#seat-row)
* [Seats Itinerary Part](#seats-itinerary-part)
* [Seats Remaining](#seats-remaining)
* [Seats Result](#seats-result)
* [Security Data](#security-data)
* [Security Question](#security-question)
* [Segment](#segment)
* [Segment Disclosure](#segment-disclosure)
* [Segment Fare Rules](#segment-fare-rules)
* [Segment Key](#segment-key)
* [Segment Offer Information](#segment-offer-information)
* [Segment Seat Map](#segment-seat-map)
* [Segment Status Code](#segment-status-code)
* [Segment Upgrade Info](#segment-upgrade-info)
* [Select Insurance Request](#select-insurance-request)
* [Selected Ancillary](#selected-ancillary)
* [Selected Ancillary SSR Info](#selected-ancillary-ssr-info)
* [Selected Insurance](#selected-insurance)
* [Selected Passenger Ancillary](#selected-passenger-ancillary)
* [Selected Seat](#selected-seat)
* [Selected Segment](#selected-segment)
* [Selected Segment Message Details](#selected-segment-message-details)
* [Selected Travel Part](#selected-travel-part)
* [Service Info](#service-info)
* [Special Preferences](#special-preferences)
* [Special Service Request](#special-service-request)
* [Stop Airport](#stop-airport)
* [String Message Details](#string-message-details)
* [Sub Type Info](#sub-type-info)
* [Tax](#tax)
* [Tax Breakdown Element](#tax-breakdown-element)
* [Tax Price](#tax-price)
* [Third Party Redirect Info](#third-party-redirect-info)
* [Third Party Redirect Return](#third-party-redirect-return)
* [Ticketing Fee Waiving Reason](#ticketing-fee-waiving-reason)
* [Ticketing Fee Waiving Reasons](#ticketing-fee-waiving-reasons)
* [Time](#time)
* [Time to Ticket](#time-to-ticket)
* [Travel Bank](#travel-bank)
* [Travel Bank Details](#travel-bank-details)
* [Travel Bank Refund](#travel-bank-refund)
* [Travel Part](#travel-part)
* [Travel Part Additional Details](#travel-part-additional-details)
* [Travel Part Offer](#travel-part-offer)
* [Travel Part Upgrade Offer](#travel-part-upgrade-offer)
* [Travel Preferences](#travel-preferences)
* [Trip Contact Info](#trip-contact-info)
* [Trip Info](#trip-info)
* [Update Agency Profile Request](#update-agency-profile-request)
* [Update Agency Profile Response](#update-agency-profile-response)
* [Update Agent Profile Request](#update-agent-profile-request)
* [Update Agent Profile Response](#update-agent-profile-response)
* [Update Profile Request](#update-profile-request)
* [Update Profile Response](#update-profile-response)
* [Upgrade Info](#upgrade-info)
* [Upgrade Item Group](#upgrade-item-group)
* [Upgrade Offer](#upgrade-offer)
* [Upgrade Offer Operation](#upgrade-offer-operation)
* [Upgrade Offer Operation Result](#upgrade-offer-operation-result)
* [Upgrade Offer Price](#upgrade-offer-price)
* [Upgrade Offer Request](#upgrade-offer-request)
* [Upgrade Offer Request Result](#upgrade-offer-request-result)
* [Upgrade Offers Result](#upgrade-offers-result)
* [Upgrade Product Information](#upgrade-product-information)
* [Upgrade Request](#upgrade-request)
* [Upgrade Request Result](#upgrade-request-result)
* [Upgrade Result](#upgrade-result)
* [Upsell Request](#upsell-request)
* [Upsell Request Result](#upsell-request-result)
* [Upsell Result](#upsell-result)
* [Upsell Upgrade Item Detail](#upsell-upgrade-item-detail)
* [Upsell Upgrade Item Matrix](#upsell-upgrade-item-matrix)
* [Upsell Upgrade Item Price](#upsell-upgrade-item-price)
* [Upsell Upgrade Item Value](#upsell-upgrade-item-value)
* [Upsell Upgrade Message](#upsell-upgrade-message)
* [User](#user)
* [User Info](#user-info)
* [User Profile](#user-profile)
* [Vendor Info](#vendor-info)
* [Vendor Reference](#vendor-reference)
* [Voucher](#voucher)
* [Waive Operation](#waive-operation)
* [Waive Operations Request](#waive-operations-request)

#### Abstract Additional Product Information

Additional product information.

##### Class Name

`AbstractAdditionalProductInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "@type": null
}
```

#### Abstract Ancillary SSR

Special Service Request information for the ancillary.

##### Class Name

`AbstractAncillarySSR`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "@type": null
}
```

#### Abstract Ancillary Structured Text

Structured text describing the special service.

##### Class Name

`AbstractAncillaryStructuredText`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PropertyName` | `String` | Optional | Name of the property. |
| `PropertyValue` | `String` | Optional | Value input provided by the passengers for attributes: weight/length/height/width/keyword etc. |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "propertyName": null,
  "propertyValue": null,
  "@type": null
}
```

#### Abstract Property Definition

Ancillary details required to reserve an ancillary.

##### Class Name

`AbstractPropertyDefinition`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PropertyName` | `String` | Optional | Ancillary details such as weight, height, length, width or any other. |
| `PropertyType` | [`PropertyType`](#property-type) | Optional | Type of ancillary property. |
| `Optional` | `Boolean` | Optional | Flag indicating if the ancillary details are mandatory. If set to false they are mandatory, if set to true they are not. |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "propertyName": null,
  "propertyType": null,
  "optional": null,
  "@type": null
}
```

#### Accept New Segment Result

Result for revalidate segments with SC(Schedule change) status and mirror WK segment status.

##### Class Name

`AcceptNewSegmentResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Segments` | [`List<Segment>`](#segment) | Optional | List of accepted segments. |

##### Example (as JSON)

```json
{
  "segments": null
}
```

#### Access Token

Authorization endpoint response

##### Class Name

`AccessToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `String` |  | Access token |
| `TokenType` | `String` |  | Type of access token |
| `ExpiresIn` | `Long` | Optional | Time in seconds before the access token expires |
| `Expiry` | `Long` | Optional | Time of token expiry as unix timestamp (UTC) |

##### Example (as JSON)

```json
{
  "access_token": "access_token8",
  "token_type": "token_type2",
  "expires_in": null,
  "expiry": null
}
```

#### Account Balance Info

Account balance info before and after transaction.

##### Class Name

`AccountBalanceInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceBeforeTransaction` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `BalanceAfterTransaction` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "balanceBeforeTransaction": null,
  "balanceAfterTransaction": null
}
```

#### Account Info

Account balance summary.

##### Class Name

`AccountInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentCode` | `String` | Optional | Code of the account. |
| `Identifier` | `String` | Optional | Account ID info. |
| `AccountBalanceInfo` | [`AccountBalanceInfo`](#account-balance-info) | Optional | Account balance info before and after transaction. |

##### Example (as JSON)

```json
{
  "paymentCode": null,
  "identifier": null,
  "accountBalanceInfo": null
}
```

#### Accounting Refund

##### Class Name

`AccountingRefund`

##### Inherits From

[`RefundTarget`](#refund-target)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### Add External Products Request

Add to cart request.

##### Class Name

`AddExternalProductsRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ExternalProducts` | [`List<ExternalProduct>`](#external-product) | Optional | List of external products with breakdown. |

##### Example (as JSON)

```json
{
  "externalProducts": null
}
```

#### Additional Details

Details of air extra associated with EMD.

##### Class Name

`AdditionalDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RefundIndicator` | [`RefundIndicator`](#refund-indicator) | Optional | Refund indicator. Can be refundable, exchangeable or non-refundable. |
| `GroupCode` | `String` | Optional | Group code. |
| `SubCode` | `String` | Optional | Sub-code. |
| `Description` | `String` | Optional | Description. |
| `Quantity` | `Integer` | Optional | Quantity. |

##### Example (as JSON)

```json
{
  "refundIndicator": null,
  "groupCode": null,
  "subCode": null,
  "description": null,
  "quantity": null
}
```

#### Additional Payment Details

Information about additional payment details.

##### Class Name

`AdditionalPaymentDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "@type": null
}
```

#### Address

Passenger Contact Address.

##### Class Name

`Address`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Street1` | `String` | Optional | First line of street address specifying building number, street name etc. |
| `Street2` | `String` | Optional | Second line of street address specifying apt, suite etc. |
| `Postcode` | `String` | Optional | Postal or Zip code of the address. |
| `State` | `String` | Optional | Name of the state. |
| `City` | `String` | Optional | Name of the city. |
| `Country` | `String` | Optional | ISO country code (two letters) like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `AddressType` | [`AddressType`](#address-type) | Optional | Address type. |

##### Example (as JSON)

```json
{
  "street1": null,
  "street2": null,
  "postcode": null,
  "state": null,
  "city": null,
  "country": null,
  "addressType": null
}
```

#### Address Details

Passenger's Address Information.

##### Class Name

`AddressDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Street1` | `String` | Optional | First line of street address specifying building number, street name etc. |
| `Street2` | `String` | Optional | Second line of street address specifying apt, suite etc. |
| `Postcode` | `String` | Optional | Postal or Zip code of the address. |
| `State` | `String` | Optional | Name of the state. |
| `City` | `String` | Optional | Name of the city. |
| `Country` | `String` | Optional | ISO country code (two letters) like: https://en.wikipedia.org/?title=ISO_3166-1. |

##### Example (as JSON)

```json
{
  "street1": null,
  "street2": null,
  "postcode": null,
  "state": null,
  "city": null,
  "country": null
}
```

#### Administrator Details

Agency administrator information.

##### Class Name

`AdministratorDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Administrator's first name. |
| `LastName` | `String` | Optional | Administrator's last name. |
| `AgencyName` | `String` | Optional | Agency name. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "agencyName": null
}
```

#### Advisory

The Flight Advisory and Marketing Message feature allows airlines to set up advisory or marketing messages and publish them to passengers.

##### Class Name

`Advisory`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Level` | `String` | Optional | Message severity level. |
| `Code` | `String` | Optional | Message translation key. |
| `ImageHint` | `String` | Optional | Message hint - custom html translation. |
| `Image` | `String` | Optional | Message with image key. |

##### Example (as JSON)

```json
{
  "level": null,
  "code": null,
  "imageHint": null,
  "image": null
}
```

#### Afop Client Detail

Information about the purchaser.

##### Class Name

`AfopClientDetail`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Purchaser's first name. |
| `LastName` | `String` | Optional | Purchaser's last name. |
| `BirthDate` | `LocalDate` | Optional | Purchaser's birth date in the format: YYYY-MM-DD. |
| `Gender` | [`Gender2`](#gender-2) | Optional | Purchaser's gender. |
| `Email` | `String` | Optional | Purchaser's email. |
| `PhoneNumber` | `String` | Optional | Purchaser's phone number. |
| `Street` | `String` | Optional | Purchaser's street. |
| `HouseNumber` | `String` | Optional | Purchaser's house number. |
| `Postcode` | `String` | Optional | Purchaser's postcode. |
| `Province` | `String` | Optional | Purchaser's province. |
| `City` | `String` | Optional | Purchaser's city. |
| `Country` | `String` | Optional | Purchaser's country. |
| `Issuer` | `String` | Optional | Financial institution issuing the form of payment. Used for payments with 3DS cards. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "birthDate": null,
  "gender": null,
  "email": null,
  "phoneNumber": null,
  "street": null,
  "houseNumber": null,
  "postcode": null,
  "province": null,
  "city": null,
  "country": null,
  "issuer": null
}
```

#### Afop Detail

Information about alternative form of payment details.

##### Class Name

`AfopDetail`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FopCode` | `String` | Optional | Alternative form of payment code. |
| `FopSubCode` | `String` | Optional | Alternative form of payment subcode. |

##### Example (as JSON)

```json
{
  "fopCode": null,
  "fopSubCode": null
}
```

#### Afop Refund

##### Class Name

`AfopRefund`

##### Inherits From

[`RefundTarget`](#refund-target)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### Agency Contact Details

Agency user's details.

##### Class Name

`AgencyContactDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Agency user's first name. |
| `LastName` | `String` | Optional | Agency user's last name. |
| `Prefix` | [`Prefix`](#prefix) | Optional | Agency user's prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted). |
| `MiddleName` | `String` | Optional | Agency user's middle name. |
| `Suffix` | [`Suffix`](#suffix) | Optional | Agency user's suffix, accepts lower and upper case letters (suffix values read from the PNR will be in upper case letters to accommodate this, upper case is also accepted). |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "prefix": null,
  "middleName": null,
  "suffix": null
}
```

#### Agency Contact Info

Agency contact information.

##### Class Name

`AgencyContactInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | List of agency's emails. |
| `Phones` | [`List<Phone>`](#phone) | Optional | List of agency's phones. |
| `Addresses` | [`List<Address>`](#address) | Optional | List of agency's addresses. |

##### Example (as JSON)

```json
{
  "emails": null,
  "phones": null,
  "addresses": null
}
```

#### Agency Credit Limit Info

Agency account information.

##### Class Name

`AgencyCreditLimitInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Balance` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `BalanceInBookingCurrency` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `CreditLimit` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `CreditLimitInBookingCurrency` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `AccountNumber` | `String` | Optional | Agency's account number. |
| `ExternalLoginData` | [`ExternalLoginData`](#external-login-data) | Optional | Data required to log in and view agency credit limit information externally. |

##### Example (as JSON)

```json
{
  "balance": null,
  "balanceInBookingCurrency": null,
  "creditLimit": null,
  "creditLimitInBookingCurrency": null,
  "accountNumber": null,
  "externalLoginData": null
}
```

#### Agency Info

Agency Information.

##### Class Name

`AgencyInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyName` | `String` |  | Agency name. |
| `LoginID` | `String` | Optional | Agency portal login ID. |
| `Password` | `String` | Optional | Agency password to be set. This field will never have a value returned. |
| `IataId` | `String` | Optional | Agency identifier. |
| `TaxId` | `String` | Optional | Identification number used for tax purposes. |
| `AgencyCorporateID` | `String` | Optional | Agency corporate ID. |
| `AgencyUrl` | `String` | Optional | Agency website. |
| `AgencyContactInfo` | [`AgencyContactInfo`](#agency-contact-info) | Optional | Agency contact information. |

##### Example (as JSON)

```json
{
  "agencyName": "Agency X"
}
```

#### Agency Login Credentials

Login credentials required to authenticate an agency user.

##### Class Name

`AgencyLoginCredentials`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LoginID` | `String` | Optional | Agency user identifier. |
| `Password` | `String` | Optional | Agency password. |

##### Example (as JSON)

```json
{
  "loginID": null,
  "password": null
}
```

#### Agency Login Result

Result of the agency login.

##### Class Name

`AgencyLoginResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AdministratorDetails` | [`AdministratorDetails`](#administrator-details) | Optional | Agency administrator information. |
| `CreditLimitInfo` | [`AgencyCreditLimitInfo`](#agency-credit-limit-info) | Optional | Agency account information. |
| `Balance` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "administratorDetails": null,
  "creditLimitInfo": null,
  "balance": null
}
```

#### Agency Login Result Holder

Result and status of the agency login operation.

##### Class Name

`AgencyLoginResultHolder`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyLoginStatus` | [`AgencyLoginStatus`](#agency-login-status) | Optional | Status of the agency's login operation. |
| `AgencyLoginResult` | [`AgencyLoginResult`](#agency-login-result) | Optional | Result of the agency login. |

##### Example (as JSON)

```json
{
  "agencyLoginStatus": null,
  "agencyLoginResult": null
}
```

#### Agency Profile

Agency's profile information.

##### Class Name

`AgencyProfile`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserDetails` | [`AgencyContactDetails`](#agency-contact-details) | Optional | Agency user's details. |
| `AgencyInfo` | [`AgencyInfo`](#agency-info) | Optional | Agency Information. |
| `DateModified` | `LocalDateTime` | Optional | Date of the last profile modification in format: YYYY-MM-DD. |
| `ProfileType` | [`ProfileType`](#profile-type) | Optional | User profile type defined in profile system. |
| `PreferredLanguage` | `String` | Optional | Agency's preferred language. Language is identified by ISO 639 2-character codes. |
| `ProfileStatus` | `Boolean` | Optional | Status of the agency's profile. If set to true - ACTIVE, if set to false - DISABLED. |
| `Remarks` | [`List<Remark>`](#remark) | Optional | Texts that can be stored in the Profile system and might be used by the Interact agents as Invoice/Itinerary remarks. |

##### Example (as JSON)

```json
{
  "userDetails": null,
  "agencyInfo": null,
  "dateModified": null,
  "profileType": null,
  "preferredLanguage": null,
  "profileStatus": null,
  "remarks": null
}
```

#### Agency Reset Password Key Request

Required information to update an agency/agent profile password.

##### Class Name

`AgencyResetPasswordKeyRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LoginID` | `String` | Optional | Login ID used to retrieve the agency/agent profile and send a password reset link. |

##### Example (as JSON)

```json
{
  "loginID": null
}
```

#### Agency Reset Password Request

Required information to update the agency/agent profile password.

##### Class Name

`AgencyResetPasswordRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Password` | `String` | Optional | Password that needs to be updated in the agency/agent profile. |
| `ResetPasswordKey` | `String` | Optional | Encrypted key sent to the user. |

##### Example (as JSON)

```json
{
  "password": null,
  "resetPasswordKey": null
}
```

#### Agency Reset Password Response

Response information of agency/agent profile password reset action.

##### Class Name

`AgencyResetPasswordResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | [`Result3`](#result-3) | Optional | Status of the password reset. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "result": null
}
```

#### Agent Agency Info

Agency information.

##### Class Name

`AgentAgencyInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyName` | `String` | Optional | Agency's name. |
| `IataId` | `String` | Optional | Agency's identifier. |
| `AgencyCreditLimitInfo` | [`AgencyCreditLimitInfo`](#agency-credit-limit-info) | Optional | Agency account information. |

##### Example (as JSON)

```json
{
  "agencyName": null,
  "iataId": null,
  "agencyCreditLimitInfo": null
}
```

#### Agent Contact Details

Agent's details.

##### Class Name

`AgentContactDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Agent's first name. |
| `LastName` | `String` | Optional | Agent's last name. |
| `Prefix` | [`Prefix1`](#prefix-1) | Optional | Agent's prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted). |
| `MiddleName` | `String` | Optional | Agent's middle name. |
| `Suffix` | [`Suffix1`](#suffix-1) | Optional | Agent's suffix, accepts lower and upper case letters (suffix values read from the PNR will be in upper case letters to accommodate this, upper case is also accepted). |
| `Gender` | [`Gender`](#gender) | Optional | Agent's gender. |
| `DateOfBirth` | `LocalDate` | Optional | Agent's date of birth in the format: YYYY-MM-DD. |
| `PreferredLanguage` | `String` | Optional | Agent's preferred language. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "prefix": null,
  "middleName": null,
  "suffix": null,
  "gender": null,
  "dateOfBirth": null,
  "preferredLanguage": null
}
```

#### Agent Contact Info

Agent's contact information.

##### Class Name

`AgentContactInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | List of agent's emails. |
| `Phones` | [`List<Phone>`](#phone) | Optional | List of agent's phones. |
| `Addresses` | [`List<Address>`](#address) | Optional | List of agent's addresses. |

##### Example (as JSON)

```json
{
  "emails": null,
  "phones": null,
  "addresses": null
}
```

#### Agent Info

Agent information.

##### Class Name

`AgentInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Agent's first name. |
| `LastName` | `String` | Optional | Agent's last name. |
| `LoginID` | `String` | Optional | Agent's login identifier. |
| `AgentType` | [`AgentType`](#agent-type) | Optional | Type of an agent. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "loginID": null,
  "agentType": null
}
```

#### Agent Login Credentials

Login credentials required to authenticate an agent.

##### Class Name

`AgentLoginCredentials`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LoginID` | `String` | Optional | Agent's identifier. |
| `Password` | `String` | Optional | Agent's password. |

##### Example (as JSON)

```json
{
  "loginID": null,
  "password": null
}
```

#### Agent Login Response

Response from agent login operation.

##### Class Name

`AgentLoginResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyLoginStatus` | [`AgencyLoginStatus`](#agency-login-status) | Optional | Status of the agency's login operation. |
| `AgentLoginResult` | [`AgentLoginResult`](#agent-login-result) | Optional | Result of agent login operation. |

##### Example (as JSON)

```json
{
  "agencyLoginStatus": null,
  "agentLoginResult": null
}
```

#### Agent Login Result

Result of agent login operation.

##### Class Name

`AgentLoginResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgentAgencyInfo` | [`AgentAgencyInfo`](#agent-agency-info) | Optional | Agency information. |
| `AgentInfo` | [`AgentInfo`](#agent-info) | Optional | Agent information. |

##### Example (as JSON)

```json
{
  "agentAgencyInfo": null,
  "agentInfo": null
}
```

#### Agent Profile

Agent's profile information.

##### Class Name

`AgentProfile`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `String` | Optional | Agent's ID. |
| `LoginID` | `String` | Optional | Agent's login ID. |
| `Password` | `String` | Optional | Agent's password. |
| `AgentDetails` | [`AgentContactDetails`](#agent-contact-details) | Optional | Agent's details. |
| `AgentContactInfo` | [`AgentContactInfo`](#agent-contact-info) | Optional | Agent's contact information. |
| `ProfileStatusActive` | `Boolean` | Optional | Status of the agent's profile. If set to true - ACTIVE, if set to false - INACTIVE. |
| `ProfileType` | [`ProfileType1`](#profile-type-1) | Optional | Agent's type. |

##### Example (as JSON)

```json
{
  "id": null,
  "loginID": null,
  "password": null,
  "agentDetails": null,
  "agentContactInfo": null,
  "profileStatusActive": null,
  "profileType": null
}
```

#### Agents Search Response

Response information for agents profiles search operation.

##### Class Name

`AgentsSearchResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Status1`](#status-1) | Optional | Status of the agents profiles retrieval operation. The field is deprecated and will be removed in a subsequent major release. |
| `AgentProfilePage` | [`PageAgentProfile`](#page-agent-profile) | Optional | Contains pagination related metadata as well as paginated content. |

##### Example (as JSON)

```json
{
  "status": null,
  "agentProfilePage": null
}
```

#### Air Custom Pricing

Custom pricing details for selected itinerary supporting custom discount at itinerary part/itinerary level, tax override and endorsement text addition to booking.

##### Class Name

`AirCustomPricing`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Endorsement` | `String` | Optional | Endorsement text which will be added to the booking. |
| `Taxes` | [`List<Tax>`](#tax) | Optional | List of overridden taxes. |
| `AirItineraryDiscount` | [`List<AirItineraryDiscount>`](#air-itinerary-discount) | Optional | Itinerary/Itinerary part level discount. |

##### Example (as JSON)

```json
{
  "endorsement": null,
  "taxes": null,
  "airItineraryDiscount": null
}
```

#### Air Itinerary Discount

Discount amount/percentage or fixed base fare for the selected itinerary.

##### Class Name

`AirItineraryDiscount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryPart` | [`SelectedSegment`](#selected-segment) | Optional | Selected segment for seat. |
| `Discount` | [`Discount`](#discount) | Optional | - |

##### Example (as JSON)

```json
{
  "itineraryPart": null,
  "discount": null
}
```

#### Air Search

JSON representation of the search parameters.

##### Class Name

`AirSearch`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CabinClass` | [`CabinClass2`](#cabin-class-2) |  | Specifies cabin class. |
| `Currency` | `String` | Optional | Currency that overrides default currency used in search. Three letter ISO code like https://en.wikipedia.org/wiki/ISO_4217, or FFCURRENCY for points/miles. |
| `AwardBooking` | `Boolean` | Optional | Flag indicating if search result should be obtained for an award booking. |
| `SearchType` | [`SearchType`](#search-type) | Optional | Search type. |
| `PromoCodes` | `List<String>` | Optional | Promo codes associated with the trip/passengers. |
| `ItineraryParts` | [`List<SearchItineraryPart>`](#search-itinerary-part) | Optional | Air search parameters. |
| `Passengers` | `Map<String, String>` | Optional | Type and number of passenger requested. At least one Stand-alone passenger is Required (based on the PassengerType configuration). |
| `PointOfSale` | `String` | Optional | Point of Sale denotes the Country from which Sale happens. ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `TrendIndicator` | `String` | Optional | Flag indicating multiple visits to the website. |
| `PreferredOperatingCarrier` | `String` | Optional | Operating carrier code to be sent to shopping as the preferred one. |

##### Example (as JSON)

```json
{
  "cabinClass": "Economy",
  "currency": null,
  "awardBooking": null,
  "searchType": null,
  "promoCodes": null,
  "itineraryParts": null,
  "passengers": null,
  "pointOfSale": null,
  "trendIndicator": null,
  "preferredOperatingCarrier": null
}
```

#### Air Search Exchange

JSON representation of the exchange search parameters.

##### Class Name

`AirSearchExchange`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SearchCriteria` | [`AirSearch`](#air-search) |  | JSON representation of the search parameters. |
| `ExchangeType` | [`ExchangeType`](#exchange-type) |  | Specifies an exchange type. |
| `SegmentsToExchange` | `List<Integer>` | Optional | Specifies segments for an exchange when exchangeType is set as segment. Segments should be specified as a list of numbers starting from 1. For itinerary DFW-FRA-KRK, KRK-DFW segment indexes will be: DFW-FRA 1, FRA-KRK 2, KRK-DFW 3. |

##### Example (as JSON)

```json
{
  "searchCriteria": {
    "cabinClass": "Business",
    "currency": null,
    "awardBooking": null,
    "searchType": null,
    "promoCodes": null,
    "itineraryParts": null,
    "passengers": null,
    "pointOfSale": null,
    "trendIndicator": null,
    "preferredOperatingCarrier": null
  },
  "exchangeType": "both",
  "segmentsToExchange": null
}
```

#### Air Search Results

Results from the search operation obtained for the search criteria containing list of itineraries with fare breakdown.

##### Class Name

`AirSearchResults`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SearchResultMetaData` | [`SearchResultMetaData`](#search-result-meta-data) | Optional | Additional results data. |
| `FareFamilies` | [`List<FareFamily>`](#fare-family) | Optional | List of all available fare families (brands). |
| `UnbundledOffers` | [`List<List<Offer>>`](#offer) | Optional | List of lists of unbundled offers sorted by legs. |
| `UnbundledAlternateDateOffers` | [`List<List<Offer>>`](#offer) | Optional | List of lists of unbundled offers sorted by legs. |
| `BundledOffers` | [`List<Offer>`](#offer) | Optional | List of all bundled offers. Offer for whole itinerary. |
| `BundledAlternateDateOffers` | [`List<Offer>`](#offer) | Optional | List of all bundled offers for alternate dats. Offer for whole itinerary. |
| `BrandedResults` | [`BrandedResults`](#branded-results) | Optional | Results grouped by flight list in brand columns. |
| `ResultMapping` | [`ResultMapping`](#result-mapping) | Optional | Result combinability mapping. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | Global and Itinerary Flight messages that match the passenger's criteria for travel date and destination. |
| `TravelPartAdvisories` | [`List<List<Advisory>>`](#advisory) | Optional | Flight Day messages pertaining to the travel day. |
| `SoldOutDatesOutbound` | `List<LocalDate>` | Optional | List of outbound dates when all possible flights are already sold out. In the format: YYYY-MM-DD. |
| `SoldOutDatesInbound` | `List<LocalDate>` | Optional | List of inbound dates when all possible flights are already sold out. In the format: YYYY-MM-DD. |
| `NoneScheduledDatesOutbound` | `List<LocalDate>` | Optional | List of outbound dates when there are no scheduled flights. In the format: YYYY-MM-DD. |
| `NoneScheduledDatesInbound` | `List<LocalDate>` | Optional | List of inbound dates when there are no scheduled flights. In the format: YYYY-MM-DD. |
| `Warnings` | `List<String>` | Optional | Warnings. |
| `Currency` | `String` | Optional | Main currency used in the search results. Three letter ISO code like https://en.wikipedia.org/wiki/ISO_4217, or FFCURRENCY for points/miles. |
| `PromocodeValid` | `Boolean` | Optional | Flag indicating if used promocode was valid. |
| `NegotiateFarePresent` | `Boolean` | Optional | Flag indicating if negotiated fares are present in response. |
| `ConversionRatesFound` | `Boolean` | Optional | Flag indicating if conversion rates were found for this RBE conversion method search. Applies only for RBE with conversion method. |
| `RetainedItineraryPartOffer` | [`RetainedOffer`](#retained-offer) | Optional | Represents offer for retained itinerary part. |
| `Messages` | [`List<Message>`](#message) | Optional | List of additional messages about the result. Additional information about results, warnings and/or non-blocking errors. |

##### Example (as JSON)

```json
{
  "searchResultMetaData": null,
  "fareFamilies": null,
  "unbundledOffers": null,
  "unbundledAlternateDateOffers": null,
  "bundledOffers": null,
  "bundledAlternateDateOffers": null,
  "brandedResults": null,
  "resultMapping": null,
  "advisories": null,
  "travelPartAdvisories": null,
  "soldOutDatesOutbound": null,
  "soldOutDatesInbound": null,
  "noneScheduledDatesOutbound": null,
  "noneScheduledDatesInbound": null,
  "warnings": null,
  "currency": null,
  "promocodeValid": null,
  "negotiateFarePresent": null,
  "conversionRatesFound": null,
  "retainedItineraryPartOffer": null,
  "messages": null
}
```

#### Alternate Search Suggestions

Alternate route suggestions associated with the air search results when flights are: SOLD_OUT, UNAVAILABLE or NO_SCHEDULE for the requested search criteria.

##### Class Name

`AlternateSearchSuggestions`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OriginalRoute` | [`SegmentKey`](#segment-key) | Optional | Segment key to associate fare rules, seat map segment etc. |
| `AlternateRoute` | [`SegmentKey`](#segment-key) | Optional | Segment key to associate fare rules, seat map segment etc. |
| `AlternateSearchType` | [`AlternateSearchType`](#alternate-search-type) | Optional | Alternate search type when flights are SOLD_OUT, UNAVAILABLE, NO_SCHEDULE for the requested search criteria. |

##### Example (as JSON)

```json
{
  "originalRoute": null,
  "alternateRoute": null,
  "alternateSearchType": null
}
```

#### Alternative Form of Payment

##### Class Name

`AlternativeFormOfPayment`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AfopClientDetail` | [`AfopClientDetail`](#afop-client-detail) | Optional | Information about the purchaser. |
| `FopCode` | `String` | Optional | Form of payment code for Alternative form of payment (AFOP) which identifies the AFOP Category. |
| `FopSubcode` | `String` | Optional | Form of payment subcode for Alternative form of payment (AFOP) which identifies the actual AFOP. |
| `RedirectUrlData` | [`RedirectUrlData`](#redirect-url-data) | Optional | Data regarding AFOP or Dynamic 3ds redirection urls, required for the 1st request. |
| `Received3rdPartyData` | [`Received3rdPartyData`](#received-3-rd-party-data) | Optional | Data obtained after returning from 3rd party redirection, required for the 2nd AFOP or Dynamic 3DS request. |

##### Example (as JSON)

```json
{
  "afopClientDetail": null,
  "fopCode": null,
  "fopSubcode": null,
  "redirectUrlData": null,
  "received3rdPartyData": null,
  "amount": null,
  "@type": null
}
```

#### Alternative Form of Payment Details

##### Class Name

`AlternativeFormOfPaymentDetails`

##### Inherits From

[`AdditionalPaymentDetails`](#additional-payment-details)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AfopDetails` | [`List<AfopDetail>`](#afop-detail) | Optional | List of alternative form of payment details. |

##### Example (as JSON)

```json
{
  "afopDetails": null,
  "@type": null
}
```

#### Amount

Amount presenting class.

##### Class Name

`Amount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `Double` | Optional | Amount. |
| `Currency` | `String` | Optional | Currency - Three letter ISO code like https://en.wikipedia.org/wiki/ISO_4217 or 'FFCURRENCY' for points/miles. |

##### Example (as JSON)

```json
{
  "amount": null,
  "currency": null
}
```

#### Amount Discount

##### Class Name

`AmountDiscount`

##### Inherits From

[`Discount`](#discount)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `Double` | Optional | Discount amount to be applied for the fare. |

##### Example (as JSON)

```json
{
  "amount": null,
  "@type": null
}
```

#### Ancillaries Result

Ancillaries result.

##### Class Name

`AncillariesResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | List of additional messages which contains  details about error, warning etc. |
| `AncillaryPassengers` | [`List<AncillaryPassenger>`](#ancillary-passenger) | Optional | List of passenger's details for the ancillary purposes. |
| `Itinerary` | [`Itinerary`](#itinerary) | Optional | - |
| `Ancillaries` | [`List<Ancillary>`](#ancillary) | Optional | Ancillaries not assigned to any group. |
| `AncillaryGroups` | [`List<AncillaryGroup>`](#ancillary-group) | Optional | List of ancillary groups with assigned ancillaries. |
| `NotPreselectedAncillaries` | [`List<OldAncillary>`](#old-ancillary) | Optional | Ancillaries not preselected for a reassociation in the exchange process. |

##### Example (as JSON)

```json
{
  "messages": null,
  "ancillaryPassengers": null,
  "itinerary": null,
  "ancillaries": null,
  "ancillaryGroups": null,
  "notPreselectedAncillaries": null
}
```

#### Ancillary

Ancillary.

##### Class Name

`Ancillary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Code of the ancillary. |
| `AncillarySpecialService` | [`AncillarySpecialService`](#ancillary-special-service) | Optional | IATA-defined special service request. |
| `AncillaryConfiguration` | [`AncillaryConfiguration`](#ancillary-configuration) | Optional | Configuration details for the ancillary. |
| `TravelPartOffers` | [`List<TravelPartOffer>`](#travel-part-offer) | Optional | Ancillary offers associated with the specified travel part and passengers. |
| `BundleItems` | [`List<BundleItem>`](#bundle-item) | Optional | Ancillary codes included in the bundle offer. |
| `Refundable` | `Boolean` | Optional | Flag indicating if the ancillary is refundable. |

##### Example (as JSON)

```json
{
  "code": null,
  "ancillarySpecialService": null,
  "ancillaryConfiguration": null,
  "travelPartOffers": null,
  "bundleItems": null,
  "refundable": null
}
```

#### Ancillary Configuration

Configuration details for the ancillary.

##### Class Name

`AncillaryConfiguration`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AllowQuantity` | `Boolean` | Optional | Flag indicating if the user can select the ancillary quantity. If set up to false user can select only one ancillary. |
| `MaxQuantityPerPax` | `Integer` | Optional | Maximum quantity per one passenger. |

##### Example (as JSON)

```json
{
  "allowQuantity": null,
  "maxQuantityPerPax": null
}
```

#### Ancillary Failed Travel Part

Details of a travel part associated with the failed ancillary.

##### Class Name

`AncillaryFailedTravelPart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A) of the travel part associated with the failed ancillary. |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A) of the travel part associated with the failed ancillary. |
| `FlightNumber` | `Integer` | Optional | Flight number associated with the failed ancillary. |

##### Example (as JSON)

```json
{
  "origin": null,
  "destination": null,
  "flightNumber": null
}
```

#### Ancillary Group

Ancillary group.

##### Class Name

`AncillaryGroup`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Group code. |
| `MaxGroupedQuantity` | `Integer` | Optional | Maximum quantity for group of ancillaries. |
| `Ancillaries` | [`List<Ancillary>`](#ancillary) | Optional | List of ancillaries. |

##### Example (as JSON)

```json
{
  "code": null,
  "maxGroupedQuantity": null,
  "ancillaries": null
}
```

#### Ancillary Inventory Failure Details

Details related to ticketing or booking failure of inventory controlled ancillaries.

##### Class Name

`AncillaryInventoryFailureDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SubCode` | `String` | Optional | A code of failed ancillary. |
| `Priority` | `Boolean` | Optional | The reason for providing warning for "priority" ancillaries. <br>The airline - based on the JSON-s warning/response - is able to distinguish between standard and priority ancillaries (e.g. paid special assistance set up as ancillary) and inform passenger accordingly on the UI. |
| `FailedTravelPart` | [`AncillaryFailedTravelPart`](#ancillary-failed-travel-part) | Optional | Details of a travel part associated with the failed ancillary. |

##### Example (as JSON)

```json
{
  "subCode": null,
  "priority": null,
  "failedTravelPart": null
}
```

#### Ancillary Keyword Property Definition

##### Class Name

`AncillaryKeywordPropertyDefinition`

##### Inherits From

[`AbstractAncillaryStructuredText`](#abstract-ancillary-structured-text)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Quantity` | `Integer` | Optional | Number of items the passenger has selected for the chosen option from the Special Service Request (SSR). |

##### Example (as JSON)

```json
{
  "quantity": null,
  "propertyName": null,
  "propertyValue": null,
  "@type": null
}
```

#### Ancillary Operation

Operation request for specific ancillary, selected travel part and passengers.

##### Class Name

`AncillaryOperation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AncillaryCode` | `String` | Optional | Ancillary code. |
| `SelectedTravelPart` | [`SelectedTravelPart`](#selected-travel-part) | Optional | Selected travel part. |
| `SelectedPassengers` | [`List<SelectedPassengerAncillary>`](#selected-passenger-ancillary) | Optional | List of passengers associated with this ancillary operation. |

##### Example (as JSON)

```json
{
  "ancillaryCode": null,
  "selectedTravelPart": null,
  "selectedPassengers": null
}
```

#### Ancillary Operation Result

Operation result for specific ancillary operation.

##### Class Name

`AncillaryOperationResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Messages for the current post ancillary request. |
| `AncillaryCode` | `String` | Optional | Code of the selected ancillary. |
| `SelectedTravelPart` | [`SelectedTravelPart`](#selected-travel-part) | Optional | Selected travel part. |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger associated with ancillary operation, expressed as a positive integer. |
| `Successful` | `Boolean` | Optional | Status of finished operation. |
| `AssignedQuantity` | `Integer` | Optional | Quantity assigned for the passenger after executing operation. |
| `AncillarySSR` | [`AbstractAncillarySSR`](#abstract-ancillary-ssr) | Optional | - |

##### Example (as JSON)

```json
{
  "messages": null,
  "ancillaryCode": null,
  "selectedTravelPart": null,
  "passengerIndex": null,
  "successful": null,
  "assignedQuantity": null,
  "ancillarySSR": null
}
```

#### Ancillary Override Price

Overridden price for the ancillary offer. Contains base, taxes and override message.

##### Class Name

`AncillaryOverridePrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BasePrice` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `TaxPrice` | [`List<OverrideTaxPrice>`](#override-tax-price) | Optional | List of tax prices. |
| `AdditionalTextQualifier` | `String` | Optional | Part of remark indicating ancillary price override. |
| `SecurityData` | [`SecurityData`](#security-data) | Optional | Security information. Contains current timestamp and fingerprint. |

##### Example (as JSON)

```json
{
  "basePrice": null,
  "taxPrice": null,
  "additionalTextQualifier": null,
  "securityData": null
}
```

#### Ancillary Passenger

Passenger's details.

##### Class Name

`AncillaryPassenger`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Index` | `Integer` | Optional | Index of the passenger expressed as a positive integer. |
| `FirstName` | `String` | Optional | Passenger's first name. |
| `LastName` | `String` | Optional | Passenger's last name. |
| `Type` | [`Type1`](#type-1) | Optional | Passenger's type. |
| `TierLevel` | `String` | Optional | Frequent Flyer tier level. |
| `TierLevelNumber` | `Integer` | Optional | Frequent Flyer tier number. |

##### Example (as JSON)

```json
{
  "index": null,
  "firstName": null,
  "lastName": null,
  "type": null,
  "tierLevel": null,
  "tierLevelNumber": null
}
```

#### Ancillary Price

Ancillary price for the ancillary offer. Contains base, taxes and total price.

##### Class Name

`AncillaryPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BasePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalAssignedPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TaxPrice` | [`List<TaxPrice>`](#tax-price) | Optional | List of tax prices. |
| `OriginalBasePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginalTotalTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginalTotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginalTaxPrice` | [`List<TaxPrice>`](#tax-price) | Optional | List of original tax prices (without discount). |

##### Example (as JSON)

```json
{
  "basePrice": null,
  "totalTax": null,
  "totalPrice": null,
  "totalAssignedPrice": null,
  "taxPrice": null,
  "originalBasePrice": null,
  "originalTotalTax": null,
  "originalTotalPrice": null,
  "originalTaxPrice": null
}
```

#### Ancillary Property Definition

##### Class Name

`AncillaryPropertyDefinition`

##### Inherits From

[`AbstractAncillaryStructuredText`](#abstract-ancillary-structured-text)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Unit` | `String` | Optional | Unit (like KG/LB for weight, INCH/CM for length) for the value (if applicable). |

##### Example (as JSON)

```json
{
  "unit": null,
  "propertyName": null,
  "propertyValue": null,
  "@type": null
}
```

#### Ancillary Request

Ancillary operation request.

##### Class Name

`AncillaryRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AncillaryOperations` | [`List<AncillaryOperation>`](#ancillary-operation) | Optional | List with details for ancillary operations. |

##### Example (as JSON)

```json
{
  "ancillaryOperations": null
}
```

#### Ancillary Request Result

Ancillary operation result.

##### Class Name

`AncillaryRequestResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Messages pertaining to ancillary request results. |
| `AncillaryOperationResults` | [`List<AncillaryOperationResult>`](#ancillary-operation-result) | Optional | List with results from ancillary operations. |

##### Example (as JSON)

```json
{
  "messages": null,
  "ancillaryOperationResults": null
}
```

#### Ancillary Search Context

Context used for providing additional options when searching for ancillaries.

##### Class Name

`AncillarySearchContext`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PreselectFreeDiscountedAncillaries` | `Boolean` | Optional | This value determines whether the ancillaries that are set in the Dynamic Retailer (as included for the given brand) should be preselected. |

##### Example (as JSON)

```json
{
  "preselectFreeDiscountedAncillaries": null
}
```

#### Ancillary Special Service

IATA-defined special service request.

##### Class Name

`AncillarySpecialService`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Code of a special service requested by the passenger. |
| `Type` | [`Type2`](#type-2) | Optional | IATA-defined Special Service Request (SSR). |
| `RequiredProperties` | [`RequiredProperties`](#required-properties) | Optional | Properties required in order to reserve a given ancillary. |

##### Example (as JSON)

```json
{
  "code": null,
  "type": null,
  "requiredProperties": null
}
```

#### Ancillary SSR Description

##### Class Name

`AncillarySSRDescription`

##### Inherits From

[`AbstractAncillarySSR`](#abstract-ancillary-ssr)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `String` | Optional | Supplementary information related to the Special Service Request (SSR). |

##### Example (as JSON)

```json
{
  "description": null,
  "@type": null
}
```

#### Ancillary Structured Texts

##### Class Name

`AncillaryStructuredTexts`

##### Inherits From

[`AbstractAncillarySSR`](#abstract-ancillary-ssr)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AncillaryStructuredTexts` | [`List<AbstractAncillaryStructuredText>`](#abstract-ancillary-structured-text) | Optional | List of structured texts. |

##### Example (as JSON)

```json
{
  "ancillaryStructuredTexts": null,
  "@type": null
}
```

#### Api Price

Contains price and alternatives to display.

##### Class Name

`ApiPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Alternatives` | [`List<List<Amount>>`](#amount) | Optional | List of price alternative lists. Each element of main list is a full price. e.g. list [[700 AUD],[300 AUD, 80000 FFCURRENCY]. |

##### Example (as JSON)

```json
{
  "alternatives": null
}
```

#### Award Ancillary Toggle

Possible points/cash options for ancillaries with specific group code and current selection.

##### Class Name

`AwardAncillaryToggle`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GroupCode` | `String` | Optional | Ancillary group code. |
| `Options` | [`List<AwardAncillaryToggleOption>`](#award-ancillary-toggle-option) | Optional | Possible points/cash options. |
| `CurrentState` | [`CurrentState`](#current-state) | Optional | Current selected option. |

##### Example (as JSON)

```json
{
  "groupCode": null,
  "options": null,
  "currentState": null
}
```

#### Award Ancillary Toggle Option

Available amount for points/cash option.

##### Class Name

`AwardAncillaryToggleOption`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Option` | [`Option`](#option) | Optional | Points or cash selection. |
| `Amount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `AwardAncillaryToggleOptionStatus` | [`AwardAncillaryToggleOptionStatus`](#award-ancillary-toggle-option-status) | Optional | Toggle option status. |

##### Example (as JSON)

```json
{
  "option": null,
  "amount": null,
  "awardAncillaryToggleOptionStatus": null
}
```

#### Award Ancillary Toggle Selection

Ancillary toggle selection.

##### Class Name

`AwardAncillaryToggleSelection`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GroupCode` | `String` | Optional | Ancillary group code. |
| `Option` | [`Option`](#option) | Optional | Points or cash selection. |

##### Example (as JSON)

```json
{
  "groupCode": null,
  "option": null
}
```

#### Award Details

Award payment details.

##### Class Name

`AwardDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FareSlider` | [`AwardFareSlider`](#award-fare-slider) | Optional | Award slider. |
| `AncillaryToggles` | [`List<AwardAncillaryToggle>`](#award-ancillary-toggle) | Optional | List of ancillary AWARD toggles. |
| `AwardTotal` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `CashTotal` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "fareSlider": null,
  "ancillaryToggles": null,
  "awardTotal": null,
  "cashTotal": null
}
```

#### Award Details Selection

Points/cash slider and toggles selection.

##### Class Name

`AwardDetailsSelection`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FareAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `AncillaryToggleSelections` | [`List<AwardAncillaryToggleSelection>`](#award-ancillary-toggle-selection) | Optional | List of ancillary toggles selection to be applied for extras. |

##### Example (as JSON)

```json
{
  "fareAmount": null,
  "ancillaryToggleSelections": null
}
```

#### Award Fare Slider

Award slider.

##### Class Name

`AwardFareSlider`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AwardMoneyTicks` | [`List<AwardMoneyTick>`](#award-money-tick) | Optional | List of possible points/cash amount combinations for the fare. |
| `CurrentPositionIndex` | `Integer` | Optional | Current position of the slider. |
| `CurrentTick` | [`AwardMoneyTick`](#award-money-tick) | Optional | Possible points/cash amount combinations for the fare. |

##### Example (as JSON)

```json
{
  "awardMoneyTicks": null,
  "currentPositionIndex": null,
  "currentTick": null
}
```

#### Award Money Tick

Possible points/cash amount combinations for the fare.

##### Class Name

`AwardMoneyTick`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MoneyAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `AwardAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "moneyAmount": null,
  "awardAmount": null
}
```

#### Award Payment

##### Class Name

`AwardPayment`

##### Inherits From

[`Payment`](#payment)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "amount": null,
  "@type": null
}
```

#### Award Refund

##### Class Name

`AwardRefund`

##### Inherits From

[`RefundTarget`](#refund-target)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceInfo` | [`AccountBalanceInfo`](#account-balance-info) | Optional | Account balance info before and after transaction. |
| `AwardLogin` | `String` | Optional | Award login ID. |

##### Example (as JSON)

```json
{
  "balanceInfo": null,
  "awardLogin": null,
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### Baggage Allowance Def

Baggage allowance information for the passenger.

##### Class Name

`BaggageAllowanceDef`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TotalUnits` | `String` | Optional | Free baggage information disclosure. |
| `BaggageRestrictions` | [`List<BaggageRestriction>`](#baggage-restriction) | Optional | Baggage name, number of units, size and weight restrictions. |
| `Id` | `String` | Optional | ID of baggage allowance offer. |
| `TotalWeight` | `Map<String, String>` | Optional | List of total weights allowed for this bag. |
| `BaggageAllowanceType` | [`BaggageAllowanceType`](#baggage-allowance-type) | Optional | Type of baggage allowance. |
| `RuleId` | `String` | Optional | Rule ID from Merchandising Manager/Dynamic Retailer. |

##### Example (as JSON)

```json
{
  "totalUnits": null,
  "baggageRestrictions": null,
  "id": null,
  "totalWeight": null,
  "baggageAllowanceType": null,
  "ruleId": null
}
```

#### Baggage Allowance Restriction

##### Class Name

`BaggageAllowanceRestriction`

##### Inherits From

[`BaggageRestriction`](#baggage-restriction)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Designation` | `String` | Optional | Designation for the baggage. |
| `WeightLimit` | [`List<BaggageWeightLimit>`](#baggage-weight-limit) | Optional | List of weight restrictions. |
| `SizeLimit` | [`List<BaggageSizeLimit>`](#baggage-size-limit) | Optional | List of size restrictions. |
| `FirstOccurLimit` | `Integer` | Optional | First occurrence limit. |
| `LastOccurLimit` | `Integer` | Optional | Last occurrence limit. |

##### Example (as JSON)

```json
{
  "designation": null,
  "weightLimit": null,
  "sizeLimit": null,
  "firstOccurLimit": null,
  "lastOccurLimit": null,
  "dimensionDescription": null,
  "weightDescription": null,
  "allowedUnits": null,
  "baggageName": null,
  "@type": null
}
```

#### Baggage Disclosure

Baggage/CarryOn/Embargo Information for selected flights.

##### Class Name

`BaggageDisclosure`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentDisclosure` | [`List<SegmentDisclosure>`](#segment-disclosure) | Optional | List of passenger baggage/carry-on and embargo information for this segment. |
| `Segments` | [`List<Segment>`](#segment) | Optional | List of itinerary part segments, for clarity results. |
| `PassengerAllowance` | [`List<PassengerAllowance>`](#passenger-allowance) | Optional | List of available baggage allowance for set of segments and each passenger. |

##### Example (as JSON)

```json
{
  "segmentDisclosure": null,
  "segments": null,
  "passengerAllowance": null
}
```

#### Baggage Restriction

Baggage linear restrictions and allowed baggage for selected flights.

##### Class Name

`BaggageRestriction`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DimensionDescription` | `String` | Optional | Measurement of bag/carry-on in linear inches/centimeters with detailed description. |
| `WeightDescription` | `String` | Optional | Weight of the bag/carry-on in kilograms/pounds with detailed description. |
| `AllowedUnits` | `Integer` | Optional | Number of bags/carry-ons allowed. |
| `BaggageName` | `String` | Optional | Type of the baggage. |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "dimensionDescription": null,
  "weightDescription": null,
  "allowedUnits": null,
  "baggageName": null,
  "@type": null
}
```

#### Baggage Size Limit

Baggage size limit details.

##### Class Name

`BaggageSizeLimit`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BaggageLimitType` | [`BaggageLimitType`](#baggage-limit-type) | Optional | Limit type. |
| `Value` | `Integer` | Optional | Size value. |
| `BaggageSizeUnit` | [`BaggageSizeUnit`](#baggage-size-unit) | Optional | Size unit. |

##### Example (as JSON)

```json
{
  "baggageLimitType": null,
  "value": null,
  "baggageSizeUnit": null
}
```

#### Baggage Weight Limit

Baggage weight limit details.

##### Class Name

`BaggageWeightLimit`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BaggageLimitType` | [`BaggageLimitType`](#baggage-limit-type) | Optional | Limit type. |
| `Value` | `Double` | Optional | Weight value. |
| `BagUnit` | [`BagUnit`](#bag-unit) | Optional | Weight unit. |

##### Example (as JSON)

```json
{
  "baggageLimitType": null,
  "value": null,
  "bagUnit": null
}
```

#### Billing Data

Billing address information for the purchase.

##### Class Name

`BillingData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Street1` | `String` | Optional | First line of street address. |
| `Street2` | `String` | Optional | Second line of street address like apartment number. |
| `City` | `String` | Optional | Name of the city. |
| `Province` | `String` | Optional | Name of the province. |
| `ZipCode` | `String` | Optional | Address zip code. |
| `Country` | `String` | Optional | 2 letter ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `Phone` | [`Phone`](#phone) | Optional | Phone details. |
| `Email` | `String` | Optional | Email associated with billing address. |

##### Example (as JSON)

```json
{
  "street1": null,
  "street2": null,
  "city": null,
  "province": null,
  "zipCode": null,
  "country": null,
  "phone": null,
  "email": null
}
```

#### Booking Result

JSON representation of booking result.

##### Class Name

`BookingResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning and error messages list related to booking result. |
| `Pnr` | [`Pnr`](#pnr) | Optional | PNR representation. |
| `RedirectInfo` | [`RedirectInfo`](#redirect-info) | Optional | JSON representation of payment redirect result. |
| `AccountInfos` | [`List<AccountInfo>`](#account-info) | Optional | List of information about account balances before and after transaction. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | List of global messages that match the passenger's criteria for travel date, and destination will be displayed. |

##### Example (as JSON)

```json
{
  "messages": null,
  "pnr": null,
  "redirectInfo": null,
  "accountInfos": null,
  "advisories": null
}
```

#### Brand Label

Label to be used in brand description.

##### Class Name

`BrandLabel`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProgramId` | `String` | Optional | Program ID used for marketing campaigns. |
| `ProgramName` | `String` | Optional | Program name used for marketing campaigns. |
| `ProgramSystemCode` | `String` | Optional | Program system code. |
| `LanguageId` | `String` | Optional | Language ID in the format: LANG_COUNTRY where LANG is lowercase 2 to 8 language code<br> and (optional) COUNTRY is uppercase two-letter ISO-3166 code. |
| `MarketingText` | `String` | Optional | Simple brand label. |
| `BrandLabelUrl` | `String` | Optional | URL to brand description. |

##### Example (as JSON)

```json
{
  "programId": null,
  "programName": null,
  "programSystemCode": null,
  "languageId": null,
  "marketingText": null,
  "brandLabelUrl": null
}
```

#### Branded Fare Itinerary Offer Mapping

Branded combinability mapping.

##### Class Name

`BrandedFareItineraryOfferMapping`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `From` | `List<Integer>` | Optional | List of all 'from' offers. |
| `To` | `List<Integer>` | Optional | List of all 'to' offers. |
| `ToMapping` | [`BrandedFareItineraryOfferMapping`](#branded-fare-itinerary-offer-mapping) | Optional | - |

##### Example (as JSON)

```json
{
  "from": null,
  "to": null,
  "toMapping": null
}
```

#### Branded Results

Results grouped by flight list in brand columns.

##### Class Name

`BrandedResults`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryPartBrands` | [`List<List<ItineraryPartBrands>>`](#itinerary-part-brands) | Optional | List of offers grouped and sorted by brand. |

##### Example (as JSON)

```json
{
  "itineraryPartBrands": null
}
```

#### Breakdown Element

Breakdown Element.

##### Class Name

`BreakdownElement`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `String` | Optional | Label for this breakdown element in the form of machine readable or parsable code. Defined per product type so it can be used in translations. |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `PricePerUnit` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `BreakdownElementAssignment` | [`BreakdownElementAssignment`](#breakdown-element-assignment) | Optional | Assignment to the specific travel part and/or the passenger or passenger's type. |
| `SubElements` | [`List<BreakdownElement>`](#breakdown-element) | Optional | List of all breakdown prices for this element e.g. if this element is the total for taxes, 'subElements' will contain a list of elements with specific tax codes and corresponding prices. |

##### Example (as JSON)

```json
{
  "label": null,
  "price": null,
  "pricePerUnit": null,
  "breakdownElementAssignment": null,
  "subElements": null
}
```

#### Breakdown Element Assignment

Assignment to the specific travel part and/or the passenger or passenger's type.

##### Class Name

`BreakdownElementAssignment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |
| `Passenger` | [`Passenger`](#passenger) | Optional | Passenger. |
| `PassengerType` | [`PassengerType2`](#passenger-type-2) | Optional | Specifies type of the passenger for this breakdown element assignment. Total should be presented for all passengers with this type. |
| `Quantity` | `Integer` | Optional | Quantity of the same values existing in this assignment e.g. number of ancillaries with specific code etc. |
| `AdditionalProductInformation` | [`AbstractAdditionalProductInformation`](#abstract-additional-product-information) | Optional | Additional product information. |

##### Example (as JSON)

```json
{
  "travelPart": null,
  "passenger": null,
  "passengerType": null,
  "quantity": null,
  "additionalProductInformation": null
}
```

#### Breakdown Response

Provides breakdown for all products in current reservation.

##### Class Name

`BreakdownResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |
| `ItineraryInformation` | [`ItineraryInformation`](#itinerary-information) | Optional | Information about selected itinerary. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ProductBreakdowns` | [`List<ProductBreakdown>`](#product-breakdown) | Optional | List of per product breakdowns. |

##### Example (as JSON)

```json
{
  "messages": null,
  "itineraryInformation": null,
  "total": null,
  "productBreakdowns": null
}
```

#### Build Information

This model contains basic information about current build information. Useful for debugging and identification of the application instance.

##### Class Name

`BuildInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BuildNumber` | `String` | Optional | Build number of the current deployment. |
| `ReleaseName` | `String` | Optional | Release name of which build number is deployed. |
| `ConfigurationVersion` | `String` | Optional | Current configuration version (active or selected). |
| `DcApiVersion` | `String` | Optional | Current DC api version. |

##### Example (as JSON)

```json
{
  "buildNumber": null,
  "releaseName": null,
  "configurationVersion": null,
  "dcApiVersion": null
}
```

#### Bundle Item

Bundle item details.

##### Class Name

`BundleItem`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Bundle item code. |
| `GroupCode` | `String` | Optional | Bundle item group code. |

##### Example (as JSON)

```json
{
  "code": null,
  "groupCode": null
}
```

#### Bundle Prices

Contains the price for the whole itinerary including all itinerary parts where bundled price configuration is enabled.

##### Class Name

`BundlePrices`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Fare` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Taxes` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalWithoutDiscount` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `AvailableObFees` | [`List<PaxTypeObFeesAvailability>`](#pax-type-ob-fees-availability) | Optional | All available OB Fees for the whole itinerary for passenger types. |
| `TotalMandatoryObFees` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "fare": null,
  "taxes": null,
  "total": null,
  "totalWithoutDiscount": null,
  "availableObFees": null,
  "totalMandatoryObFees": null
}
```

#### Business Loyalty

Corporate Loyalty details.

##### Class Name

`BusinessLoyalty`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MemberId` | `String` | Optional | Corporate Loyalty member ID. |
| `ProgramId` | [`ProgramId`](#program-id) | Optional | Corporate Loyalty program name. |
| `Airline` | `String` | Optional | Corporate Loyalty airline code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). |

##### Example (as JSON)

```json
{
  "memberId": null,
  "programId": null,
  "airline": null
}
```

#### Cabin

Seat map cabin details.

##### Class Name

`Cabin`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Deck` | [`Deck`](#deck) | Optional | Deck type describing location of the deck. |
| `SeatColumns` | `List<String>` | Optional | Available seats columns in the cabin. |
| `SeatRows` | [`List<SeatRow>`](#seat-row) | Optional | List of seat rows. |
| `FirstRow` | `Integer` | Optional | Number of the first row. |
| `LastRow` | `Integer` | Optional | Number of the last row. |

##### Example (as JSON)

```json
{
  "deck": null,
  "seatColumns": null,
  "seatRows": null,
  "firstRow": null,
  "lastRow": null
}
```

#### Cancel Upgrade Offer Operation

Operation request for specific waitlisted upgrade offer and selected travel part for all passengers.

##### Class Name

`CancelUpgradeOfferOperation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Code of waitlisted upgrade offer. |
| `OfferSelectedForCancelation` | `Boolean` | Optional | Flag indicating if the waitlisted offer is selected for the cancelation, set to true if you want to cancel an upgrade offer. |
| `SelectedTravelPart` | [`SelectedTravelPart`](#selected-travel-part) | Optional | Selected travel part. |

##### Example (as JSON)

```json
{
  "code": null,
  "offerSelectedForCancelation": null,
  "selectedTravelPart": null
}
```

#### Cancel Upgrade Offer Operation Result

Cancel upgrade offer operation result.

##### Class Name

`CancelUpgradeOfferOperationResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning messages. |
| `Code` | `String` | Optional | Code of an upgrade offer. |
| `SelectedTravelPart` | [`SelectedTravelPart`](#selected-travel-part) | Optional | Selected travel part. |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger who concerns cancel upgrade offer operation, expressed as a positive integer. |
| `Successful` | `Boolean` | Optional | Cancel upgrade operation finished successfully. |

##### Example (as JSON)

```json
{
  "messages": null,
  "code": null,
  "selectedTravelPart": null,
  "passengerIndex": null,
  "successful": null
}
```

#### Cancel Upgrade Offer Request

Cancel upgrade offer operation request.

##### Class Name

`CancelUpgradeOfferRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CancelUpgradeOfferOperations` | [`List<CancelUpgradeOfferOperation>`](#cancel-upgrade-offer-operation) | Optional | List with details for cancel upgrade offer operations. |

##### Example (as JSON)

```json
{
  "cancelUpgradeOfferOperations": null
}
```

#### Cancel Upgrade Offer Request Result

Cancel upgrade offer request result.

##### Class Name

`CancelUpgradeOfferRequestResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CancelUpgradeOfferOperationResults` | [`List<CancelUpgradeOfferOperationResult>`](#cancel-upgrade-offer-operation-result) | Optional | List with results from cancel upgrade offer operations. |

##### Example (as JSON)

```json
{
  "cancelUpgradeOfferOperationResults": null
}
```

#### Cancel Upgrade Offers Result

Cancel upgrade offers result.

##### Class Name

`CancelUpgradeOffersResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning messages. |
| `Itinerary` | [`Itinerary`](#itinerary) | Optional | - |
| `Passengers` | [`List<AncillaryPassenger>`](#ancillary-passenger) | Optional | Passengers details associated with cancel upgrade offers. |
| `CancelUpgradeOffers` | [`List<UpgradeOffer>`](#upgrade-offer) | Optional | Cancel upgrade offers linking waitlisted upgrades with passengers and travel parts. |

##### Example (as JSON)

```json
{
  "messages": null,
  "itinerary": null,
  "passengers": null,
  "cancelUpgradeOffers": null
}
```

#### Cancel Upgrade Result

JSON representation of cancel upgrade result.

##### Class Name

`CancelUpgradeResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning and error messages list related to cancel upgrade result. |
| `Pnr` | [`Pnr`](#pnr) | Optional | PNR representation. |

##### Example (as JSON)

```json
{
  "messages": null,
  "pnr": null
}
```

#### Cancellation Confirm Result

Result of the cancellation confirm request. List refund amounts and refund targets.

##### Class Name

`CancellationConfirmResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Informational, warning and error messages related to cancellation result. |
| `CancelledReloc` | `String` | Optional | PNR of the cancelled booking. |
| `CancellationStatus` | `String` | Optional | Status of the cancell operation. |
| `TotalRefund` | [`BreakdownElement`](#breakdown-element) | Optional | - |
| `RefundDocumentInfoList` | [`List<RefundDocumentInfo>`](#refund-document-info) | Optional | Information about refunded documents, VCRs and EMDs. |
| `RefundTargets` | [`List<RefundTarget>`](#refund-target) | Optional | List of refund targets. |

##### Example (as JSON)

```json
{
  "messages": null,
  "cancelledReloc": null,
  "cancellationStatus": null,
  "totalRefund": null,
  "refundDocumentInfoList": null,
  "refundTargets": null
}
```

#### Cancellation Confirmation Data

Passenger's confirmation to proceed with cancellation. Travel bank details to be given if required.

##### Class Name

`CancellationConfirmationData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Confirmed` | `boolean` |  | Passeger’s confirmation. |
| `TravelBankLogin` | `String` | Optional | Travel Bank account login code. |
| `TravelBankPassword` | `String` | Optional | Travel Bank password. |
| `PaymentData` | [`CancellationPaymentData`](#cancellation-payment-data) | Optional | JSON representation of payment data for cancellation. |

##### Example (as JSON)

```json
{
  "confirmed": false,
  "travelBankLogin": null,
  "travelBankPassword": null,
  "paymentData": null
}
```

#### Cancellation Payment Data

JSON representation of payment data for cancellation.

##### Class Name

`CancellationPaymentData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payment` | [`Payment`](#payment) | Optional | - |
| `BillingData` | [`BillingData`](#billing-data) | Optional | Billing address information for the purchase. |

##### Example (as JSON)

```json
{
  "payment": null,
  "billingData": null
}
```

#### Cancellation Result

Result of the cancellation request. List refund amounts and refund targets. When refund is completed update with actual selected refund target and PNR.

##### Class Name

`CancellationResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CancelledReloc` | `String` | Optional | PNR of the cancelled booking. |
| `TotalRefund` | [`BreakdownElement`](#breakdown-element) | Optional | - |
| `RefundDocumentInfoList` | [`List<RefundDocumentInfo>`](#refund-document-info) | Optional | Information about refunded documents, VCRs and EMDs. |
| `RefundTargets` | [`List<RefundTarget>`](#refund-target) | Optional | Refund targets. |
| `Payments` | [`List<PaymentProduct>`](#payment-product) | Optional | Information about available forms of payment that can be used to pay for the cancellation fee if applicable. |

##### Example (as JSON)

```json
{
  "cancelledReloc": null,
  "totalRefund": null,
  "refundDocumentInfoList": null,
  "refundTargets": null,
  "payments": null
}
```

#### Capacity

Describes vehicle capacity for passengers and baggage.

##### Class Name

`Capacity`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Passengers` | `Integer` | Optional | Number of passengers that can be accommodated by this vehicle. |
| `Baggage` | `Integer` | Optional | Number of bags/suitcases that can be accommodated by this vehicle. |

##### Example (as JSON)

```json
{
  "passengers": null,
  "baggage": null
}
```

#### Car Availability Search

JSON representation of the car availability search.

##### Class Name

`CarAvailabilitySearch`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryOrigin` | `String` |  | Location code of the selected origin (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `PickUpDetail` | [`CarRentalLocation`](#car-rental-location) |  | Contains information about car pickup/dropoff depot. |
| `DropOffDetail` | [`CarRentalLocation`](#car-rental-location) |  | Contains information about car pickup/dropoff depot. |
| `DriversInfo` | [`DriversInfo`](#drivers-info) |  | Driver's information. |
| `CountryCode` | `String` | Optional | ISO country code (two letters) like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `Currency` | `String` | Optional | Three letter ISO currency code like https://en.wikipedia.org/wiki/ISO_4217. |
| `LanguageId` | `String` | Optional | Preferred language code. |
| `IpAddress` | `String` | Optional | Client's IP address. |

##### Example (as JSON)

```json
{
  "itineraryOrigin": "AUH",
  "pickUpDetail": null,
  "dropOffDetail": null,
  "driversInfo": null
}
```

#### Car Availability Search Response

Contains information about car availability search results.

##### Class Name

`CarAvailabilitySearchResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarOffers` | [`List<CarOffer>`](#car-offer) | Optional | List of rental car offers. |

##### Example (as JSON)

```json
{
  "carOffers": null
}
```

#### Car Depot Location

Contains all the information about car depot location.

##### Class Name

`CarDepotLocation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `String` |  | Name of the depot location. |
| `CarLocationId` | [`CarLocationId`](#car-location-id) | Optional | Contains information about car rental location. |
| `AtAirport` | `Boolean` | Optional | Flag indicating if the depot is at the airport or not. |
| `Address` | [`Address`](#address) | Optional | Passenger Contact Address. |
| `Phones` | [`List<Phone>`](#phone) | Optional | List of depot's available contact numbers. |
| `Emails` | `List<String>` | Optional | List of depot's available emails. |
| `CarRentalFacilityRole` | [`CarRentalFacilityRole`](#car-rental-facility-role) | Optional | Role of car rental facility. |

##### Example (as JSON)

```json
{
  "name": "Jersey - Airport"
}
```

#### Car Details Summary

Details of the rented vehicle.

##### Class Name

`CarDetailsSummary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AirCondition` | `Boolean` | Optional | Flag indicating if the air condition is present. |
| `CarType` | [`CarType`](#car-type) | Optional | Type of the vehicle. |
| `CarSize` | [`CarSize`](#car-size) | Optional | Size of the vehicle. |
| `TransmissionType` | [`TransmissionType`](#transmission-type) | Optional | Type of the transmission. |
| `FuelType` | [`FuelType`](#fuel-type) | Optional | Type of the fuel a vehicle's engine uses. |
| `CarDetailsCode` | `String` | Optional | Code summarizing the key features of a rented vehicle (ECAR: Economy 2/4 door auto drive car with air conditioning). The code is normally 4 characters long. |

##### Example (as JSON)

```json
{
  "airCondition": null,
  "carType": null,
  "carSize": null,
  "transmissionType": null,
  "fuelType": null,
  "carDetailsCode": null
}
```

#### Car Features

Contains the information about available car's features.

##### Class Name

`CarFeatures`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FuelType` | [`FuelType1`](#fuel-type-1) | Optional | Type of the fuel a vehicle's engine uses. |
| `NumberOfDoors` | `Integer` | Optional | The number of the vehicle's doors. |
| `TransmissionType` | [`TransmissionType1`](#transmission-type-1) | Optional | Type of the transmission. |
| `AirCondition` | `Boolean` | Optional | Flag indicating if air condition is present. |
| `DrivetrainType` | [`DrivetrainType`](#drivetrain-type) | Optional | Type of the drivetrain. |

##### Example (as JSON)

```json
{
  "fuelType": null,
  "numberOfDoors": null,
  "transmissionType": null,
  "airCondition": null,
  "drivetrainType": null
}
```

#### Car Info Model

Data of car availability response.

##### Class Name

`CarInfoModel`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Model` | `String` | Optional | Car model name. |
| `Features` | [`CarFeatures`](#car-features) | Optional | Contains the information about available car's features. |
| `VehicleSize` | [`VehicleSize`](#vehicle-size) | Optional | Size of the vehicle. |
| `Type` | [`Type6`](#type-6) | Optional | Type of the class model. |
| `ImageLink` | `String` | Optional | Image of the car model. |
| `Capacity` | [`Capacity`](#capacity) | Optional | Describes vehicle capacity for passengers and baggage. |
| `Code` | `String` | Optional | Code of the vehicle. |

##### Example (as JSON)

```json
{
  "model": null,
  "features": null,
  "vehicleSize": null,
  "type": null,
  "imageLink": null,
  "capacity": null,
  "code": null
}
```

#### Car Location Id

Contains information about car rental location.

##### Class Name

`CarLocationId`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Location code of the car depot - format depends on the codeContext. |
| `CodeContext` | `String` | Optional | Car service provider's context of the returned codes. |

##### Example (as JSON)

```json
{
  "code": null,
  "codeContext": null
}
```

#### Car Location Search

JSON representation of the car location search.

##### Class Name

`CarLocationSearch`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryOrigin` | `String` |  | Location code of the selected origin (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `CountryCode` | `String` | Optional | ISO country code (two letters) like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `City` | `String` | Optional | Name of the city. |
| `DestinationReferenceCode` | `String` | Optional | Airport code as an optional search criteria (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Currency` | `String` | Optional | Three letter ISO currency code like https://en.wikipedia.org/wiki/ISO_4217. |
| `LanguageId` | `String` | Optional | Preferred language code. |

##### Example (as JSON)

```json
{
  "itineraryOrigin": "AUH"
}
```

#### Car Location Search Result

Contains information about car location search results.

##### Class Name

`CarLocationSearchResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarRentalAreas` | [`List<CarRentalArea>`](#car-rental-area) | Optional | List of available car rental locations. |

##### Example (as JSON)

```json
{
  "carRentalAreas": null
}
```

#### Car Offer

Details regarding depots or other reference points for cars with car offers.

##### Class Name

`CarOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PickUpDateTime` | `LocalDateTime` | Optional | Car's pickup date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `DropOffDateTime` | `LocalDateTime` | Optional | Car's drop-off date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `PickUpLocation` | [`CarDepotLocation`](#car-depot-location) | Optional | Contains all the information about car depot location. |
| `DropOffLocation` | [`CarDepotLocation`](#car-depot-location) | Optional | Contains all the information about car depot location. |
| `PricedCars` | [`List<PricedCar>`](#priced-car) | Optional | List of car availability information. |
| `VendorInfo` | [`VendorInfo`](#vendor-info) | Optional | Details of the Vendor. |

##### Example (as JSON)

```json
{
  "pickUpDateTime": null,
  "dropOffDateTime": null,
  "pickUpLocation": null,
  "dropOffLocation": null,
  "pricedCars": null,
  "vendorInfo": null
}
```

#### Car Payment Summary

Payment summary for the car rental.

##### Class Name

`CarPaymentSummary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TotalPrice` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `RentalDays` | `Integer` | Optional | Number of days for which car has been rented. |
| `PaymentTimeType` | [`PaymentTimeType`](#payment-time-type) | Optional | Type of payment. |

##### Example (as JSON)

```json
{
  "totalPrice": null,
  "rentalDays": null,
  "paymentTimeType": null
}
```

#### Car Rental Area

Represents a location where one or more rental facilities can be located.

##### Class Name

`CarRentalArea`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RentalAreaName` | `String` | Optional | Name of the Rental Area. |
| `AtAirport` | `Boolean` | Optional | Flag indicating if the rental area is at the airport or not. |
| `Address` | [`Address`](#address) | Optional | Passenger Contact Address. |
| `CarRentalDepots` | [`List<CarDepotLocation>`](#car-depot-location) | Optional | Rental facilities available in the area. |
| `CarLocationId` | [`CarLocationId`](#car-location-id) | Optional | Contains information about car rental location. |

##### Example (as JSON)

```json
{
  "rentalAreaName": null,
  "atAirport": null,
  "address": null,
  "carRentalDepots": null,
  "carLocationId": null
}
```

#### Car Rental Location

Contains information about car pickup/dropoff depot.

##### Class Name

`CarRentalLocation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Date` | `LocalDateTime` | Optional | Pickup/drop-off date in the format: YYYY-MM-DD. |
| `CarLocationId` | [`CarLocationId`](#car-location-id) | Optional | Contains information about car rental location. |

##### Example (as JSON)

```json
{
  "date": null,
  "carLocationId": null
}
```

#### Car Reservation

JSON representation of the car reservation.

##### Class Name

`CarReservation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarPickUpLocation` | [`CarDepotLocation`](#car-depot-location) | Optional | Contains all the information about car depot location. |
| `DropOffLocation` | [`CarDepotLocation`](#car-depot-location) | Optional | Contains all the information about car depot location. |
| `PickUpDateTime` | `LocalDateTime` | Optional | Car's pickup date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `DropOffDateTime` | `LocalDateTime` | Optional | Car's drop-off date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `PricedCar` | [`PricedCar`](#priced-car) | Optional | Detailed description of the rental car, including its availability, features and all associated charges. |
| `PrimaryDriver` | [`Driver`](#driver) | Optional | Driver's details. |
| `VendorInfo` | [`VendorInfo`](#vendor-info) | Optional | Details of the Vendor. |

##### Example (as JSON)

```json
{
  "carPickUpLocation": null,
  "dropOffLocation": null,
  "pickUpDateTime": null,
  "dropOffDateTime": null,
  "pricedCar": null,
  "primaryDriver": null,
  "vendorInfo": null
}
```

#### Car Reservation Request

JSON representation of the car reservation request.

##### Class Name

`CarReservationRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Pnr` | `String` |  | PNR corresponding to the flight reservation. |
| `PickUpLocation` | [`CarDepotLocation`](#car-depot-location) |  | Contains all the information about car depot location. |
| `DropOffLocation` | [`CarDepotLocation`](#car-depot-location) |  | Contains all the information about car depot location. |
| `PickUpDateTime` | `LocalDateTime` |  | Car's pickup date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `DropOffDateTime` | `LocalDateTime` |  | Car's drop-off date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `DriversInfo` | [`DriversInfo`](#drivers-info) |  | Driver's information. |
| `PricedCar` | [`PricedCar`](#priced-car) |  | Detailed description of the rental car, including its availability, features and all associated charges. |
| `Payment` | [`CreditCard`](#credit-card) | Optional | - |
| `VendorInfo` | [`VendorInfo`](#vendor-info) | Optional | Details of the Vendor. |
| `CountryCode` | `String` | Optional | ISO country code (two letters) like: https://en.wikipedia.org/?title=ISO_3166-1. |

##### Example (as JSON)

```json
{
  "pnr": "QQAPRG",
  "pickUpLocation": {
    "name": "Jersey - Airport"
  },
  "dropOffLocation": {
    "name": "Jersey - Airport"
  },
  "pickUpDateTime": "2016-06-30T05:55:00",
  "dropOffDateTime": "2016-06-30T05:55:00",
  "driversInfo": null,
  "pricedCar": null
}
```

#### Car Reservation Response

JSON response of the car reservation request.

##### Class Name

`CarReservationResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning and error messages list related to the car booking result. |
| `CarReservation` | [`CarReservation`](#car-reservation) | Optional | JSON representation of the car reservation. |
| `ConfirmationIDs` | [`List<ConfirmationID>`](#confirmation-id) | Optional | Confirmation IDs returned from the Provider such as CarTrawler, OpenJaw, Datalex and/or Supplier such as DOLLAR, HERTZ etc. |

##### Example (as JSON)

```json
{
  "messages": null,
  "carReservation": null,
  "confirmationIDs": null
}
```

#### Car Reservation Summary

Summary of the car reservation.

##### Class Name

`CarReservationSummary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ConfirmationNumber` | `String` | Optional | Confirmation ID. |
| `PickupDateTime` | `LocalDateTime` | Optional | Car's pickup date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `DropOffDateTime` | `LocalDateTime` | Optional | Car's drop-off date and time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `CarPickUpLocation` | [`CarDepotLocation`](#car-depot-location) | Optional | Contains all the information about car depot location. |
| `DropOffLocation` | [`CarDepotLocation`](#car-depot-location) | Optional | Contains all the information about car depot location. |
| `CarDetailsSummary` | [`CarDetailsSummary`](#car-details-summary) | Optional | Details of the rented vehicle. |
| `VendorInfo` | [`VendorInfo`](#vendor-info) | Optional | Details of the Vendor. |
| `CarPaymentSummary` | [`CarPaymentSummary`](#car-payment-summary) | Optional | Payment summary for the car rental. |

##### Example (as JSON)

```json
{
  "confirmationNumber": null,
  "pickupDateTime": null,
  "dropOffDateTime": null,
  "carPickUpLocation": null,
  "dropOffLocation": null,
  "carDetailsSummary": null,
  "vendorInfo": null,
  "carPaymentSummary": null
}
```

#### Card Details

Credit card details.

##### Class Name

`CardDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MaskedNumber` | `String` | Optional | Masked card number. |
| `Code` | `String` | Optional | Card code. |
| `Status` | [`Status8`](#status-8) | Optional | Result of the failed authorization operation. |
| `FailureReason` | `String` | Optional | Cause of the failed authorization operation. |

##### Example (as JSON)

```json
{
  "maskedNumber": null,
  "code": null,
  "status": null,
  "failureReason": null
}
```

#### Cards Authorization Failure Details

Credit cards authorization failure details.

##### Class Name

`CardsAuthorizationFailureDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardsDetails` | [`List<CardDetails>`](#card-details) | Optional | Credit cards authorization failure details. |

##### Example (as JSON)

```json
{
  "cardsDetails": null
}
```

#### Carry on Baggage

Carryon Allowance Information for selected flights.

##### Class Name

`CarryOnBaggage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FreeBaggageAllowance` | [`FreeBaggageAllowance`](#free-baggage-allowance) | Optional | Baggage allowance information for selected flight. |
| `ExcessBaggage` | [`List<ExcessBaggage>`](#excess-baggage) | Optional | List of excess baggage allowance information for selected flights. |
| `AdditionalInfo` | `String` | Optional | Additional information related to carry on baggage. |

##### Example (as JSON)

```json
{
  "freeBaggageAllowance": null,
  "excessBaggage": null,
  "additionalInfo": null
}
```

#### Checked in Baggage

Checked in baggage information for selected flights.

##### Class Name

`CheckedInBaggage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FreeBaggageAllowance` | [`FreeBaggageAllowance`](#free-baggage-allowance) | Optional | Baggage allowance information for selected flight. |
| `ExcessBaggage` | [`List<ExcessBaggage>`](#excess-baggage) | Optional | List of excess baggage allowance information for selected flights. |

##### Example (as JSON)

```json
{
  "freeBaggageAllowance": null,
  "excessBaggage": null
}
```

#### Checked in Baggage Allowance

Checked in baggage allowance.

##### Class Name

`CheckedInBaggageAllowance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BaggageAllowanceDefinition` | [`List<BaggageAllowanceDef>`](#baggage-allowance-def) | Optional | List of baggage allowances for passengers. |

##### Example (as JSON)

```json
{
  "baggageAllowanceDefinition": null
}
```

#### Collect Additional Data Info

##### Class Name

`CollectAdditionalDataInfo`

##### Inherits From

[`RedirectInfo`](#redirect-info)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "transactionId": null,
  "@type": null
}
```

#### Collect Additional Data Return

##### Class Name

`CollectAdditionalDataReturn`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TransactionId` | `String` | Optional | Transaction ID associated with this payment. |
| `Received3rdPartyData` | [`Received3rdPartyData`](#received-3-rd-party-data) | Optional | Data obtained after returning from 3rd party redirection, required for the 2nd AFOP or Dynamic 3DS request. |

##### Example (as JSON)

```json
{
  "transactionId": null,
  "received3rdPartyData": null,
  "amount": null,
  "@type": null
}
```

#### Combinable Payments Result

Retrieve combinable fops result.

##### Class Name

`CombinablePaymentsResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SecondFops` | [`List<PaymentInfo>`](#payment-info) | Optional | List of combinable form of payment with residual values. |
| `Messages` | [`List<Message>`](#message) | Optional | List of additional messages which contain details about error, warning etc. |

##### Example (as JSON)

```json
{
  "secondFops": null,
  "messages": null
}
```

#### Company Details

Company details associated with the unique ID.

##### Class Name

`CompanyDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CompanyName` | `String` | Optional | Name of the company. |
| `Division` | `String` | Optional | The division name or ID with which the contact is associated. |
| `Department` | `String` | Optional | The department name or ID with which the contact is associated. |

##### Example (as JSON)

```json
{
  "companyName": null,
  "division": null,
  "department": null
}
```

#### Configuration Service Result

Return data about enabled json services, routes, etc.

##### Class Name

`ConfigurationServiceResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ServiceInfos` | [`List<ServiceInfo>`](#service-info) | Optional | Information about exposed services. |
| `Routes` | [`List<Route>`](#route) | Optional | List of routes (pairs of origin and destination) available for the storefront. |

##### Example (as JSON)

```json
{
  "serviceInfos": null,
  "routes": null
}
```

#### Confirmation ID

Confirmation ID returned from the Provider such as CarTrawler, OpenJaw, Datalex and/or Supplier such as DOLLAR, HERTZ etc.

##### Class Name

`ConfirmationID`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Value` | `String` | Optional | Confirmation ID. |
| `ConfirmationIDType` | [`ConfirmationIDType`](#confirmation-id-type) | Optional | Type of Provider's confirmation ID. |

##### Example (as JSON)

```json
{
  "value": null,
  "confirmationIDType": null
}
```

#### Connection Information

Connection information.

##### Class Name

`ConnectionInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Duration` | `Long` | Optional | The duration gap between two segments, expressed in minutes. |
| `ChangeOfAirport` | `Boolean` | Optional | Flag indicating change of airport. True in case of change of airport. |

##### Example (as JSON)

```json
{
  "duration": null,
  "changeOfAirport": null
}
```

#### Consent

Passenger's consent information.

##### Class Name

`Consent`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ConsentTypeCode` | `String` | Optional | Consent type code. |
| `Value` | [`Value`](#value) | Optional | Consent value. |
| `CampaignTypeCode` | `String` | Optional | Campaign type code. |

##### Example (as JSON)

```json
{
  "consentTypeCode": null,
  "value": null,
  "campaignTypeCode": null
}
```

#### Contact

Booker's contact information.

##### Class Name

`Contact`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | List of booker's contact emails. |
| `Phones` | [`List<Phone>`](#phone) | Optional | List of booker's contact phone numbers. |
| `Addresses` | [`List<Address>`](#address) | Optional | List of booker's contact address. |

##### Example (as JSON)

```json
{
  "emails": null,
  "phones": null,
  "addresses": null
}
```

#### Contact Details

Driver's contact details.

##### Class Name

`ContactDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Addresses` | [`List<Address>`](#address) | Optional | Addresses of the driver. |
| `Phones` | [`List<Phone>`](#phone) | Optional | Driver's available contact numbers. |
| `Emails` | `List<String>` | Optional | Driver's available emails. |

##### Example (as JSON)

```json
{
  "addresses": null,
  "phones": null,
  "emails": null
}
```

#### Context Info

Context information to specify contextual validation subtype.

##### Class Name

`ContextInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ContextValue` | `String` | Optional | Field value specified by context path, means contextual validation subtype. |
| `ContextPath` | `String` | Optional | Path indicating field to distinguishing validation context. |

##### Example (as JSON)

```json
{
  "contextValue": null,
  "contextPath": null
}
```

#### Contextual Validation Info

Contextual validation subtype.

##### Class Name

`ContextualValidationInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ContextInfo` | [`ContextInfo`](#context-info) | Optional | Context information to specify contextual validation subtype. |
| `Fields` | [`List<ObjectConfig>`](#object-config) | Optional | Configuration definition for object fields. |

##### Example (as JSON)

```json
{
  "@contextInfo": null,
  "fields": null
}
```

#### Coupon

Travel part couponStatus details associated with the reservation.

##### Class Name

`Coupon`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CouponNumber` | `Integer` | Optional | Coupon number. |
| `CouponStatus` | [`CouponStatus`](#coupon-status) | Optional | Coupon status. |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |

##### Example (as JSON)

```json
{
  "couponNumber": null,
  "couponStatus": null,
  "travelPart": null
}
```

#### Create Agency Profile Request

Input information of agency profile service.

##### Class Name

`CreateAgencyProfileRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyProfile` | [`AgencyProfile`](#agency-profile) | Optional | Agency's profile information. |
| `HasCreditLimitWithAirline` | `Boolean` | Optional | Flag indicating if the agency has a credit limit agreement with airline or not. This field may be disabled by configuration. In that case, setting this flag to true will result in a validation error. |

##### Example (as JSON)

```json
{
  "agencyProfile": null,
  "hasCreditLimitWithAirline": null
}
```

#### Create Agency Profile Response

Response information of profile service.

##### Class Name

`CreateAgencyProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyProfile` | [`AgencyProfile`](#agency-profile) | Optional | Agency's profile information. |
| `Result` | [`Result`](#result) | Optional | Status of the agency profile creation operation. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "agencyProfile": null,
  "result": null
}
```

#### Create Agent Profile Request

An input data for agent profile creation request.

##### Class Name

`CreateAgentProfileRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgentProfile` | [`AgentProfile`](#agent-profile) | Optional | Agent's profile information. |

##### Example (as JSON)

```json
{
  "agentProfile": null
}
```

#### Create Agent Profile Response

Response information for agent profile creation operation.

##### Class Name

`CreateAgentProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | [`Result1`](#result-1) | Optional | Status of the agent profile creation operation. The field is deprecated and will be removed in a subsequent major release. |
| `AgentProfile` | [`AgentProfile`](#agent-profile) | Optional | Agent's profile information. |

##### Example (as JSON)

```json
{
  "result": null,
  "agentProfile": null
}
```

#### Create Profile Request

Input information of profile service.

##### Class Name

`CreateProfileRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Profile` | [`UserProfile`](#user-profile) | Optional | Passenger's profile information. |
| `AutoLogin` | `Boolean` | Optional | Flag indicating that the passenger should be logged in to the profile after it is successfully created. This field may be disabled by configuration. In that case, setting this flag to true will result in a validation error. |

##### Example (as JSON)

```json
{
  "profile": null,
  "autoLogin": null
}
```

#### Create Profile Response

Response information of profile service.

##### Class Name

`CreateProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Profile` | [`UserProfile`](#user-profile) | Optional | Passenger's profile information. |
| `Result` | [`Result6`](#result-6) | Optional | User profile creation result status. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "profile": null,
  "result": null
}
```

#### Credit Card

##### Class Name

`CreditCard`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Number` | `String` | Optional | Credit Card number. |
| `Cvc` | `String` | Optional | Credit Card cvc/cvv security code. |
| `Pin` | `String` | Optional | Credit Card pin. |
| `HolderName` | `String` | Optional | Credit Card holder name as on card. |
| `HolderNameInDetail` | [`PassengerDetails`](#passenger-details) | Optional | Passenger's/Agency user's details. |
| `ExpirationDate` | `LocalDate` | Optional | Credit Card expiration date in the format: YYYY-MM-DD. |
| `CardCode` | `String` | Optional | Credit Card code. |
| `Installment` | [`Installment`](#installment) | Optional | Installment information for credit card. |
| `MobileNumber` | [`Phone`](#phone) | Optional | Phone details. |
| `RedirectData` | [`RedirectData`](#redirect-data) | Optional | 3ds details. |
| `Received3rdPartyData` | [`Received3rdPartyData`](#received-3-rd-party-data) | Optional | Data obtained after returning from 3rd party redirection, required for the 2nd AFOP or Dynamic 3DS request. |
| `SelectedDCCOffer` | [`DCCPaymentOffer`](#dcc-payment-offer) | Optional | Details of the Dynamic Currency Conversion (DCC) offer. |

##### Example (as JSON)

```json
{
  "number": null,
  "cvc": null,
  "pin": null,
  "holderName": null,
  "holderNameInDetail": null,
  "expirationDate": null,
  "cardCode": null,
  "installment": null,
  "mobileNumber": null,
  "redirectData": null,
  "received3rdPartyData": null,
  "selectedDCCOffer": null,
  "amount": null,
  "@type": null
}
```

#### Credit Card Refund

##### Class Name

`CreditCardRefund`

##### Inherits From

[`RefundTarget`](#refund-target)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### DCC Document Detail

Dynamic Currency Conversion(DCC) details of the passenger’s document.

##### Class Name

`DCCDocumentDetail`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DocumentType` | [`DocumentType2`](#document-type-2) | Optional | Type of the document. |
| `OriginalDocAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `CardCurrencyDocAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "documentType": null,
  "originalDocAmount": null,
  "cardCurrencyDocAmount": null
}
```

#### DCC Offer Response

Dynamic currency conversion (DCC) amount details.

##### Class Name

`DCCOfferResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DccPaymentOffers` | [`List<DCCPaymentOffer>`](#dcc-payment-offer) | Optional | Dynamic currency conversion (DCC) payment offers. |

##### Example (as JSON)

```json
{
  "dccPaymentOffers": null
}
```

#### DCC Passenger Document Detail

Dynamic Currency Conversion(DCC) details of the passenger and the passenger’s document.

##### Class Name

`DCCPassengerDocumentDetail`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger expressed as a positive integer. |
| `PassengerDetails` | [`PassengerDetails`](#passenger-details) | Optional | Passenger's/Agency user's details. |
| `DccDocumentDetails` | [`List<DCCDocumentDetail>`](#dcc-document-detail) | Optional | Dynamic Conversion(DCC) details of the passenger’s documents. |

##### Example (as JSON)

```json
{
  "passengerIndex": null,
  "passengerDetails": null,
  "dccDocumentDetails": null
}
```

#### DCC Payment Offer

Details of the Dynamic Currency Conversion (DCC) offer.

##### Class Name

`DCCPaymentOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OriginalCurrencyAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `CreditCardCurrencyAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `ExchangeRate` | `Double` | Optional | Exchange rate between the price in the original currency and price in the Credit Card currency (including the marginPercentRate). |
| `MarginPercentRate` | `Double` | Optional | The conversion margin interest rate. |
| `ExchangeRateSource` | `String` | Optional | The source of an exchange rate. |
| `SupplierId` | `String` | Optional | The merchant providing the dynamic currency conversion service. |
| `DccPassengerDocumentDetails` | [`List<DCCPassengerDocumentDetail>`](#dcc-passenger-document-detail) | Optional | Document details of passengers. |

##### Example (as JSON)

```json
{
  "originalCurrencyAmount": null,
  "creditCardCurrencyAmount": null,
  "exchangeRate": null,
  "marginPercentRate": null,
  "exchangeRateSource": null,
  "supplierId": null,
  "dccPassengerDocumentDetails": null
}
```

#### Deal Discount

Deal discount details.

##### Class Name

`DealDiscount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OfferName` | `String` | Optional | Offer name. |
| `TotalDiscount` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Percentage` | `Double` | Optional | Discount percentage. |

##### Example (as JSON)

```json
{
  "offerName": null,
  "totalDiscount": null,
  "percentage": null
}
```

#### Direct Debit

##### Class Name

`DirectDebit`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountNumber` | `String` | Optional | Bank account number. Required for ELV transaction. |
| `CountryCode` | `String` | Optional | Code of the country where the bank is located (two letters ISO country code like : https://en.wikipedia.org/?title=ISO_3166-1). |
| `SortCode` | `String` | Optional | Six digit code that identifies the bank and the branch where account is held. Required for ELV transaction. |
| `AccountHolder` | `String` | Optional | Bank account holder's name. |
| `IbanNumber` | `String` | Optional | ISO compliant IBAN number. |
| `BicCode` | `String` | Optional | Business Identifier Code (SWIFT code). |
| `BankName` | `String` | Optional | The name of account holder's bank. |

##### Example (as JSON)

```json
{
  "accountNumber": null,
  "countryCode": null,
  "sortCode": null,
  "accountHolder": null,
  "ibanNumber": null,
  "bicCode": null,
  "bankName": null,
  "amount": null,
  "@type": null
}
```

#### Discount

JSON representation of the select flights discount parameter.

##### Class Name

`Discount`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "@type": null
}
```

#### Discount Info

Discount info details.

##### Class Name

`DiscountInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OfferName` | `String` | Optional | Discount offer name. |
| `Percentage` | `Double` | Optional | Discount percentage. |
| `OriginalPrices` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalDiscount` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "offerName": null,
  "percentage": null,
  "originalPrices": null,
  "totalDiscount": null
}
```

#### Distance

The distance limit that the rented vehicle can make free of charge per unit.

##### Class Name

`Distance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Unit` | [`Unit`](#unit) | Optional | Unit of the distance. |
| `Limit` | `Integer` | Optional | Defined limit. |
| `Unlimited` | `Boolean` | Optional | Flag indicating that there is no limit on distance. If set to true - both unit and limit are not present. |

##### Example (as JSON)

```json
{
  "unit": null,
  "limit": null,
  "unlimited": null
}
```

#### Distance Restriction

Distance restriction defined for the rented vehicle.

##### Class Name

`DistanceRestriction`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Period` | [`Period`](#period) | Optional | Time period for which the restriction is defined. |
| `Distance` | [`Distance`](#distance) | Optional | The distance limit that the rented vehicle can make free of charge per unit. |

##### Example (as JSON)

```json
{
  "period": null,
  "distance": null
}
```

#### Document

Document information associated with reservation.

##### Class Name

`Document`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DocumentDetails` | [`DocumentDetails`](#document-details) | Optional | Contains information about electronic documents: VCR or EMD. |
| `Passenger` | [`Passenger`](#passenger) | Optional | Passenger. |
| `Coupons` | [`List<Coupon>`](#coupon) | Optional | List of coupons associated with the document. |

##### Example (as JSON)

```json
{
  "documentDetails": null,
  "passenger": null,
  "coupons": null
}
```

#### Document Details

Contains information about electronic documents: VCR or EMD.

##### Class Name

`DocumentDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DocumentType` | [`DocumentType1`](#document-type-1) | Optional | Document type. |
| `DocumentNumber` | `String` | Optional | Document number. |
| `AdditionalDetails` | [`List<AdditionalDetails>`](#additional-details) | Optional | Additional details of air extras assigned to EMD. |

##### Example (as JSON)

```json
{
  "documentType": null,
  "documentNumber": null,
  "additionalDetails": null
}
```

#### Document Payment Details

Document payments detail.

##### Class Name

`DocumentPaymentDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Document` | [`Document`](#document) | Optional | Document information associated with reservation. |
| `Endorsements` | `List<String>` | Optional | List of document's endorsements. |
| `TourCode` | `String` | Optional | Tour code. |
| `Payments` | [`List<PnrPayment>`](#pnr-payment) | Optional | List of payments associated with the document. |
| `PriceBreakdown` | [`BreakdownElement`](#breakdown-element) | Optional | Breakdown Element. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "document": null,
  "endorsements": null,
  "tourCode": null,
  "payments": null,
  "priceBreakdown": null,
  "total": null
}
```

#### Driver

Driver's details.

##### Class Name

`Driver`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DriverAge` | `Integer` | Optional | Driver's age (expressed in years). |
| `DriverName` | [`PassengerName`](#passenger-name) | Optional | Passenger name information. |

##### Example (as JSON)

```json
{
  "driverAge": null,
  "driverName": null
}
```

#### Drivers Info

Driver's information.

##### Class Name

`DriversInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PrimaryDriver` | [`Driver`](#driver) | Optional | Driver's details. |
| `Drivers` | [`List<Driver>`](#driver) | Optional | List of secondary drivers. It might be the list of all eligible passengers that want to drive, excluding the primary driver. |
| `PrimaryDriverCitizenship` | `String` | Optional | Primary driver's citizenship ISO country code (two letters) like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `ContactDetails` | [`ContactDetails`](#contact-details) | Optional | Driver's contact details. |

##### Example (as JSON)

```json
{
  "primaryDriver": null,
  "drivers": null,
  "primaryDriverCitizenship": null,
  "contactDetails": null
}
```

#### Embargo Information

Embargo information for selected flights.

##### Class Name

`EmbargoInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AirlineIataCode` | `String` | Optional | Airline IATA Code like http://www.iata.org/about/members/pages/airline-list.aspx?All=true. |
| `RestrictionList` | `List<String>` | Optional | List of embargo restrictions. |

##### Example (as JSON)

```json
{
  "airlineIataCode": null,
  "restrictionList": null
}
```

#### Excess Baggage

Excess baggage allowance information for selected flights.

##### Class Name

`ExcessBaggage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BagPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `BaggageRestriction` | [`BaggageRestriction`](#baggage-restriction) | Optional | - |
| `AllowedStatus` | [`AllowedStatus`](#allowed-status) | Optional | Returns the baggage status. |

##### Example (as JSON)

```json
{
  "bagPrice": null,
  "baggageRestriction": null,
  "allowedStatus": null
}
```

#### Exchange Breakdown Response

Provides breakdown for all products in current exchange.

##### Class Name

`ExchangeBreakdownResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryInformation` | [`ItineraryInformation`](#itinerary-information) | Optional | Information about selected itinerary. |
| `OriginalBookingProductBreakdown` | [`List<ProductBreakdown>`](#product-breakdown) | Optional | List of products (with their price breakdown) from the original booking. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ProductBreakdowns` | [`List<ProductBreakdown>`](#product-breakdown) | Optional | List of per product breakdowns. |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |

##### Example (as JSON)

```json
{
  "itineraryInformation": null,
  "originalBookingProductBreakdown": null,
  "total": null,
  "productBreakdowns": null,
  "messages": null
}
```

#### External Login Data

Data required to log in and view agency credit limit information externally.

##### Class Name

`ExternalLoginData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Url` | `String` | Optional | URL address to agency's credit limit external system. |
| `LoginID` | `String` | Optional | Login identifier to the account in agency's credit limit external system. |
| `PasswordHash` | `String` | Optional | Hashed password to the account in agency's credit limit external system. |

##### Example (as JSON)

```json
{
  "url": null,
  "loginID": null,
  "passwordHash": null
}
```

#### External Product

Price breakdown information of an external product for example car, hotel and insurance.

##### Class Name

`ExternalProduct`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the external product. |
| `IncludeInTotal` | `Boolean` | Optional | Flag indicating if the amount should be included in the total payable amount in the cart. |
| `Breakdown` | [`ProductBreakdown`](#product-breakdown) | Optional | Test. |

##### Example (as JSON)

```json
{
  "name": null,
  "includeInTotal": null,
  "breakdown": null
}
```

#### Fare Basis Rules

Fare rules for a specific fare basis code.

##### Class Name

`FareBasisRules`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FareBasis` | `String` | Optional | Fare basis code. |
| `FareRules` | [`List<FareRule>`](#fare-rule) | Optional | Fare rules list for fare basis. |

##### Example (as JSON)

```json
{
  "fareBasis": null,
  "fareRules": null
}
```

#### Fare Family

Brand information. Contains all information about available brands. Referenced in flight by brand ID.

##### Class Name

`FareFamily`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BrandId` | `String` | Optional | Fare Family identifier. |
| `BrandLabel` | [`List<BrandLabel>`](#brand-label) | Optional | List of brand labels associated with this brand (per campaign/program ID). |
| `BrandText` | `String` | Optional | Simple brand text in the default language. |
| `MarketingTexts` | [`List<MarketingText>`](#marketing-text) | Optional | List of different marketing text associated with this brand. (per campaign/program ID). |
| `BrandAncillaries` | [`FlightAncillaries`](#flight-ancillaries) | Optional | Contains list of ancillaries available to brand and/or flight. |
| `FareFamilyRemarkRPH` | `Integer` | Optional | Technical field containing index of a brand that was stored in the PNR. Not relevant to the UI or to the search response. |

##### Example (as JSON)

```json
{
  "brandId": null,
  "brandLabel": null,
  "brandText": null,
  "marketingTexts": null,
  "brandAncillaries": null,
  "fareFamilyRemarkRPH": null
}
```

#### Fare Rule

Fare rule information retrieved from GDS.

##### Class Name

`FareRule`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | `String` | Optional | GDS category. |
| `RuleCode` | `String` | Optional | Code of the fare rule. |
| `RuleText` | `String` | Optional | The message text of the rule. |

##### Example (as JSON)

```json
{
  "category": null,
  "ruleCode": null,
  "ruleText": null
}
```

#### Fare Rules Result

Result for retrieving fare rules.

##### Class Name

`FareRulesResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentFareRules` | [`List<SegmentFareRules>`](#segment-fare-rules) | Optional | Basis of fare rules for every travel part. |

##### Example (as JSON)

```json
{
  "segmentFareRules": null
}
```

#### First Payment

Information about the payment code and amount to pay.

##### Class Name

`FirstPayment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentCode` | `String` | Optional | Unique and more specific payment code. |
| `Amount` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "paymentCode": null,
  "amount": null
}
```

#### Fixed Base Fare

##### Class Name

`FixedBaseFare`

##### Inherits From

[`Discount`](#discount)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BaseFare` | `Double` | Optional | Fixed base fare (excluding taxes) which will replace the original fare. |

##### Example (as JSON)

```json
{
  "baseFare": null,
  "@type": null
}
```

#### Flight

Flight details.

##### Class Name

`Flight`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightNumber` | `Integer` | Optional | Flight number. |
| `OperatingFlightNumber` | `Integer` | Optional | Operating flight number. |
| `AirlineCode` | `String` | Optional | Marketing airline two letter code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). |
| `OperatingAirlineCode` | `String` | Optional | Operating airline two letter code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). |
| `DisclosureAirlineCode` | `String` | Optional | Disclosure airline two letter code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). Code that identifies (discloses) the codeshare airline that operates the flight. This code can be different from the marketing or operating airline codes. |
| `StopAirports` | [`List<StopAirport>`](#stop-airport) | Optional | Stop airports associated with this flight. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | Marketing messages pertaining to the specific flight. |
| `ChangeOfGauge` | `Boolean` | Optional | Flag indicating if this flight has a change of gauge. |
| `DepartureTerminal` | `String` | Optional | Departure terminal. |
| `ArrivalTerminal` | `String` | Optional | Arrival terminal. |

##### Example (as JSON)

```json
{
  "flightNumber": null,
  "operatingFlightNumber": null,
  "airlineCode": null,
  "operatingAirlineCode": null,
  "disclosureAirlineCode": null,
  "stopAirports": null,
  "advisories": null,
  "changeOfGauge": null,
  "departureTerminal": null,
  "arrivalTerminal": null
}
```

#### Flight Ancillaries

Contains list of ancillaries available to brand and/or flight.

##### Class Name

`FlightAncillaries`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightAncillary` | [`List<FlightAncillary>`](#flight-ancillary) | Optional | Actual list of ancillaries. |

##### Example (as JSON)

```json
{
  "flightAncillary": null
}
```

#### Flight Ancillary

Information about ancillary available for a specific flight.

##### Class Name

`FlightAncillary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `String` | Optional | ID of this flight ancillary. |
| `SubCode` | `String` | Optional | ATPCO sub-code for the ancillary. |

##### Example (as JSON)

```json
{
  "id": null,
  "subCode": null
}
```

#### Flight Info

Flight details.

##### Class Name

`FlightInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightNumber` | `Integer` | Optional | Flight number. |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time, this is local to the origin airport, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `Arrival` | `LocalDateTime` | Optional | Arrival date time, this is local to the destination airport, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `OperatingCarrier` | `String` | Optional | Operating carrier. |
| `EquipmentType` | `String` | Optional | Equipment type. |
| `NumberOfStops` | `Integer` | Optional | Number of stops. |
| `Duration` | `Long` | Optional | Flight duration expressed in minutes |

##### Example (as JSON)

```json
{
  "flightNumber": null,
  "origin": null,
  "destination": null,
  "departure": null,
  "arrival": null,
  "operatingCarrier": null,
  "equipmentType": null,
  "numberOfStops": null,
  "duration": null
}
```

#### Flight Leg Info

Flight leg information.

##### Class Name

`FlightLegInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightStatus` | [`FlightStatus`](#flight-status-1) | Optional | Flight status. |
| `AirportCode` | `String` | Optional | Airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Terminal` | `String` | Optional | Terminal information. |
| `Gate` | `String` | Optional | Gate information. |
| `ScheduledDateTime` | `LocalDateTime` | Optional | Scheduled flight date time, in the format: YYYY-MM-DD'T'HH:MM:SS |
| `EstimatedDateTime` | `LocalDateTime` | Optional | Estimated flight date time, in the format: YYYY-MM-DD'T'HH:MM:SS |
| `ActualDateTime` | `LocalDateTime` | Optional | Actual flight date time, in the format: YYYY-MM-DD'T'HH:MM:SS |
| `BaggageClaimAreaCode` | `String` | Optional | Baggage claim area code. |

##### Example (as JSON)

```json
{
  "flightStatus": null,
  "airportCode": null,
  "terminal": null,
  "gate": null,
  "scheduledDateTime": null,
  "estimatedDateTime": null,
  "actualDateTime": null,
  "baggageClaimAreaCode": null
}
```

#### Flight Schedule

Flight schedule.

##### Class Name

`FlightSchedule`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Flights` | [`List<FlightInfo>`](#flight-info) | Optional | Flight information for segment(s) of the leg. |
| `OperatingDays` | [`List<OperatingDay>`](#operating-day) | Optional | Flight days availabilities. |
| `TotalDuration` | `Long` | Optional | Total flight duration time expressed in minutes. |
| `TotalStops` | `Integer` | Optional | Total number of stops. |

##### Example (as JSON)

```json
{
  "flights": null,
  "operatingDays": null,
  "totalDuration": null,
  "totalStops": null
}
```

#### Flight Schedule Result

Flight schedule result.

##### Class Name

`FlightScheduleResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightSchedules` | [`List<FlightSchedule>`](#flight-schedule) | Optional | List of flight schedules. |

##### Example (as JSON)

```json
{
  "flightSchedules": null
}
```

#### Flight Selection Options

Provides additional options during flight selection.

##### Class Name

`FlightSelectionOptions`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AirCustomPricing` | [`AirCustomPricing`](#air-custom-pricing) | Optional | Custom pricing details for selected itinerary supporting custom discount at itinerary part/itinerary level, tax override and endorsement text addition to booking. |

##### Example (as JSON)

```json
{
  "airCustomPricing": null
}
```

#### Flight Status Info

Flight status information details.

##### Class Name

`FlightStatusInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DepartureInfo` | [`FlightLegInfo`](#flight-leg-info) | Optional | Flight leg information. |
| `ArrivalInfo` | [`FlightLegInfo`](#flight-leg-info) | Optional | Flight leg information. |

##### Example (as JSON)

```json
{
  "departureInfo": null,
  "arrivalInfo": null
}
```

#### Flight Status Result

Flight status details.

##### Class Name

`FlightStatusResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightNumber` | `Integer` | Optional | Flight number. |
| `Date` | `LocalDate` | Optional | Flight date in the format: YYYY-MM-DD. |
| `AirlineCode` | `String` | Optional | Marketing airline two letter code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). |
| `Flights` | [`List<FlightStatusInfo>`](#flight-status-info) | Optional | List of flight(s) associated with flight number and requested date. |

##### Example (as JSON)

```json
{
  "flightNumber": null,
  "date": null,
  "airlineCode": null,
  "flights": null
}
```

#### Fop Refund Data

Form of payment and amount information for refund in Exchange and MTO.

##### Class Name

`FopRefundData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FopNumber` | `String` | Optional | Masked form of the payment number. |
| `FopCode` | `String` | Optional | Form of the payment code. |
| `RefundValue` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `Vcr` | `Boolean` | Optional | Flag indicating if the refund is made to the VCR. |
| `Emd` | `Boolean` | Optional | Flag indicating if the refund is made to the EMD. |
| `AccountBalanceInfo` | [`AccountBalanceInfo`](#account-balance-info) | Optional | Account balance info before and after transaction. |

##### Example (as JSON)

```json
{
  "fopNumber": null,
  "fopCode": null,
  "refundValue": null,
  "vcr": null,
  "emd": null,
  "accountBalanceInfo": null
}
```

#### Fraud Check Result

Fraud check result data.

##### Class Name

`FraudCheckResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FraudCheckStatus` | [`FraudCheckStatus`](#fraud-check-status) | Optional | Fraud check status. |
| `ShouldPresentCard` | `Boolean` | Optional | Present credit card indicator. |

##### Example (as JSON)

```json
{
  "fraudCheckStatus": null,
  "shouldPresentCard": null
}
```

#### Fraud Net Data

Additional data about the user browser, used by Fraud check providers to validate transaction.

##### Class Name

`FraudNetData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `HttpHeaders` | `Map<String, String>` | Optional | Http headers. |
| `DeviceFingerPrintId` | `String` | Optional | Device finger print ID. |
| `Timestamp` | `LocalDateTime` | Optional | Point of Sale date and time of the purchase passed for the Fraud check operation in format: YYYY-MM-DD. |
| `IpAddress` | `String` | Optional | The user IP address passed for the Fraud Check operation. |
| `TransactionType` | `String` | Optional | Transaction name. |
| `FrequentFlyerInfo` | [`FrequentFlyerMemberInfo`](#frequent-flyer-member-info) | Optional | Frequent Flyer information. |

##### Example (as JSON)

```json
{
  "httpHeaders": null,
  "deviceFingerPrintId": null,
  "timestamp": null,
  "ipAddress": null,
  "transactionType": null,
  "frequentFlyerInfo": null
}
```

#### Free Baggage Allowance

Baggage allowance information for selected flight.

##### Class Name

`FreeBaggageAllowance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TotalUnits` | `String` | Optional | Free baggage information disclosure. |
| `BaggageRestrictions` | [`List<BaggageRestriction>`](#baggage-restriction) | Optional | Baggage name, number of units, size and weight restrictions. |
| `TotalWeight` | `String` | Optional | Total weight allowed on the flight. |

##### Example (as JSON)

```json
{
  "totalUnits": null,
  "baggageRestrictions": null,
  "totalWeight": null
}
```

#### Frequent Flyer

Frequent Flyer details.

##### Class Name

`FrequentFlyer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Airline` | `String` | Optional | Frequent Flyer account airline code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?All=true). |
| `MarketingCarrier` | `String` | Optional | Marketing carrier. |
| `Number` | `String` | Optional | Frequent Flyer number. |
| `TierLevel` | `String` | Optional | Frequent Flyer tier level. |
| `TierNumber` | `Integer` | Optional | Frequent Flyer tier number. |

##### Example (as JSON)

```json
{
  "airline": null,
  "marketingCarrier": null,
  "number": null,
  "tierLevel": null,
  "tierNumber": null
}
```

#### Frequent Flyer Details

Frequent Flyer's Details.

##### Class Name

`FrequentFlyerDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Airline` | `String` | Optional | Frequent Flyer account airline code (IATA code like http://www.iata.org/about/members/Pages/airline-list.aspx?Alltrue). |
| `MembershipID` | `String` | Optional | Frequent Flyer membership ID. |
| `MembershipLevelTypeCode` | `String` | Optional | Frequent Flyer membership level type code. |
| `MembershipLevelValue` | `String` | Optional | Frequent Flyer membership level value. |
| `AccountBalance` | `Integer` | Optional | Frequent Flyer account balance. |
| `MembershipStartDate` | `String` | Optional | Frequent Flyer membership start date in format: YYYY-MM-DD. |

##### Example (as JSON)

```json
{
  "airline": null,
  "membershipID": null,
  "membershipLevelTypeCode": null,
  "membershipLevelValue": null,
  "accountBalance": null,
  "membershipStartDate": null
}
```

#### Frequent Flyer Member Info

Frequent Flyer information.

##### Class Name

`FrequentFlyerMemberInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MemberName` | [`PassengerDetails`](#passenger-details) | Optional | Passenger's/Agency user's details. |
| `AddressDetails` | [`AddressDetails`](#address-details) | Optional | Passenger's Address Information. |
| `Phone` | [`Phone`](#phone) | Optional | Phone details. |
| `CurrentBalance` | `Integer` | Optional | Current balance of award miles. |
| `LoggedMemberId` | `String` | Optional | Logged in member id. |
| `Email` | `String` | Optional | Email address of the logged in user. |
| `TierLevel` | `String` | Optional | Logged in user's frequent flyer member level. |
| `TierStatus` | `String` | Optional | Logged in user's frequent flyer status. |
| `IssueDate` | `LocalDate` | Optional | Issue date of FF account in the format: YYYY-MM-DD. |
| `MemberLoggedIn` | `Boolean` | Optional | - |

##### Example (as JSON)

```json
{
  "memberName": null,
  "addressDetails": null,
  "phone": null,
  "currentBalance": null,
  "loggedMemberId": null,
  "email": null,
  "tierLevel": null,
  "tierStatus": null,
  "issueDate": null,
  "memberLoggedIn": null
}
```

#### General Sales Tax Data

Passenger's General Sales Tax (GST) data.

##### Class Name

`GeneralSalesTaxData`

##### Fields

| Name | Type | Description |
|  --- | --- | --- |
| `Number` | `String` | General Sales Tax (GST) number. |
| `Company` | `String` | General sales tax (GST) company's name. |
| `Address` | [`AddressDetails`](#address-details) | Passenger's Address Information. |
| `Phones` | `List<String>` | General sales tax (GST) company’s business phones in format supported by Indian Goods and Sales Tax GSTP SSR. |
| `Email` | `String` | General sales tax (GST) company’s business email address. |

##### Example (as JSON)

```json
{
  "number": "22AAAAA0000A1Z5",
  "company": "IBM",
  "address": null,
  "phones": [
    "9103345229023",
    "910758222144"
  ],
  "email": "example@example.com"
}
```

#### Get Balance Result

Gets balance result.

##### Class Name

`GetBalanceResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Balance` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `ValidUntil` | `LocalDate` | Optional | Expiration date for the eVoucher in the format: YYYY-MM-DD. |
| `ValidFrom` | `LocalDate` | Optional | Commencing date for the eVoucher in the format: YYYY-MM-DD. |

##### Example (as JSON)

```json
{
  "balance": null,
  "validUntil": null,
  "validFrom": null
}
```

#### Get DCC Offer

Dynamic currency conversion (DCC) selected offer details.

##### Class Name

`GetDCCOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Payment` | [`List<Payment>`](#payment) | Optional | List of preferred payment/payments for the selected offering. |
| `CardNumber` | `String` |  | Number of the credit card. |
| `CardCode` | `String` |  | Credit card code. |
| `Amount` | [`Amount`](#amount) |  | Amount presenting class. |

##### Example (as JSON)

```json
{
  "cardNumber": "111111111115550",
  "cardCode": "AX",
  "amount": null
}
```

#### Hobby

Maintain user hobbies related information.

##### Class Name

`Hobby`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CategoryCode` | [`CategoryCode`](#category-code) | Optional | Hobby category code options. |
| `TypeCode` | [`TypeCode`](#type-code) | Optional | Hobby values code options. |

##### Example (as JSON)

```json
{
  "categoryCode": null,
  "typeCode": null
}
```

#### Hold Option

Available Book Now Pay Later option available for the current reservation.

##### Class Name

`HoldOption`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OptionId` | `String` | Optional | Hold option identifier. |
| `Type` | [`Type4`](#type-4) | Optional | Hold option type. |
| `Period` | `String` | Optional | Period of time when the booking will be on hold, ISO period format: P[n]Y[n]M[n]DT[n]H[n]M[n]S or P[n]W<br>[n] parameter supports only non decimal values.<br>The capital letters P, Y, M, W, D, T, H, M and S are designators for each of the date and time elements and are not replaced. |
| `Price` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `ProductPaymentCombinability` | [`ProductPaymentCombinability`](#product-payment-combinability) | Optional | All allowed payments broken down by payment type. |

##### Example (as JSON)

```json
{
  "optionId": null,
  "type": null,
  "period": null,
  "price": null,
  "productPaymentCombinability": null
}
```

#### Hold Options Result

On-hold options available for the selected itinerary.

##### Class Name

`HoldOptionsResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Warning messages for removing ancillaries and seats from on-hold booking. |
| `HoldOptions` | [`List<HoldOption>`](#hold-option) | Optional | List of on-hold options. |

##### Example (as JSON)

```json
{
  "messages": null,
  "holdOptions": null
}
```

#### Hold Payment

Payment data for Book Now Pay Later.

##### Class Name

`HoldPayment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentRequired` | `Boolean` | Optional | Flag indicating if payment is required or not. |
| `Payment` | [`List<Payment>`](#payment) | Optional | List with used payments. The request should contain at least one instance of /payment. |
| `BillingData` | [`BillingData`](#billing-data) | Optional | Billing address information for the purchase. |
| `LanguageForBooking` | `String` | Optional | Language code for the booking. |
| `FraudNetData` | [`FraudNetData`](#fraud-net-data) | Optional | Additional data about the user browser, used by Fraud check providers to validate transaction. |
| `RemarksAndSSRs` | [`RemarksAndSSRs`](#remarks-and-ss-rs) | Optional | Messages that can be added to the PNR. |
| `ProfileInput` | [`ProfileInput`](#profile-input) | Optional | Input information for profile created in the booking path. |
| `QueuePlacementData` | [`QueuePlacementData`](#queue-placement-data) | Optional | Queue number and prefatory instruction code used to place the PNR in a specific queue. |
| `HoldOptionId` | `String` | Optional | Hold option identifier. |

##### Example (as JSON)

```json
{
  "paymentRequired": null,
  "payment": null,
  "billingData": null,
  "languageForBooking": null,
  "fraudNetData": null,
  "remarksAndSSRs": null,
  "profileInput": null,
  "queuePlacementData": null,
  "holdOptionId": null
}
```

#### Hotel Reservation Summary

Summary of the hotel reservation.

##### Class Name

`HotelReservationSummary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TransactionNumber` | `String` | Optional | Hotel booking transaction number. |
| `CheckinDate` | `LocalDate` | Optional | Check-in date in the format: YYYY-MM-DD. |
| `CheckoutDate` | `LocalDate` | Optional | Check-out date in the format: YYYY-MM-DD. |
| `HotelName` | `String` | Optional | Hotel name. |
| `HotelAddress` | `String` | Optional | Hotel address. |
| `RoomTypeId` | `String` | Optional | Hotel room type id. |
| `RoomCount` | `Integer` | Optional | Total number of booked rooms. |
| `AdultCount` | `Integer` | Optional | Total number of adults. |
| `ChildCount` | `Integer` | Optional | Total number of children. |
| `TotalPrice` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "transactionNumber": null,
  "checkinDate": null,
  "checkoutDate": null,
  "hotelName": null,
  "hotelAddress": null,
  "roomTypeId": null,
  "roomCount": null,
  "adultCount": null,
  "childCount": null,
  "totalPrice": null
}
```

#### Installment

Installment information for credit card.

##### Class Name

`Installment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InstallmentId` | `String` | Optional | Installment ID. Used when installment source in payment options service is PAYMENT_PROVIDER. It should not be present when installment source in payment options service is CONFIGURATION. |
| `BankName` | `String` | Optional | Installment bank name. Used when installment source in payment options service is CONFIGURATION. It should not be present when installment source in payment options service is PAYMENT_PROVIDER. |
| `Months` | `Integer` | Optional | Selected amount of monthly installments (available options are configurable). Used when installment source in payment options service is CONFIGURATION. It should not be present when installment source in payment options service is PAYMENT_PROVIDER. |

##### Example (as JSON)

```json
{
  "installmentId": null,
  "bankName": null,
  "months": null
}
```

#### Installment Details

##### Class Name

`InstallmentDetails`

##### Inherits From

[`AdditionalPaymentDetails`](#additional-payment-details)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InstallmentsSource` | [`InstallmentsSource`](#installments-source) | Optional | Source of installments. |
| `InstallmentOptions` | [`List<InstallmentOption>`](#installment-option) | Optional | List of available installment options. |

##### Example (as JSON)

```json
{
  "installmentsSource": null,
  "installmentOptions": null,
  "@type": null
}
```

#### Installment Option

Information regarding installments.

##### Class Name

`InstallmentOption`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BankName` | `String` | Optional | Name of the bank. |
| `MonthOptions` | `List<Integer>` | Optional | Available amounts of monthly installments. |

##### Example (as JSON)

```json
{
  "bankName": null,
  "monthOptions": null
}
```

#### Installments Request

Installment request.

##### Class Name

`InstallmentsRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardCode` | `String` |  | Credit card code. |
| `CardBIN` | `String` | Optional | Credit card number or leading four/six digits of the card number (bank identification number). |

##### Example (as JSON)

```json
{
  "cardCode": "AX"
}
```

#### Installments Response

Installments response.

##### Class Name

`InstallmentsResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CardCode` | `String` | Optional | Credit card code. |
| `PaymentType` | [`PaymentType1`](#payment-type-1) | Optional | Payment type. |
| `Bin` | `String` | Optional | Leading four/six digits of the credit card number (bank identification number). |
| `Currency` | `String` | Optional | Three letter ISO currency code like https://en.wikipedia.org/wiki/ISO_4217. |
| `InstallmentOptions` | [`List<PaymentQueryInstallmentOption>`](#payment-query-installment-option) | Optional | List of available installment options. |

##### Example (as JSON)

```json
{
  "cardCode": null,
  "paymentType": null,
  "bin": null,
  "currency": null,
  "installmentOptions": null
}
```

#### Insurance Information

Insurance confirmation details.

##### Class Name

`InsuranceInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PolicyNumber` | `String` | Optional | Insurance confirmation number. |

##### Example (as JSON)

```json
{
  "policyNumber": null
}
```

#### Insurance Offer

Insurance offer details.

##### Class Name

`InsuranceOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductID` | `String` | Optional | Product code that identifies an insurance offer. |
| `SupplierCode` | `String` | Optional | Supplier Code that identifies the Insurance in the suppliers system. |
| `ProductName` | `String` | Optional | Name of an insurance offer. |
| `ProductDescriptionURL` | `String` | Optional | URL providing a description of the product. |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "productID": null,
  "supplierCode": null,
  "productName": null,
  "productDescriptionURL": null,
  "price": null
}
```

#### Insurance Offers

Insurance offers available.

##### Class Name

`InsuranceOffers`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InsuranceOffers` | [`List<InsuranceOffer>`](#insurance-offer) | Optional | List of insurance offers and their details. |

##### Example (as JSON)

```json
{
  "insuranceOffers": null
}
```

#### Irop Response

Irop response.

##### Class Name

`IropResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning and error messages related to accepting segments. |
| `AcceptNewSegmentResult` | [`AcceptNewSegmentResult`](#accept-new-segment-result) | Optional | Result for revalidate segments with SC(Schedule change) status and mirror WK segment status. |
| `Pnr` | [`Pnr`](#pnr) | Optional | PNR representation. |

##### Example (as JSON)

```json
{
  "messages": null,
  "acceptNewSegmentResult": null,
  "pnr": null
}
```

#### Itinerary

##### Class Name

`Itinerary`

##### Inherits From

[`TravelPart`](#travel-part)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryParts` | [`List<ItineraryPart>`](#itinerary-part) | Optional | List of itinerary parts (legs). In case of the Round Trip flight: SYD - MEL and MEL - SYD, SYD - MEL is one itinerary part. |

##### Example (as JSON)

```json
{
  "itineraryParts": null,
  "@type": null
}
```

#### Itinerary Information

Information about selected itinerary.

##### Class Name

`ItineraryInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Itinerary` | [`Itinerary`](#itinerary) | Optional | - |
| `PromoCodesUsed` | `List<String>` | Optional | Promo codes used to obtain current offers. |
| `OffersSelected` | [`List<OfferWithoutPrice>`](#offer-without-price) | Optional | Selected offers from search results. |
| `Passengers` | [`Passengers`](#passengers) | Optional | List of passengers. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | Global messages that match the passenger's criteria for travel date, and destination will be displayed. |

##### Example (as JSON)

```json
{
  "itinerary": null,
  "promoCodesUsed": null,
  "offersSelected": null,
  "passengers": null,
  "advisories": null
}
```

#### Itinerary Part

##### Class Name

`ItineraryPart`

##### Inherits From

[`TravelPart`](#travel-part)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Segments` | [`List<Segment>`](#segment) | Optional | List of itinerary parts (legs). In case of the Round Trip flight: SYD - MEL and MEL - SYD, SYD - MEL is one itinerary part. |
| `Stops` | `Integer` | Optional | Number of stops in the itinerary part. |
| `TotalDuration` | `Long` | Optional | Total flight duration expressed in minutes. |
| `ConnectionInformations` | [`List<ConnectionInformation>`](#connection-information) | Optional | Connection information in case of multiple segment in a itinerary. |
| `BookingClass` | `String` | Optional | Booking Class at ItineraryPart level that contains same value for all segments. In case of the disparate CabinClasses across segments (e.g. BookingClass 'X' for Economy Class at Seg1 and BookingClass 'Y' for Business Class at Seg2) in a single ItineraryPart, BookingClass at the ItineraryPart level would be the BookingClass of the higher CabinClass (BookingClass 'Y'). In case of the BookingClass being different/assorted for the same CabinClass across segments in an ItineraryPart (e.g. BookingClass 'X' for Economy Class at Seg1 and BookingClass 'Y' for Economy Class at Seg2),value 'ASSORTED' will be returned as a value for the bookingClass at the ItineraryPart level. |
| `BrandId` | `String` | Optional | Brand ID for itinerary part. Used only for the exchange shopping - context shopping when there is a need of exposing brand ID for the already selected flights. |
| `ProgramIDs` | `List<String>` | Optional | List of program identifiers that belong to the brand of the itinerary part. |
| `ProgramCodes` | `List<String>` | Optional | List of program codes that belong to the brand of the itinerary part. |
| `CancelledSegments` | [`List<Segment>`](#segment) | Optional | List of cancelled segments (with status 'WK') for this itinerary part. Segment is added to that list when it is impossible to flight with it anymore. E.g. Because of bad weather on the destination airport it is impossible for plane to land there, so segment is changed to another one with different destination airport. In this case cancelled segment is added to this list, and new segment is added to segment list. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | The flight advisory or marketing message pertaining to specific flights or fares. |

##### Example (as JSON)

```json
{
  "segments": null,
  "stops": null,
  "totalDuration": null,
  "connectionInformations": null,
  "bookingClass": null,
  "brandId": null,
  "programIDs": null,
  "programCodes": null,
  "cancelledSegments": null,
  "advisories": null,
  "@type": null
}
```

#### Itinerary Part Brands

Result of one itinerary with possible brands fares buckets.

##### Class Name

`ItineraryPartBrands`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryPart` | [`ItineraryPart`](#itinerary-part) | Optional | - |
| `BrandOffers` | [`List<Offer>`](#offer) | Optional | Brand bucket offers. |
| `Duration` | `Long` | Optional | Flight duration expressed in minutes. |
| `Departure` | `LocalDateTime` | Optional | Departure date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |
| `Arrival` | `LocalDateTime` | Optional | Arrival date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |

##### Example (as JSON)

```json
{
  "itineraryPart": null,
  "brandOffers": null,
  "duration": null,
  "departure": null,
  "arrival": null
}
```

#### Itinerary Result

Represents itinerary.

##### Class Name

`ItineraryResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Messages concerning flight selection result. |
| `ItineraryParts` | [`List<ItineraryPart>`](#itinerary-part) | Optional | List of itinerary parts (aka legs). |

##### Example (as JSON)

```json
{
  "messages": null,
  "itineraryParts": null
}
```

#### Keyword Property Definition

##### Class Name

`KeywordPropertyDefinition`

##### Inherits From

[`AbstractPropertyDefinition`](#abstract-property-definition)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AllowedValueList` | `List<String>` | Optional | List of predefined options that can be chosen from to fulfill a SSR/AE request. |

##### Example (as JSON)

```json
{
  "allowedValueList": null,
  "propertyName": null,
  "propertyType": null,
  "optional": null,
  "@type": null
}
```

#### List Message Details

Basic message details in the list format.

##### Class Name

`ListMessageDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Value` | [`List<MessageDetails>`](#message-details) | Optional | Message details. |

##### Example (as JSON)

```json
{
  "value": null
}
```

#### Location

Location information. Code may be city or code.

##### Class Name

`Location`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Location code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `UseNearbyLocations` | `Boolean` | Optional | Flag indicating if we should use nearby location search. |

##### Example (as JSON)

```json
{
  "code": null,
  "useNearbyLocations": null
}
```

#### Login Credentials

Credentials required for the passenger's authentication.

##### Class Name

`LoginCredentials`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserId` | `String` | Optional | The passenger's identifier. |
| `Password` | `String` | Optional | The passenger's password. |
| `Captcha` | `String` | Optional | Captcha text used to prevent logins by robots. Checking capcha is disabled by default, but can be enabled by the following key:<br>sat.json.service.login.captchaEnabled = true. |

##### Example (as JSON)

```json
{
  "userId": null,
  "password": null,
  "captcha": null
}
```

#### Login Result

Result of the login operation.

##### Class Name

`LoginResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `User` | [`User`](#user) | Optional | Information about authenticated user of the application. |
| `LoyaltyRefreshError` | `Boolean` | Optional | Flag indicating if loyalty profile refresh attempt failed. True for failed attempt. |

##### Example (as JSON)

```json
{
  "user": null,
  "loyaltyRefreshError": null
}
```

#### Login Result Holder

Result and status of the login operation.

##### Class Name

`LoginResultHolder`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Status7`](#status-7) | Optional | Login status. |
| `Result` | [`LoginResult`](#login-result) | Optional | Result of the login operation. |

##### Example (as JSON)

```json
{
  "status": null,
  "result": null
}
```

#### Login Travel Bank Details

Travel Bank account information.

##### Class Name

`LoginTravelBankDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Balance` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "balance": null
}
```

#### Loyalty Details

Loyalty (Frequent Flyer) information.

##### Class Name

`LoyaltyDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MemberId` | `String` | Optional | Member ID (Frequent Flyer number). |
| `MemberAirline` | `String` | Optional | Member airline code. |
| `TierLevel` | `String` | Optional | Name of the membership tier level. |
| `Balance` | `Integer` | Optional | Points/miles balance. |
| `BalanceRefreshDate` | `LocalDateTime` | Optional | Date and time when the balance was refreshed in format: yyyy-MM-ddTHH:mm:ss. |

##### Example (as JSON)

```json
{
  "memberId": null,
  "memberAirline": null,
  "tierLevel": null,
  "balance": null,
  "balanceRefreshDate": null
}
```

#### Marketing Text

Marketing text details.

##### Class Name

`MarketingText`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProgramId` | `String` | Optional | Program ID used for marketing campaigns. |
| `LanguageId` | `String` | Optional | Language ID in the format: LANG_COUNTRY, where LANG is lowercase 2 to 8 language code and (optional) COUNTRY  is uppercase two-letter ISO-3166 code. |
| `MarketingText` | `String` | Optional | Detailed HTML code brand description. |

##### Example (as JSON)

```json
{
  "programId": null,
  "languageId": null,
  "marketingText": null
}
```

#### Message

Message contains details about error, warning etc.

##### Class Name

`Message`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Level` | [`Level`](#level) | Optional | Severity level. |
| `Code` | `String` | Optional | Message code. |
| `Details` | [`MessageDetails`](#message-details) | Optional | - |

##### Example (as JSON)

```json
{
  "level": null,
  "code": null,
  "details": null
}
```

#### Message Details

##### Class Name

`MessageDetails`

##### Fields

|  |
| 

##### Example (as JSON)

```json
{}
```

#### Meta Search

JSON representation of the metasearch parameters.

##### Class Name

`MetaSearch`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Currency` | `String` | Optional | Currency of the advertised fare that overrides default currency used in search. Three letter ISO code like https://en.wikipedia.org/wiki/ISO_4217, or FFCURRENCY for points/miles. |
| `PointOfSale` | `String` | Optional | Point of sale denotes the country from which sale happens. ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `Passengers` | `Map<String, String>` | Optional | Type and number of the requested passenger. At least one Stand-alone passenger is required (based on the PassengerType configuration). |
| `ReferrerCode` | `String` | Optional | Third party website referral code. |
| `AdvertisedFare` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `PromoCodes` | `List<String>` | Optional | Promo codes associated with the trip/passengers. |
| `MetaItineraryParts` | [`List<MetaSearchItineraryPart>`](#meta-search-itinerary-part) | Optional | Metasearch itinerary part information details. |
| `MetaSearchAirCustomPricing` | [`MetaSearchAirCustomPricing`](#meta-search-air-custom-pricing) | Optional | Metasearch custom pricing details. |

##### Example (as JSON)

```json
{
  "currency": null,
  "pointOfSale": null,
  "passengers": null,
  "referrerCode": null,
  "advertisedFare": null,
  "promoCodes": null,
  "metaItineraryParts": null,
  "metaSearchAirCustomPricing": null
}
```

#### Meta Search Air Custom Pricing

Metasearch custom pricing details.

##### Class Name

`MetaSearchAirCustomPricing`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Endorsement` | `String` | Optional | Endorsement text which will be added to the booking. |
| `Taxes` | [`List<Tax>`](#tax) | Optional | List of overridden taxes. |
| `Discount` | [`Discount`](#discount) | Optional | - |

##### Example (as JSON)

```json
{
  "endorsement": null,
  "taxes": null,
  "discount": null
}
```

#### Meta Search Itinerary Part

MetaSearch itinerary part.

##### Class Name

`MetaSearchItineraryPart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Segments` | [`List<Segment>`](#segment) | Optional | Segment details. |
| `BrandId` | `String` |  | Brand ID code with which the fare is filed. Dependent on the airline fare filing. |
| `MarriageGroup` | [`MarriageGroup`](#marriage-group) |  | Marriage group indicator. Default value is 0. Set to 0 means false, set to 1 means true. |
| `Discount` | [`Discount`](#discount) | Optional | JSON representation of the select flights discount parameter. |

##### Example (as JSON)

```json
{
  "brandId": "DEFAULT",
  "marriageGroup": null
}
```

#### Meta Search Results

Metasearch result.

##### Class Name

`MetaSearchResults`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightSelected` | `Boolean` | Optional | Flag indicating if the flight selection was successful. |
| `PriceChanged` | `Boolean` | Optional | Flag indicating if there was a change in the advertised fare. |
| `CurrencyChanged` | `Boolean` | Optional | Flag indicating if there was a change in the currency. |
| `DiscrepancyPrice` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "flightSelected": null,
  "priceChanged": null,
  "currencyChanged": null,
  "discrepancyPrice": null
}
```

#### Mini Fare Rule Result

Result object for mini fare rules.

##### Class Name

`MiniFareRuleResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rules` | [`Rules`](#rules) | Optional | Rules contains the information about Mini Fare Rules. |

##### Example (as JSON)

```json
{
  "rules": null
}
```

#### Monetary Modifier

##### Class Name

`MonetaryModifier`

##### Inherits From

[`PriceModifier`](#price-modifier)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerApplyType` | [`PassengerApplyType`](#passenger-apply-type) | Optional | Specifies how offering is applied - per passenger, or per all passengers. |
| `JourneyApplyType` | [`JourneyApplyType`](#journey-apply-type) | Optional | Specifies how offering is applied - per segment, itinerary part or whole itinerary. |
| `Currency` | `String` | Optional | Offering fee currency. |
| `Amount` | `Double` | Optional | Offering fee amount. |

##### Example (as JSON)

```json
{
  "passengerApplyType": null,
  "journeyApplyType": null,
  "currency": null,
  "amount": null,
  "remarkCode": null,
  "tourCode": null,
  "commercialName": null,
  "prasCode": null,
  "ocaeCode": null,
  "rficCode": null,
  "groupCode": null,
  "actionCode": null,
  "refundIndicator": null,
  "feeApplicationIndicator": null,
  "vendor": null,
  "emdtype": null,
  "@type": null
}
```

#### My Trip Response

Response container for myTrips response.

##### Class Name

`MyTripResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Trips` | [`List<TripInfo>`](#trip-info) | Optional | List of reservations. |

##### Example (as JSON)

```json
{
  "trips": null
}
```

#### Ob Fee

Ob Fee details.

##### Class Name

`ObFee`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Ob Fee sub-code. |
| `Name` | `String` | Optional | Ob Fee commercial name. |
| `Amount` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "code": null,
  "name": null,
  "amount": null
}
```

#### Ob Fee Breakdown Element

Ob Fee Breakdown element information.

##### Class Name

`ObFeeBreakdownElement`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `String` | Optional | Ob Fee fee generic label. Item description in the formats: general label: obfees; passenger indicator: ADT1, ADT2, CHD1; OBFeee indicator: R02, T01, T02, R13. |
| `Description` | `String` | Optional | Ob Fee commercial name. |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ObFeeBreakdownElements` | [`List<ObFeeBreakdownElement>`](#ob-fee-breakdown-element) | Optional | List of all Ob Fee breakdown elements. |
| `IsWaived` | `Boolean` | Optional | The waiver indicator. |

##### Example (as JSON)

```json
{
  "label": null,
  "description": null,
  "price": null,
  "obFeeBreakdownElements": null,
  "isWaived": null
}
```

#### Ob Fee Breakdown Information

All currently selected Ob Fees in a breakdown per passenger.

##### Class Name

`ObFeeBreakdownInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ObFeeBreakdownElements` | [`List<ObFeeBreakdownElement>`](#ob-fee-breakdown-element) | Optional | Ob Fee breakdown elements information. |

##### Example (as JSON)

```json
{
  "obFeeBreakdownElements": null
}
```

#### OB Fee Type R Update Response

List of operation results after adding or removing OB Fees type R.

##### Class Name

`OBFeeTypeRUpdateResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Results` | [`List<OBFeeTypeRUpdateResult>`](#ob-fee-type-r-update-result) | Optional | List of operation results after adding or removing Ob Fees type R. |

##### Example (as JSON)

```json
{
  "results": null
}
```

#### OB Fee Type R Update Result

OB Fee update result.

##### Class Name

`OBFeeTypeRUpdateResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResultCode` | `Integer` | Optional | Operation result code: <br>0 - "success result"<br>1 - "passenger not found"<br>2 - "OB Fee already associated to the passenger"<br>3 - "OB Fee not available for the passenger"<br>4 - "Unsupported operation". |
| `Description` | `String` | Optional | Description of operation result:<br>for 0 - " OB Fee " + obFeeTypeRCode + " successfully removed from passenger " + passengerIndex or "OB Fee " + obFeeTypeRCode + " successfully added to passenger " + passengerIndex<br>for 1 - "Passenger not found"<br>for 2 - "OB Fee already associated to passenger"<br>for 3 - "OB Fee not available for passenger"<br>for 4 - "Unsupported operation exception". |

##### Example (as JSON)

```json
{
  "resultCode": null,
  "description": null
}
```

#### Ob Fees Type R Change Request

List of operations to add or remove Requested OBFees per passenger.

##### Class Name

`ObFeesTypeRChangeRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ObFeeTypeROperationList` | [`List<OBFeesTypeROperation>`](#ob-fees-type-r-operation) | Optional | List of update operations. Each update operation is being applied to one passenger only. It contains Requested Fee code and action to perform. |

##### Example (as JSON)

```json
{
  "obFeeTypeROperationList": null
}
```

#### OB Fees Type R Operation

Operation to add or remove requested Ob Fees per passenger.

##### Class Name

`OBFeesTypeROperation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerIndex` | `Integer` | Optional | Flag indicating the passenger number in the itinerary. The requested fee will be updated for this passenger. |
| `ObFeeTypeRCode` | `String` | Optional | The requested fee code for an operation. |
| `ObFeesTypeRAction` | [`ObFeesTypeRAction`](#ob-fees-type-r-action) | Optional | Operation type. |

##### Example (as JSON)

```json
{
  "passengerIndex": null,
  "obFeeTypeRCode": null,
  "obFeesTypeRAction": null
}
```

#### OB Fees Waive Result

Response of waiving OB Fees.

##### Class Name

`OBFeesWaiveResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Success` | `Boolean` | Optional | Flag indicating if waive was successful. |

##### Example (as JSON)

```json
{
  "success": null
}
```

#### Object Config

Configuration definition for basic object validation.

##### Class Name

`ObjectConfig`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FieldName` | `String` | Optional | Field name specified in contract for request body or query parameters name for request query parameters, for root element in request body it is symbolic object name. |
| `ValidationInfo` | `Map<String, String>` | Optional | Basic validation configuration for the specified field. |
| `SubTypes` | [`List<SubTypeInfo>`](#sub-type-info) | Optional | Configuration definitions for subtypes if field can be defined by many types. |
| `ContextualValidation` | [`List<ContextualValidationInfo>`](#contextual-validation-info) | Optional | Configuration definitions for contextual subtypes if there are many contextual validation subtypes. |
| `Fields` | [`List<ObjectConfig>`](#object-config) | Optional | Configuration definition for object fields. |

##### Example (as JSON)

```json
{
  "fieldName": null,
  "@validationInfo": null,
  "@subTypes": null,
  "@contextualValidation": null,
  "fields": null
}
```

#### Occupation

Maintains occupation related information.

##### Class Name

`Occupation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IndustryCode` | [`IndustryCode`](#industry-code) | Optional | Occupation industry code. Values - AGY:Agency Employee, AGR:Agriculture/Forestry/Fishing, ART:Art, BNK:Banking, BUS:Business, BSC:Business Services and Consulting, CON:Construction, CPR:Chemicals/Petroleum Refining, CLG:College Student, EDU:Education, ELC:Electric, ENR:Entertainment and Recreation, FIN:Finance, FDP:Food Processing, GOV:Government, HLT:Health Services, HTL:Hotel, HPS:Household and Personal Service, HSW:Housewife, HRS:Human Resources, INF:Information Technology, INS:Insurance, LGL:Legal, LEI:Leisure and Hospitality, MFG:Manufacturing, MKT:Marketing, MCE:MFG - Computers/Electronics, MCD:MFG - Consumer Durables, MCN:MFG - Consumer Nondurables, MHE:MFG - Heavy Equipment, MIN:Mining, MUS:Music, NNG:Non-Governmental, OGE:Oil/Gas Exploration, POL:Politics, PST:Post Student, PRO:Professional Services, RLE:Real Estate, REL:Religion, RTR:Retail Trade, SCC:Securities and Commodities, SCL:Social, SFT:Software, SPT:Sport, STU:Student, TEL:Telecommunications, TRD:Trade, TRN:Transportation, TVL:Travel, UTL:Utilities, WTD:Wholesale Trade - Durables, WTN:Wholesale Trade - Nondurables, OTH:Other. |
| `Company` | `String` | Optional | Name of the company where the passenger works. |

##### Example (as JSON)

```json
{
  "industryCode": null,
  "company": null
}
```

#### Off Load Passenger Request

Data required to Offload passenger(s).

##### Class Name

`OffLoadPassengerRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin of the segment where Offload will be started (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `FlightNumber` | `Integer` | Optional | Segment's flight number where Offload will be started. |
| `DepartureDate` | `LocalDateTime` | Optional | Flight's departure date when Offload will be started. |

##### Example (as JSON)

```json
{
  "origin": null,
  "flightNumber": null,
  "departureDate": null
}
```

#### Off Load Passenger Response

Offload passenger(s) response.

##### Class Name

`OffLoadPassengerResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightNumber` | `Integer` | Optional | Flight number of first Offloaded segment. |
| `DepartureDate` | `LocalDateTime` | Optional | Departure date of first Offloaded segment. |
| `Origin` | `String` | Optional | Origin of first Offloaded segment. |
| `Pnr` | [`Pnr`](#pnr) | Optional | PNR representation. |

##### Example (as JSON)

```json
{
  "flightNumber": null,
  "departureDate": null,
  "origin": null,
  "pnr": null
}
```

#### Offer

Result of one itinerary with available fares.

##### Class Name

`Offer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShoppingBasketHashCode` | `Integer` | Optional | Offer identifier. Might not be unique. Should be consistent between searches. It is generated dynamically for each flight offer in the search. |
| `BrandId` | `String` | Optional | Brand associated with this offer. |
| `Soldout` | `Boolean` | Optional | Flag indicating if the offer is sold out. |
| `BundlePrice` | [`BundlePrices`](#bundle-prices) | Optional | Contains the price for the whole itinerary including all itinerary parts where bundled price configuration is enabled. |
| `PreviouslySelectedPrice` | [`Prices`](#prices) | Optional | Contains multiple price components. |
| `AvailableObFees` | [`List<PaxTypeObFeesAvailability>`](#pax-type-ob-fees-availability) | Optional | All available Ob Fees for passenger types. |
| `SeatsRemaining` | [`SeatsRemaining`](#seats-remaining) | Optional | Information about remaining seats count and if it is considered low by backend services. |
| `ItineraryPart` | [`List<ItineraryPart>`](#itinerary-part) | Optional | Offered itinerary parts. |
| `CabinClass` | [`CabinClass1`](#cabin-class-1) | Optional | Cabin class for this offer. |
| `IdenticalOffersRefs` | `List<Integer>` | Optional | References by shoppingBasketHashRef to other identical (flight, cabin, brand) offers that have different prices for any reason i.e. combinability makes the price lower or higher. |
| `OfferInformation` | [`OfferInformation`](#offer-information) | Optional | Additional information about a fare. |
| `PricedItineraryExchangeCharge` | [`PricedItineraryExchangeCharge`](#priced-itinerary-exchange-charge) | Optional | Information about irregular operations: Fee and price difference waivers if applicable. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | Messages pertaining to specific fares will be displayed. |
| `Status` | [`Status2`](#status-2) | Optional | Offer status. |
| `DepartureDates` | `List<LocalDate>` | Optional | List of offer's departure dates. Date is in the format: YYYY-MM-DD. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Fare` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Taxes` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ChangeFee` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ChangeFeeTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalMandatoryObFees` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalWithoutDiscount` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `RequiredMinThreshold` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `PriceDifference` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TaxesBreakdown` | [`List<TaxBreakdownElement>`](#tax-breakdown-element) | Optional | Tax breakdown prices. |

##### Example (as JSON)

```json
{
  "shoppingBasketHashCode": null,
  "brandId": null,
  "soldout": null,
  "bundlePrice": null,
  "previouslySelectedPrice": null,
  "availableObFees": null,
  "seatsRemaining": null,
  "itineraryPart": null,
  "cabinClass": null,
  "identicalOffersRefs": null,
  "offerInformation": null,
  "pricedItineraryExchangeCharge": null,
  "advisories": null,
  "status": null,
  "departureDates": null,
  "total": null,
  "fare": null,
  "taxes": null,
  "changeFee": null,
  "changeFeeTax": null,
  "totalMandatoryObFees": null,
  "totalWithoutDiscount": null,
  "requiredMinThreshold": null,
  "priceDifference": null,
  "taxesBreakdown": null
}
```

#### Offer Information

Additional information about a fare.

##### Class Name

`OfferInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Discounted` | `Boolean` | Optional | Flag indicating if the price is reduced by the discount. |
| `Negotiated` | `Boolean` | Optional | Flag indicating if the fare is a negotiated fare: corporate fares, lowered negotiated fares, etc. |
| `NegotiatedType` | [`NegotiatedType`](#negotiated-type) | Optional | Indicator for negotiated fare type. |
| `OfferName` | `String` | Optional | Offer Name associated with this offer. |
| `PromotionId` | `String` | Optional | Promotion Id associated with this offer. |
| `PromotionTag` | `String` | Optional | Promotion Tag associated with this offer. |

##### Example (as JSON)

```json
{
  "discounted": null,
  "negotiated": null,
  "negotiatedType": null,
  "offerName": null,
  "promotionId": null,
  "promotionTag": null
}
```

#### Offer Without Price

Result of one itinerary without pricing information.

##### Class Name

`OfferWithoutPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShoppingBasketHashCode` | `Integer` | Optional | Offer identifier that might not be unique. It should be a valid basket hash value of selected flight consistent between searches. It is generated dynamically for each flight offer in a search. |
| `BrandId` | `String` | Optional | Brand ID associated with this offer, usually alphanumeric. |
| `SeatsRemaining` | [`SeatsRemaining`](#seats-remaining) | Optional | Information about remaining seats count and if it is considered low by backend services. |
| `ItineraryPart` | [`List<ItineraryPart>`](#itinerary-part) | Optional | Offered itinerary parts. |
| `OfferInformation` | [`OfferInformation`](#offer-information) | Optional | Additional information about a fare. |
| `Advisories` | [`List<Advisory>`](#advisory) | Optional | Messages pertaining to specific fares will be displayed. |

##### Example (as JSON)

```json
{
  "shoppingBasketHashCode": null,
  "brandId": null,
  "seatsRemaining": null,
  "itineraryPart": null,
  "offerInformation": null,
  "advisories": null
}
```

#### Old Ancillary

Ancillary from original booking during exchange.

##### Class Name

`OldAncillary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Ancillary code. |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |
| `AncillaryPrice` | [`AncillaryPrice`](#ancillary-price) | Optional | Ancillary price for the ancillary offer. Contains base, taxes and total price. |
| `Quantity` | `Integer` | Optional | Quantity of the same values existing in this assignment e.g. number of passengers of type for air fare, amount of ancillaries with specific code etc. |
| `RefundIndicator` | `Boolean` | Optional | Flag indicating if the refund will be performed, otherwise it will be forfeited. |
| `AvailabilityIndicator` | `Boolean` | Optional | Flag indicating if the ancillary is available in the exchange operation. |

##### Example (as JSON)

```json
{
  "code": null,
  "travelPart": null,
  "ancillaryPrice": null,
  "quantity": null,
  "refundIndicator": null,
  "availabilityIndicator": null
}
```

#### Old Paid Seat

Information about previously booked paid seat in original reservation.

##### Class Name

`OldPaidSeat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AncillaryCode` | `String` | Optional | Ancillary code. |
| `SeatCode` | `String` | Optional | Seat code. |
| `SeatPrice` | [`SeatPrice`](#seat-price) | Optional | Seat price. |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |
| `Refundable` | `Boolean` | Optional | Seat refund indicator. |

##### Example (as JSON)

```json
{
  "ancillaryCode": null,
  "seatCode": null,
  "seatPrice": null,
  "travelPart": null,
  "refundable": null
}
```

#### Operating Day

Flight operating day availability.

##### Class Name

`OperatingDay`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Date` | `LocalDate` | Optional | Flight date in the format: YYYY-MM-DD. |
| `DayOfWeek` | [`DayOfWeek`](#day-of-week) | Optional | Day of the week. |
| `Available` | `Boolean` | Optional | Flag indicating if flight is available. |

##### Example (as JSON)

```json
{
  "date": null,
  "dayOfWeek": null,
  "available": null
}
```

#### Override Tax Price

Overridden price for ancillary tax. Contains tax code and new amount.

##### Class Name

`OverrideTaxPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Tax code. |
| `Price` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "code": null,
  "price": null
}
```

#### Page

Contains pagination related metadata as well as paginated content.

##### Class Name

`Page`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PageNumber` | `Integer` | Optional | Requested page number. |
| `ElementsPerPage` | `Integer` | Optional | Number of elements per page. |
| `ElementsList` | `List<Object>` | Optional | List of paginated elements. |

##### Example (as JSON)

```json
{
  "pageNumber": null,
  "elementsPerPage": null,
  "elementsList": null
}
```

#### Page Agent Profile

Contains pagination related metadata as well as paginated content.

##### Class Name

`PageAgentProfile`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PageNumber` | `Integer` | Optional | Requested page number. |
| `ElementsPerPage` | `Integer` | Optional | Number of elements per page. |
| `ElementsList` | [`List<AgentProfile>`](#agent-profile) | Optional | List of paginated elements. |

##### Example (as JSON)

```json
{
  "pageNumber": null,
  "elementsPerPage": null,
  "elementsList": null
}
```

#### Passenger

Passenger.

##### Class Name

`Passenger`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger expressed as a positive integer. |
| `PassengerNameNumber` | `String` | Optional | Passenger's name number. |
| `PassengerDetails` | [`PassengerDetails`](#passenger-details) | Optional | Passenger's/Agency user's details. |
| `PassengerInfo` | [`PassengerInfo`](#passenger-info) | Optional | Passenger's information. |
| `Preferences` | [`Preferences`](#preferences) | Optional | Passenger's preferences. |
| `DocumentInfo` | [`PassengerDocumentInfo`](#passenger-document-info) | Optional | Passenger document information. |
| `VisaInfo` | [`PassengerVisaInfo`](#passenger-visa-info) | Optional | Passenger's visa information. |

##### Example (as JSON)

```json
{
  "passengerIndex": null,
  "passengerNameNumber": null,
  "passengerDetails": null,
  "passengerInfo": null,
  "preferences": null,
  "documentInfo": null,
  "visaInfo": null
}
```

#### Passenger Allowance

List of passenger baggage allowances for each segment.

##### Class Name

`PassengerAllowance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Segments` | [`List<Segment>`](#segment) | Optional | List of segments with baggage allowance. |
| `PassengerBaggageInfo` | [`List<PassengerBaggageInfo>`](#passenger-baggage-info) | Optional | List of baggage allowances grouped by passenger. |
| `Message` | [`Message`](#message) | Optional | Message contains details about error, warning etc. |

##### Example (as JSON)

```json
{
  "segments": null,
  "passengerBaggageInfo": null,
  "message": null
}
```

#### Passenger Baggage Disclosure

Embargo Information for selected flights.

##### Class Name

`PassengerBaggageDisclosure`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CheckedInBaggage` | [`CheckedInBaggage`](#checked-in-baggage) | Optional | Checked in baggage information for selected flights. |
| `CarryOnBaggage` | [`CarryOnBaggage`](#carry-on-baggage) | Optional | Carryon Allowance Information for selected flights. |
| `PassengerType` | [`PassengerType1`](#passenger-type-1) | Optional | Passenger type like adult, child etc. |

##### Example (as JSON)

```json
{
  "checkedInBaggage": null,
  "carryOnBaggage": null,
  "passengerType": null
}
```

#### Passenger Baggage Info

Baggage allowance information for this passenger.

##### Class Name

`PassengerBaggageInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CheckedInBaggage` | [`CheckedInBaggageAllowance`](#checked-in-baggage-allowance) | Optional | Checked in baggage allowance. |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger expressed as a positive integer. |

##### Example (as JSON)

```json
{
  "checkedInBaggage": null,
  "passengerIndex": null
}
```

#### Passenger Change Response

Contains the response data from change passenger details operation.

##### Class Name

`PassengerChangeResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AnyUserChange` | `Boolean` | Optional | Flag indicating changes in passengers' details. |

##### Example (as JSON)

```json
{
  "anyUserChange": null
}
```

#### Passenger Details

Passenger's/Agency user's details.

##### Class Name

`PassengerDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Passenger's first name. |
| `LastName` | `String` | Optional | Passenger's last name. |
| `Prefix` | [`Prefix2`](#prefix-2) | Optional | Passenger prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted). |
| `MiddleName` | `String` | Optional | Passenger's middle name. |
| `MaidenName` | `String` | Optional | Passenger's maiden name. |
| `Suffix` | [`Suffix2`](#suffix-2) | Optional | Passenger suffix, accepts lower and upper case letters (suffix values read from the PNR will be in upper case letters to accommodate this, upper case is also accepted). |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "prefix": null,
  "middleName": null,
  "maidenName": null,
  "suffix": null
}
```

#### Passenger Document Info

Passenger document information.

##### Class Name

`PassengerDocumentInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IssuingCountry` | `String` | Optional | Document issue country code (ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1). |
| `CountryOfBirth` | `String` | Optional | Passenger's country of birth (ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1). |
| `IssueDate` | `LocalDate` | Optional | Document issued date in the format: YYYY-MM-DD. |
| `DocumentNumber` | `String` | Optional | Passenger's document number. |
| `DocumentType` | [`DocumentType`](#document-type) | Optional | Document type. |
| `Nationality` | `String` | Optional | Passenger's nationality ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1. |
| `ExpirationDate` | `LocalDate` | Optional | Document expiration date in the format: YYYY-MM-DD. |
| `DateOfBirth` | `LocalDate` | Optional | Passenger's date of birth in the format: YYYY-MM-DD. |

##### Example (as JSON)

```json
{
  "issuingCountry": null,
  "countryOfBirth": null,
  "issueDate": null,
  "documentNumber": null,
  "documentType": null,
  "nationality": null,
  "expirationDate": null,
  "dateOfBirth": null
}
```

#### Passenger Fare Rule

Passenger fare rule for each passenger type.

##### Class Name

`PassengerFareRule`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerType` | [`PassengerType3`](#passenger-type-3) | Optional | Passenger's type. |
| `ChangesFees` | [`PenaltyFees`](#penalty-fees) | Optional | Change/cancellation fee for the passenger fare rule. |
| `RefundFees` | [`PenaltyFees`](#penalty-fees) | Optional | Change/cancellation fee for the passenger fare rule. |

##### Example (as JSON)

```json
{
  "passengerType": null,
  "changesFees": null,
  "refundFees": null
}
```

#### Passenger Info

Passenger's information.

##### Class Name

`PassengerInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DateOfBirth` | `LocalDate` | Optional | Passenger's date of birth in the format: YYYY-MM-DD. |
| `Gender` | [`Gender1`](#gender-1) | Optional | Passenger's gender. |
| `RedressNumber` | `String` | Optional | Redress number is issued to customers as part the TSA's Secure Flight program to speed identification and security clearance. More information available at www.tsa.gov/stakeholders/secure-flight-program. |
| `KnownTravelerNumber` | `String` | Optional | Known Travler/TSA PreCheck Number. |
| `GeneralSalesTaxData` | [`GeneralSalesTaxData`](#general-sales-tax-data) | Optional | Passenger's General Sales Tax (GST) data. |
| `Type` | [`Type5`](#type-5) | Optional | Passenger's type. |
| `Emails` | `List<String>` | Optional | List of passenger's emails. |
| `Phones` | [`List<Phone>`](#phone) | Optional | List of passenger's phones. |
| `Address` | [`Address`](#address) | Optional | Passenger Contact Address. |

##### Example (as JSON)

```json
{
  "dateOfBirth": null,
  "gender": null,
  "redressNumber": null,
  "knownTravelerNumber": null,
  "generalSalesTaxData": null,
  "type": null,
  "emails": null,
  "phones": null,
  "address": null
}
```

#### Passenger Name

Passenger name information.

##### Class Name

`PassengerName`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Passenger's first name. |
| `LastName` | `String` | Optional | Passenger's last name. |
| `Prefix` | [`Prefix2`](#prefix-2) | Optional | Passenger prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted). |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "prefix": null
}
```

#### Passenger Offer

Ancillary offer details for specific passenger.

##### Class Name

`PassengerOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AncillaryPassenger` | [`AncillaryPassenger`](#ancillary-passenger) | Optional | Passenger's details. |
| `AncillaryPrice` | [`AncillaryPrice`](#ancillary-price) | Optional | Ancillary price for the ancillary offer. Contains base, taxes and total price. |
| `DealDiscount` | [`DealDiscount`](#deal-discount) | Optional | Deal discount details. |
| `BagCharacteristics` | [`Map<String, BagCharacteristics>`](#bag-characteristics) | Optional | Bag characteristics. |
| `AssignedQuantity` | `Integer` | Optional | Quantity assigned for the passenger. |
| `IncludedInBundle` | `Boolean` | Optional | Ancillary included in the selected bundle. |
| `Available` | `Boolean` | Optional | Flag indicating if the offer is available for the passenger. |
| `OriginalAssignedQuantity` | `Integer` | Optional | Originally selected ancillary quantity assigned for the passenger. |
| `ModificationAllowed` | `Boolean` | Optional | Flag indicating if modification for the originally purchased ancillary is allowed. |
| `SsrProperties` | `Map<String, String>` | Optional | Ancillary Special Service Request (SSR) properties like weight, age, keyword etc. |
| `SsrDescription` | `String` | Optional | AAncillary Special Service Request (SSR) structured text description. |

##### Example (as JSON)

```json
{
  "ancillaryPassenger": null,
  "ancillaryPrice": null,
  "dealDiscount": null,
  "bagCharacteristics": null,
  "assignedQuantity": null,
  "includedInBundle": null,
  "available": null,
  "originalAssignedQuantity": null,
  "modificationAllowed": null,
  "ssrProperties": null,
  "ssrDescription": null
}
```

#### Passenger Seat Map

Seat map information for passenger.

##### Class Name

`PassengerSeatMap`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Warning/error messages related to the downline response for this segment seat map (for preview seat map). |
| `PaidSeatSelectionRequired` | `Boolean` | Optional | Flag indicating if the paid seat needs to be re-selected after reassociation. |
| `SeatSelectionEnabledForPax` | `Boolean` | Optional | Indicator for seat selection enabled for passenger. |
| `SeatMap` | [`SeatMap`](#seat-map) | Optional | Seat map details. |
| `Passenger` | [`Passenger`](#passenger) | Optional | Passenger. |

##### Example (as JSON)

```json
{
  "messages": null,
  "paidSeatSelectionRequired": null,
  "seatSelectionEnabledForPax": null,
  "seatMap": null,
  "passenger": null
}
```

#### Passenger Segment Key

PassengerSegmentKey to use segment information together with passenger index and with general purpose code property, mainly this contract is being used as a detail part of Messages.

##### Class Name

`PassengerSegmentKey`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `Arrival` | `LocalDateTime` | Optional | Arrival date time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger expressed as a positive integer. |
| `Code` | `String` | Optional | Code such as seat code, ancillary code. |

##### Example (as JSON)

```json
{
  "origin": null,
  "destination": null,
  "departure": null,
  "arrival": null,
  "passengerIndex": null,
  "code": null
}
```

#### Passenger Update Response

Response container for update passengers.

##### Class Name

`PassengerUpdateResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Messages pertaining to the passenger's result. |
| `Passengers` | [`Passengers`](#passengers) | Optional | List of passengers. |
| `Warnings` | `Map<String, String>` | Optional | List of warnings associated with the Frequent Flyer validations failure. |

##### Example (as JSON)

```json
{
  "messages": null,
  "passengers": null,
  "warnings": null
}
```

#### Passenger Upgrade Offer Price

Upgrade offer price for passenger.

##### Class Name

`PassengerUpgradeOfferPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Passenger` | [`AncillaryPassenger`](#ancillary-passenger) | Optional | Passenger's details. |
| `UpgradeOfferPrice` | [`UpgradeOfferPrice`](#upgrade-offer-price) | Optional | Upgrade offer price. |

##### Example (as JSON)

```json
{
  "passenger": null,
  "upgradeOfferPrice": null
}
```

#### Passenger Upgrade Price

Segment upgrade price for passenger.

##### Class Name

`PassengerUpgradePrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Passenger` | [`Passenger`](#passenger) | Optional | Passenger. |
| `UpgradePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "passenger": null,
  "upgradePrice": null
}
```

#### Passenger Visa Info

Passenger's visa information.

##### Class Name

`PassengerVisaInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IssuingCountry` | `String` | Optional | Document issue country code (ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1). |
| `CountryOfBirth` | `String` | Optional | Passenger's country of birth (ISO country code like: https://en.wikipedia.org/?title=ISO_3166-1). |
| `IssueDate` | `LocalDate` | Optional | Document issued date in the format: YYYY-MM-DD. |
| `DocumentNumber` | `String` | Optional | Passenger's document number. |
| `IssuePlace` | `String` | Optional | Document issue place. |

##### Example (as JSON)

```json
{
  "issuingCountry": null,
  "countryOfBirth": null,
  "issueDate": null,
  "documentNumber": null,
  "issuePlace": null
}
```

#### Passenger With Features

Represents passenger with related features (e.g. ancillaries).

##### Class Name

`PassengerWithFeatures`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Passenger` | [`Passenger`](#passenger) | Optional | Passenger. |
| `Ancillaries` | [`List<SelectedAncillary>`](#selected-ancillary) | Optional | Ancillaries related to given passenger. |
| `CheckedInBaggage` | [`CheckedInBaggageAllowance`](#checked-in-baggage-allowance) | Optional | Checked in baggage allowance. |
| `Seat` | [`PnrSelectedSeat`](#pnr-selected-seat) | Optional | Information about selected seat. |
| `EticketNumber` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "passenger": null,
  "ancillaries": null,
  "checkedInBaggage": null,
  "seat": null,
  "eticketNumber": null
}
```

#### Passengers

List of passengers.

##### Class Name

`Passengers`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Passengers` | [`List<Passenger>`](#passenger) | Optional | Passenger list. |
| `BusinessLoyalty` | [`BusinessLoyalty`](#business-loyalty) | Optional | Corporate Loyalty details. |
| `Contact` | [`Contact`](#contact) | Optional | Booker's contact information. |

##### Example (as JSON)

```json
{
  "passengers": null,
  "businessLoyalty": null,
  "contact": null
}
```

#### Pax Type Ob Fees Availability

Information about all available ob fees for specific passenger type.

##### Class Name

`PaxTypeObFeesAvailability`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerType` | [`PassengerType`](#passenger-type) | Optional | Passenger's type code. |
| `Mandatory` | [`List<ObFee>`](#ob-fee) | Optional | List of mandatory Ob Fees for this passenger type. |
| `Optional` | [`List<ObFee>`](#ob-fee) | Optional | List of optional Ob Fees for this passenger type. |

##### Example (as JSON)

```json
{
  "passengerType": null,
  "mandatory": null,
  "optional": null
}
```

#### Pay Pal

##### Class Name

`PayPal`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CancelURL` | `String` | Optional | Context parameter - cancel URL. |
| `SuccessURL` | `String` | Optional | Context parameter - success URL. |
| `PayerId` | `String` | Optional | ID of the payer needed for 2nd PayPal request. |
| `Token` | `String` | Optional | Token needed for 2nd PayPal request. |
| `Status` | [`Status6`](#status-6) | Optional | Status of executed transaction. |

##### Example (as JSON)

```json
{
  "cancelURL": null,
  "successURL": null,
  "payerId": null,
  "token": null,
  "status": null,
  "amount": null,
  "@type": null
}
```

#### Pay Pal Refund

##### Class Name

`PayPalRefund`

##### Inherits From

[`RefundTarget`](#refund-target)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### Payment

Common payment details.

##### Class Name

`Payment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "amount": null,
  "@type": null
}
```

#### Payment Combinability

Payment combinability response model.

##### Class Name

`PaymentCombinability`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |
| `Result` | [`PaymentOptionsResult`](#payment-options-result) | Optional | Payment options result. |
| `Payment` | [`PaymentProductCombinability`](#payment-product-combinability) | Optional | All allowed payments broken down by product type. |

##### Example (as JSON)

```json
{
  "messages": null,
  "result": null,
  "payment": null
}
```

#### Payment Data

JSON representation of payment data.

##### Class Name

`PaymentData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentRequired` | `Boolean` | Optional | Flag indicating if payment is required or not. |
| `Payment` | [`List<Payment>`](#payment) | Optional | List with used payments. The request should contain at least one instance of /payment. |
| `BillingData` | [`BillingData`](#billing-data) | Optional | Billing address information for the purchase. |
| `LanguageForBooking` | `String` | Optional | Language code for the booking. |
| `FraudNetData` | [`FraudNetData`](#fraud-net-data) | Optional | Additional data about the user browser, used by Fraud check providers to validate transaction. |
| `RemarksAndSSRs` | [`RemarksAndSSRs`](#remarks-and-ss-rs) | Optional | Messages that can be added to the PNR. |
| `ProfileInput` | [`ProfileInput`](#profile-input) | Optional | Input information for profile created in the booking path. |
| `QueuePlacementData` | [`QueuePlacementData`](#queue-placement-data) | Optional | Queue number and prefatory instruction code used to place the PNR in a specific queue. |

##### Example (as JSON)

```json
{
  "paymentRequired": null,
  "payment": null,
  "billingData": null,
  "languageForBooking": null,
  "fraudNetData": null,
  "remarksAndSSRs": null,
  "profileInput": null,
  "queuePlacementData": null
}
```

#### Payment Info

Information about the payment type.

##### Class Name

`PaymentInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentType` | [`PaymentType`](#payment-type) | Optional | General payment type. |
| `PaymentCode` | `String` | Optional | Unique and more specific payment code. |
| `Amount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `MinimumAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `Surcharge` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `CombinableWith` | `List<String>` | Optional | All combinable forms of Payment that can be used with currently chosen one. |
| `AdditionalPaymentDetails` | [`AdditionalPaymentDetails`](#additional-payment-details) | Optional | Information about additional payment details. |

##### Example (as JSON)

```json
{
  "paymentType": null,
  "paymentCode": null,
  "amount": null,
  "minimumAmount": null,
  "surcharge": null,
  "combinableWith": null,
  "additionalPaymentDetails": null
}
```

#### Payment Options Result

Payment options result.

##### Class Name

`PaymentOptionsResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `VcrChangeType` | [`VcrChangeType`](#vcr-change-type) | Optional | Type of VCR change. |
| `PaymentRequired` | `Boolean` | Optional | - |
| `Refund` | `Boolean` | Optional | - |

##### Example (as JSON)

```json
{
  "vcrChangeType": null,
  "paymentRequired": null,
  "refund": null
}
```

#### Payment Product

Payment for products.

##### Class Name

`PaymentProduct`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentInfo` | [`PaymentInfo`](#payment-info) | Optional | Information about the payment type. |
| `ProductType` | [`List<ProductType1>`](#product-type-1) | Optional | List of grouped products that are paid together. |

##### Example (as JSON)

```json
{
  "paymentInfo": null,
  "productType": null
}
```

#### Payment Product Combinability

All allowed payments broken down by product type.

##### Class Name

`PaymentProductCombinability`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentProducts` | [`List<PaymentProduct>`](#payment-product) | Optional | List of all payment products. |
| `RefundDataModel` | [`RefundDataModel`](#refund-data-model) | Optional | All data related to refund in an Exchange. |

##### Example (as JSON)

```json
{
  "paymentProducts": null,
  "refundDataModel": null
}
```

#### Payment Query Installment Details

Represents information about used payment query installment option details.

##### Class Name

`PaymentQueryInstallmentDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NumberOfInstallments` | `Integer` | Optional | Total number of installments. |
| `InterestAmount` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `InterestRate` | `Double` | Optional | Annual percentage interest rate. |

##### Example (as JSON)

```json
{
  "numberOfInstallments": null,
  "interestAmount": null,
  "interestRate": null
}
```

#### Payment Query Installment Option

Information regarding installments from payment query.

##### Class Name

`PaymentQueryInstallmentOption`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InstallmentId` | `String` | Optional | Installment ID. |
| `NumberOfInstallments` | `Integer` | Optional | Total number of installments. |
| `TotalPaymentAmount` | `Double` | Optional | Total payment amount. |
| `InstallmentAmount` | `Double` | Optional | Installment amount per month. |
| `InterestAmount` | `Double` | Optional | Total interest amount. |
| `InterestRate` | `Double` | Optional | Annual percentage interest rate. |
| `PromotionalInd` | `Boolean` | Optional | PromotionalInd Flag for the paymentOptional Installment. |

##### Example (as JSON)

```json
{
  "installmentId": null,
  "numberOfInstallments": null,
  "totalPaymentAmount": null,
  "installmentAmount": null,
  "interestAmount": null,
  "interestRate": null,
  "promotionalInd": null
}
```

#### Paypal Redirect Info

##### Class Name

`PaypalRedirectInfo`

##### Inherits From

[`RedirectInfo`](#redirect-info)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RedirectUrl` | `String` | Optional | URL of remote system (paypal or 3ds) where the transaction will be continued. |
| `FlowStatus` | `String` | Optional | Paypal flow status. |

##### Example (as JSON)

```json
{
  "redirectUrl": null,
  "flowStatus": null,
  "transactionId": null,
  "@type": null
}
```

#### Penalty

Displays applicability and penalty amount for change/cancellation.

##### Class Name

`Penalty`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Allowed` | `Boolean` | Optional | Flag indicating if the change/cancellation fee is allowed. |
| `Penalty` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "allowed": null,
  "penalty": null
}
```

#### Penalty Fees

Change/cancellation fee for the passenger fare rule.

##### Class Name

`PenaltyFees`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BeforeFee` | [`Penalty`](#penalty) | Optional | Displays applicability and penalty amount for change/cancellation. |
| `AfterFee` | [`Penalty`](#penalty) | Optional | Displays applicability and penalty amount for change/cancellation. |

##### Example (as JSON)

```json
{
  "beforeFee": null,
  "afterFee": null
}
```

#### Percentage Discount

##### Class Name

`PercentageDiscount`

##### Inherits From

[`Discount`](#discount)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Percentage` | `Double` | Optional | Discount percentage to be applied for the fare. |

##### Example (as JSON)

```json
{
  "percentage": null,
  "@type": null
}
```

#### Percentage Modifier

##### Class Name

`PercentageModifier`

##### Inherits From

[`PriceModifier`](#price-modifier)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `Double` | Optional | Percent of the original fee. |
| `IncludeBase` | `Boolean` | Optional | Should include base. |
| `IncludeTax` | `Boolean` | Optional | Should include tax. |
| `IncludeDiscount` | `Boolean` | Optional | Should include discount. |

##### Example (as JSON)

```json
{
  "amount": null,
  "includeBase": null,
  "includeTax": null,
  "includeDiscount": null,
  "remarkCode": null,
  "tourCode": null,
  "commercialName": null,
  "prasCode": null,
  "ocaeCode": null,
  "rficCode": null,
  "groupCode": null,
  "actionCode": null,
  "refundIndicator": null,
  "feeApplicationIndicator": null,
  "vendor": null,
  "emdtype": null,
  "@type": null
}
```

#### Personal Details

Passenger's personal information.

##### Class Name

`PersonalDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `String` | Optional | Passenger's first name. |
| `LastName` | `String` | Optional | Passenger's last name. |

##### Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

#### Phone

Phone details.

##### Class Name

`Phone`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type`](#type) | Optional | Phone type. |
| `CountryCode` | `String` | Optional | Phone country code (ISO country code like https://en.wikipedia.org/wiki/Country_code). |
| `AreaCode` | `String` | Optional | Phone area code. |
| `Number` | `String` | Optional | Phone number. |
| `Extension` | `String` | Optional | Phone extension. |

##### Example (as JSON)

```json
{
  "type": null,
  "countryCode": null,
  "areaCode": null,
  "number": null,
  "extension": null
}
```

#### Pnr

PNR representation.

##### Class Name

`Pnr`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reloc` | `String` | Optional | Reservation code - 6 uppercase alphanumeric characters. |
| `IropAffected` | `Boolean` | Optional | Flag indicating if PNR is IROP affected. |
| `Itinerary` | [`Itinerary`](#itinerary) | Optional | - |
| `Passengers` | [`List<Passenger>`](#passenger) | Optional | Passengers. |
| `InsuranceInformation` | [`InsuranceInformation`](#insurance-information) | Optional | Insurance confirmation details. |
| `Documents` | [`List<Document>`](#document) | Optional | List of documents attached to the reservation. |
| `TravelPartsAdditionalDetails` | [`List<TravelPartAdditionalDetails>`](#travel-part-additional-details) | Optional | Additional details for specific travel parts. |
| `Payments` | [`List<PnrPayment>`](#pnr-payment) | Optional | List of payments used to pay for reservation. |
| `DocumentPaymentDetails` | [`List<DocumentPaymentDetails>`](#document-payment-details) | Optional | List of payments used to pay for reservation per document. |
| `PriceBreakdown` | [`BreakdownElement`](#breakdown-element) | Optional | - |
| `TimeToTicket` | [`TimeToTicket`](#time-to-ticket) | Optional | Time to ticket. |
| `Contact` | [`Contact`](#contact) | Optional | Booker's contact information. |
| `BusinessLoyalty` | [`BusinessLoyalty`](#business-loyalty) | Optional | Corporate Loyalty details. |
| `FraudCheckResult` | [`FraudCheckResult`](#fraud-check-result) | Optional | Fraud check result data. |
| `OtherServiceInformation` | `List<String>` | Optional | Other service information list associated with this PNR. |
| `TripContactInfo` | [`TripContactInfo`](#trip-contact-info) | Optional | Trip contact information. |
| `FareRulesResult` | [`FareRulesResult`](#fare-rules-result) | Optional | Result for retrieving fare rules. |
| `Remarks` | `List<String>` | Optional | Remarks filtered out using the preconfigured regular expression and associated with this PNR. These remarks will not contain any PCI sensitive data. |
| `SpecialServiceRequests` | [`List<SpecialServiceRequest>`](#special-service-request) | Optional | All non-ancillary SSRs (Special Service Request) from the PNR. |
| `PseudoCity` | [`PseudoCity`](#pseudo-city) | Optional | Information about pseudocity that this pnr was created in. |
| `UpgradeInfo` | [`UpgradeInfo`](#upgrade-info) | Optional | PNR upgrade information. |
| `CarReservationSummary` | [`CarReservationSummary`](#car-reservation-summary) | Optional | Summary of the car reservation. |
| `HotelReservationSummary` | [`HotelReservationSummary`](#hotel-reservation-summary) | Optional | Summary of the hotel reservation. |

##### Example (as JSON)

```json
{
  "reloc": null,
  "iropAffected": null,
  "itinerary": null,
  "passengers": null,
  "insuranceInformation": null,
  "documents": null,
  "travelPartsAdditionalDetails": null,
  "payments": null,
  "documentPaymentDetails": null,
  "priceBreakdown": null,
  "timeToTicket": null,
  "contact": null,
  "businessLoyalty": null,
  "fraudCheckResult": null,
  "otherServiceInformation": null,
  "tripContactInfo": null,
  "fareRulesResult": null,
  "remarks": null,
  "specialServiceRequests": null,
  "pseudoCity": null,
  "upgradeInfo": null,
  "carReservationSummary": null,
  "hotelReservationSummary": null
}
```

#### Pnr Payment

Represents payment transaction.

##### Class Name

`PnrPayment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentCode` | `String` | Optional | Code of payment. |
| `PaymentType` | `String` | Optional | Type of payment. |
| `Identifier` | `String` | Optional | Payment ID like number of Credit Card, eVoucher number, etc.). |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `RetailInformation` | [`List<RetailReference>`](#retail-reference) | Optional | Information for retail form of payment. Present only if payment code is RP. |
| `PaymentDCCSummary` | [`DCCPaymentOffer`](#dcc-payment-offer) | Optional | Details of the Dynamic Currency Conversion (DCC) offer. |
| `InstallmentDetails` | [`PaymentQueryInstallmentDetails`](#payment-query-installment-details) | Optional | Represents information about used payment query installment option details. |
| `SupplierTransactionId` | `String` | Optional | Supplier Transaction ID is the Id in payment Response. |
| `ApprovalCode` | `String` | Optional | Approval Code is the code in payment Response. |

##### Example (as JSON)

```json
{
  "paymentCode": null,
  "paymentType": null,
  "identifier": null,
  "price": null,
  "retailInformation": null,
  "paymentDCCSummary": null,
  "installmentDetails": null,
  "supplierTransactionId": null,
  "approvalCode": null
}
```

#### Pnr Retrieve Response

PNR representation.

##### Class Name

`PnrRetrieveResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Pnr` | [`Pnr`](#pnr) | Optional | PNR representation. |
| `TripOptions` | [`List<RulesEvaluation>`](#rules-evaluation) | Optional | List of trip options and their statuses associated with the retrieved booking. |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning and error messages related to PNR Retrieval Response result. |

##### Example (as JSON)

```json
{
  "pnr": null,
  "tripOptions": null,
  "messages": null
}
```

#### Pnr Selected Seat

Information about selected seat.

##### Class Name

`PnrSelectedSeat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SeatCode` | `String` | Optional | Seat code. |
| `Description` | `String` | Optional | Type of the seat. |

##### Example (as JSON)

```json
{
  "seatCode": null,
  "description": null
}
```

#### Poli

##### Class Name

`Poli`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CheckoutUrl` | `String` | Optional | Poli context parameter - checkout URL. |
| `HomePageUrl` | `String` | Optional | Poli context parameter - home page URL. |
| `SuccessfulUrl` | `String` | Optional | Poli context parameter - successful URL. |
| `UnSuccessfulUrl` | `String` | Optional | Poli context parameter - unsuccessful URL. |
| `Token` | `String` | Optional | Token required for the 2nd poli request. |

##### Example (as JSON)

```json
{
  "checkoutUrl": null,
  "homePageUrl": null,
  "successfulUrl": null,
  "unSuccessfulUrl": null,
  "token": null,
  "amount": null,
  "@type": null
}
```

#### Poli Redirect Info

##### Class Name

`PoliRedirectInfo`

##### Inherits From

[`RedirectInfo`](#redirect-info)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RedirectUrl` | `String` | Optional | URL of POLI remote system used to authorize the transaction. |
| `Token` | `String` | Optional | POLI token transaction identifier. |

##### Example (as JSON)

```json
{
  "redirectUrl": null,
  "token": null,
  "transactionId": null,
  "@type": null
}
```

#### Preferences

Passenger's preferences.

##### Class Name

`Preferences`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SpecialPreferences` | [`SpecialPreferences`](#special-preferences) | Optional | Passenger Special Preferences. |
| `FrequentFlyer` | [`List<FrequentFlyer>`](#frequent-flyer) | Optional | List of Passenger's Frequent Flyer accounts details. |

##### Example (as JSON)

```json
{
  "specialPreferences": null,
  "frequentFlyer": null
}
```

#### Preview Seats Result

Preview seats result.

##### Class Name

`PreviewSeatsResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentSeatMaps` | [`List<SegmentSeatMap>`](#segment-seat-map) | Optional | Contains segment's seat map details for the itinerary. |

##### Example (as JSON)

```json
{
  "segmentSeatMaps": null
}
```

#### Price Modifier

Common price modifier details.

##### Class Name

`PriceModifier`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RemarkCode` | `String` | Optional | Remark code details. |
| `TourCode` | `String` | Optional | Tour code details. |
| `CommercialName` | `String` | Optional | Commercial name details. |
| `PrasCode` | `String` | Optional | PRAS code details. |
| `OcaeCode` | `String` | Optional | OCAE code details. |
| `RficCode` | `String` | Optional | RFIC code details. |
| `GroupCode` | `String` | Optional | Group code details. |
| `ActionCode` | `String` | Optional | Action code details. |
| `RefundIndicator` | `Boolean` | Optional | Refund indicator. |
| `FeeApplicationIndicator` | `String` | Optional | Fee application indicator. |
| `Vendor` | `String` | Optional | Vendor details. |
| `Emdtype` | `String` | Optional | - |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "remarkCode": null,
  "tourCode": null,
  "commercialName": null,
  "prasCode": null,
  "ocaeCode": null,
  "rficCode": null,
  "groupCode": null,
  "actionCode": null,
  "refundIndicator": null,
  "feeApplicationIndicator": null,
  "vendor": null,
  "emdtype": null,
  "@type": null
}
```

#### Priced Car

Detailed description of the rental car, including its availability, features and all associated charges.

##### Class Name

`PricedCar`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Signature` | `String` | Optional | A JWT token (see: https://jwt.io/). Signature and data used for signing. It can be validated by Digital Connect if provided object is correct and no price was changed without authorization. |
| `CarInfoModel` | [`CarInfoModel`](#car-info-model) | Optional | Data of car availability response. |
| `VendorReference` | [`VendorReference`](#vendor-reference) | Optional | Information identifying this availability quote. Some Provider expect it to match exactly as returned in availability Response for desired Vehicle. |
| `RentalRate` | [`RentalRate`](#rental-rate) | Optional | Rate definition associated with offered vehicle. |
| `AvailabilityStatus` | [`AvailabilityStatus`](#availability-status) | Optional | Defines a set of valid status values, allowing the selection of a specific group based on its availability or just the disclosure of the reservation status. |
| `DistanceRestriction` | [`DistanceRestriction`](#distance-restriction) | Optional | Distance restriction defined for the rented vehicle. |

##### Example (as JSON)

```json
{
  "signature": null,
  "carInfoModel": null,
  "vendorReference": null,
  "rentalRate": null,
  "availabilityStatus": null,
  "distanceRestriction": null
}
```

#### Priced Itinerary Exchange Charge

Information about irregular operations: Fee and price difference waivers if applicable.

##### Class Name

`PricedItineraryExchangeCharge`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ChangeFeeWaived` | `Boolean` | Optional | Flag indicating if the change fee for the itinerary is waived. |
| `ChangeFeeRuleId` | `String` | Optional | ID of the rule for the waiving change fee. |
| `PriceDifferenceWaived` | `Boolean` | Optional | Flag indicating if price difference for the itinerary is waived. |
| `PriceDifferenceRuleId` | `String` | Optional | ID of the rule for the waiving price difference. |

##### Example (as JSON)

```json
{
  "changeFeeWaived": null,
  "changeFeeRuleId": null,
  "priceDifferenceWaived": null,
  "priceDifferenceRuleId": null
}
```

#### Prices

Contains multiple price components.

##### Class Name

`Prices`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Fare` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Taxes` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TaxesBreakdown` | [`List<TaxBreakdownElement>`](#tax-breakdown-element) | Optional | Taxes Breakdown. |
| `TotalMandatoryObFees` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ChangeFee` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ChangeFeeTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalWithoutDiscount` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `PriceDifference` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `RequiredMinThreshold` | [`Amount`](#amount) | Optional | Amount presenting class. |

##### Example (as JSON)

```json
{
  "fare": null,
  "taxes": null,
  "taxesBreakdown": null,
  "totalMandatoryObFees": null,
  "changeFee": null,
  "changeFeeTax": null,
  "total": null,
  "totalWithoutDiscount": null,
  "priceDifference": null,
  "requiredMinThreshold": null
}
```

#### Product Breakdown

Test.

##### Class Name

`ProductBreakdown`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `String` | Optional | Product label. |
| `BreakdownElements` | [`List<BreakdownElement>`](#breakdown-element) | Optional | Breakdown for this products price. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "label": null,
  "breakdownElements": null,
  "total": null
}
```

#### Product Payment

About available payment for each product.

##### Class Name

`ProductPayment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductType` | [`ProductType`](#product-type) | Optional | Product type. |
| `Price` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `PaymentList` | [`List<PaymentInfo>`](#payment-info) | Optional | List of allowed payments. |

##### Example (as JSON)

```json
{
  "productType": null,
  "price": null,
  "paymentList": null
}
```

#### Product Payment Combinability

All allowed payments broken down by payment type.

##### Class Name

`ProductPaymentCombinability`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductPayments` | [`List<ProductPayment>`](#product-payment) | Optional | List of all product payments. |
| `RefundDataModel` | [`RefundDataModel`](#refund-data-model) | Optional | All data related to refund in an Exchange. |

##### Example (as JSON)

```json
{
  "productPayments": null,
  "refundDataModel": null
}
```

#### Products Cart

Grouped results for /products responses.

##### Class Name

`ProductsCart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductsInformation` | [`BreakdownResponse`](#breakdown-response) | Optional | Provides breakdown for all products in current reservation. |
| `BaggageInformation` | [`BaggageDisclosure`](#baggage-disclosure) | Optional | Baggage/CarryOn/Embargo Information for selected flights. |
| `ContactAddress` | [`TripContactInfo`](#trip-contact-info) | Optional | Trip contact information. |

##### Example (as JSON)

```json
{
  "productsInformation": null,
  "baggageInformation": null,
  "contactAddress": null
}
```

#### Products Context

Context for products data recalculation. For MTO flow only awardSwichState is applicable.

##### Class Name

`ProductsContext`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AwardSwitchState` | [`AwardSwitchState`](#award-switch-state) | Optional | Defines products prices mode: CASH or POINTS. For CASH, products breakdown returned by service will be in cash.<br>For POINTS, products breakdown will be recalculated to points, if user is logged in and has sufficient balance.<br>Can be used in B2C flow. Switching to POINTS does not change flow to RBE. |
| `AirCustomPricing` | [`AirCustomPricing`](#air-custom-pricing) | Optional | Custom pricing details for selected itinerary supporting custom discount at itinerary part/itinerary level, tax override and endorsement text addition to booking. |
| `Reprice` | `Boolean` | Optional | Until now pricing was supported on select flights and in purchase.<br>This new property (value set to: true/false) in PUT method will allow additional re-price before user enters payment page or any other step in flow.<br>If it is not provided it will be treated as "false". |

##### Example (as JSON)

```json
{
  "awardSwitchState": null,
  "airCustomPricing": null,
  "reprice": null
}
```

#### Profile Input

Input information for profile created in the booking path.

##### Class Name

`ProfileInput`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Create` | `boolean` |  | Set to true to create profile during booking. |
| `Username` | `String` | Optional | User name for user profile create in booking path. |
| `Password` | `String` | Optional | Password for user profile create in booking path. |

##### Example (as JSON)

```json
{
  "create": false,
  "username": null,
  "password": null
}
```

#### Property Definition

##### Class Name

`PropertyDefinition`

##### Inherits From

[`AbstractPropertyDefinition`](#abstract-property-definition)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Min` | `Integer` | Optional | Minimum value of the property for example minimum value for weight/length/width/height. |
| `Max` | `Integer` | Optional | Maximum value of the property for example maximum value for weight/length/width/height. |
| `Unit` | `String` | Optional | Unit of the property. |

##### Example (as JSON)

```json
{
  "min": null,
  "max": null,
  "unit": null,
  "propertyName": null,
  "propertyType": null,
  "optional": null,
  "@type": null
}
```

#### Provider Type

Retail location type.

##### Class Name

`ProviderType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentCode` | `String` | Optional | Provider's payment code. |
| `Description` | `String` | Optional | Provider's name. |

##### Example (as JSON)

```json
{
  "paymentCode": null,
  "description": null
}
```

#### Pseudo City

Information about pseudocity that this pnr was created in.

##### Class Name

`PseudoCity`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PseudoCityCode` | `String` | Optional | PseudoCity code. |
| `StationId` | `String` | Optional | Station ID. |
| `AccountingCode` | `String` | Optional | Accounting code. |
| `OfficeStationCode` | `String` | Optional | Office station code. |
| `AccountingCity` | `String` | Optional | Accounting city. |

##### Example (as JSON)

```json
{
  "pseudoCityCode": null,
  "stationId": null,
  "accountingCode": null,
  "officeStationCode": null,
  "accountingCity": null
}
```

#### Queue Placement Data

Queue number and prefatory instruction code used to place the PNR in a specific queue.

##### Class Name

`QueuePlacementData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueueNumber` | `Integer` | Optional | Queue number used to specify the required queue. |
| `InstructionCode` | `Integer` | Optional | Prefatory instruction code for given queue. |

##### Example (as JSON)

```json
{
  "queueNumber": null,
  "instructionCode": null
}
```

#### Queue Placement Failure Details

Details related to queue placement failure.

##### Class Name

`QueuePlacementFailureDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reason` | `String` | Optional | The reason for failure during queue placement. |

##### Example (as JSON)

```json
{
  "reason": null
}
```

#### Received 3 Rd Party Data

Data obtained after returning from 3rd party redirection, required for the 2nd AFOP or Dynamic 3DS request.

##### Class Name

`Received3rdPartyData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResultCode` | `String` | Optional | Authorization operation result code. |
| `PaymentRef` | `String` | Optional | Reference number of the payment. |
| `ResponseCode` | `String` | Optional | Authorization operation response code. |
| `SupplierId` | `String` | Optional | Id of the supplier. |
| `MerchantId` | `String` | Optional | Id of the merchant. |
| `Mac` | `String` | Optional | Secret key used to validate response from the redirect. |
| `SmsCode` | `String` | Optional | SMS code for card authorization verification. |

##### Example (as JSON)

```json
{
  "resultCode": null,
  "paymentRef": null,
  "responseCode": null,
  "supplierId": null,
  "merchantId": null,
  "mac": null,
  "smsCode": null
}
```

#### Redirect Data

3ds details.

##### Class Name

`RedirectData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RedirectUrlData` | [`RedirectUrlData`](#redirect-url-data) | Optional | Data regarding AFOP or Dynamic 3ds redirection urls, required for the 1st request. |
| `PaRes` | `String` | Optional | PaRes needed for 2nd eurocommerce request. |
| `VerificationResult` | `String` | Optional | Verification Result for 3DS context second pass. |
| `TransactionId` | `String` | Optional | Transaction identification number. |

##### Example (as JSON)

```json
{
  "redirectUrlData": null,
  "paRes": null,
  "verificationResult": null,
  "transactionId": null
}
```

#### Redirect Info

JSON representation of payment redirect result.

##### Class Name

`RedirectInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TransactionId` | `String` | Optional | Remote payment transaction identifier - token for paypal, transactionId for 3ds. |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "transactionId": null,
  "@type": null
}
```

#### Redirect Url Data

Data regarding AFOP or Dynamic 3ds redirection urls, required for the 1st request.

##### Class Name

`RedirectUrlData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DefaultURL` | `String` | Optional | Holds the default URL where the client would like to post the result of the 3rd party verification. |
| `PendingURL` | `String` | Optional | Holds the URL where the client would like to post the result of the 3rd party verification while the operation is pending. |
| `ApprovedURL` | `String` | Optional | Holds the URL where the client would like to post the result of the 3rd party verification when it has been approved. |
| `DeclinedURL` | `String` | Optional | Holds the URL where the client would like to post the result of the 3rd party verification when it has been declined. |
| `ErrorURL` | `String` | Optional | Holds the URL where the client would like to post the result of the 3rd party verification when during the process an error has been encountered. |
| `CancelURL` | `String` | Optional | Holds the URL where the client would like to post the result of the 3rd party verification when the operation has been cancelled. |

##### Example (as JSON)

```json
{
  "defaultURL": null,
  "pendingURL": null,
  "approvedURL": null,
  "declinedURL": null,
  "errorURL": null,
  "cancelURL": null
}
```

#### Refund Data Model

All data related to refund in an Exchange.

##### Class Name

`RefundDataModel`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FopRefundDataList` | [`List<FopRefundData>`](#fop-refund-data) | Optional | Breakdown list of refund elements and form of payment information. |
| `TotalRefund` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `RefundToAccounting` | `Boolean` | Optional | Flag indicating if the refund is made to the accounting. |

##### Example (as JSON)

```json
{
  "fopRefundDataList": null,
  "totalRefund": null,
  "refundToAccounting": null
}
```

#### Refund Document Info

Information related to refunded document.

##### Class Name

`RefundDocumentInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DocumentDetails` | [`DocumentDetails`](#document-details) | Optional | Contains information about electronic documents: VCR or EMD. |
| `RefundPayments` | [`List<PnrPayment>`](#pnr-payment) | Optional | Payments related to the document. |
| `Passenger` | [`Passenger`](#passenger) | Optional | Passenger. |

##### Example (as JSON)

```json
{
  "documentDetails": null,
  "refundPayments": null,
  "passenger": null
}
```

#### Refund Target

Refund target.

##### Class Name

`RefundTarget`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Refund` | [`PnrPayment`](#pnr-payment) | Optional | Represents payment transaction. |
| `DocumentRefs` | [`List<RefundDocumentInfo>`](#refund-document-info) | Optional | References to refunded documents, VCRs and EMDs. |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### Remark

Agency profile information.

##### Class Name

`Remark`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RemarkText` | `String` | Optional | Agency remark text. |
| `SequenceNumber` | `Integer` | Optional | Remark sequence number. |

##### Example (as JSON)

```json
{
  "remarkText": null,
  "sequenceNumber": null
}
```

#### Remark Addition Failure Details

Details related to issues with adding a remarks.

##### Class Name

`RemarkAdditionFailureDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Remark` | `String` | Optional | A remark that has not been added. |
| `Reason` | `String` | Optional | A reason for failure when adding remarks. |

##### Example (as JSON)

```json
{
  "remark": null,
  "reason": null
}
```

#### Remarks and SS Rs

Messages that can be added to the PNR.

##### Class Name

`RemarksAndSSRs`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Remarks` | `List<String>` | Optional | List of remarks to be stored in the PNR. |
| `OtherServiceInformation` | `List<String>` | Optional | List of OSI to be stored in the PNR. |
| `SpecialServiceRequests` | [`List<SpecialServiceRequest>`](#special-service-request) | Optional | List of SSR (Special Service Request) to be stored in the PNR. |

##### Example (as JSON)

```json
{
  "remarks": null,
  "otherServiceInformation": null,
  "specialServiceRequests": null
}
```

#### Remote Payment

##### Class Name

`RemotePayment`

##### Inherits From

[`Payment`](#payment)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "amount": null,
  "@type": null
}
```

#### Remove External Product Request

Products that will be removed from the cart.

##### Class Name

`RemoveExternalProductRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Names` | `List<String>` | Optional | List of external products. |

##### Example (as JSON)

```json
{
  "names": null
}
```

#### Rental Rate

Rate definition associated with offered vehicle.

##### Class Name

`RentalRate`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EstimatedTotal` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `Rate` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `DailyEstimatedTotal` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `RateQualifier` | [`RateQualifier`](#rate-qualifier) | Optional | Indicates the type of rates applicable to the customer. |

##### Example (as JSON)

```json
{
  "estimatedTotal": null,
  "rate": null,
  "dailyEstimatedTotal": null,
  "rateQualifier": null
}
```

#### Required Properties

Properties required in order to reserve a given ancillary.

##### Class Name

`RequiredProperties`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PropertyDefinitionList` | [`List<AbstractPropertyDefinition>`](#abstract-property-definition) | Optional | Ancillary details required to reserve an ancillary. |

##### Example (as JSON)

```json
{
  "propertyDefinitionList": null
}
```

#### Reset Password Key Request

Required information to update a profile password.

##### Class Name

`ResetPasswordKeyRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Username` | `String` | Optional | Username used to retrieve the profile and to send a password reset link. |

##### Example (as JSON)

```json
{
  "username": null
}
```

#### Reset Password Request

Required information to update a profile password.

##### Class Name

`ResetPasswordRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Password` | `String` | Optional | Passenger's password that needs to be updated in the profile. |
| `ResetPasswordKey` | `String` | Optional | Encrypted key sent to the passenger. |

##### Example (as JSON)

```json
{
  "password": null,
  "resetPasswordKey": null
}
```

#### Reset Password Response

Response information of profile password reset action.

##### Class Name

`ResetPasswordResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | [`Result3`](#result-3) | Optional | Status of the password reset. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "result": null
}
```

#### Resource Configuration Definition

Configuration definition for basic request validation.

##### Class Name

`ResourceConfigurationDefinition`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryParams` | [`List<ObjectConfig>`](#object-config) | Optional | Query parameters required with the request. |
| `RequestBody` | [`ObjectConfig`](#object-config) | Optional | - |

##### Example (as JSON)

```json
{
  "queryParams": null,
  "requestBody": null
}
```

#### Result Mapping

Result combinability mapping.

##### Class Name

`ResultMapping`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SimplifiedRoundTripMapping` | `Map<String, Integer>` | Optional | Simple one to many combinability mapping (based on shoppingBasketHashCodes). This form of combinability is returned in case of the Legacy Shopping. |
| `CombinabilityMapping` | [`List<BrandedFareItineraryOfferMapping>`](#branded-fare-itinerary-offer-mapping) | Optional | More complex combinability mapping -Array of "from" to Array of "to" (based on shoppingBasketHashCodes). It is returned in case of the IBF (Advanced Shopping). |

##### Example (as JSON)

```json
{
  "simplifiedRoundTripMapping": null,
  "combinabilityMapping": null
}
```

#### Retail Payment

##### Class Name

`RetailPayment`

##### Inherits From

[`Payment`](#payment)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "amount": null,
  "@type": null
}
```

#### Retail Reference

Retail payment references number and retail locations.

##### Class Name

`RetailReference`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Providers` | [`List<ProviderType>`](#provider-type) | Optional | Retail locations list. |
| `ReferenceNumber` | `String` | Optional | Reference number for the payment. |

##### Example (as JSON)

```json
{
  "providers": null,
  "referenceNumber": null
}
```

#### Retained Offer

Represents offer for retained itinerary part.

##### Class Name

`RetainedOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RetainedItineraryPart` | [`ItineraryPart`](#itinerary-part) | Optional | - |
| `ActualPrice` | [`Prices`](#prices) | Optional | Contains multiple price components. |

##### Example (as JSON)

```json
{
  "retainedItineraryPart": null,
  "actualPrice": null
}
```

#### Retrieve Agency Profile Response

Response information of agency profile.

##### Class Name

`RetrieveAgencyProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Status`](#status) | Optional | Result status of the agency profile retrieval. The field is deprecated and will be removed in a subsequent major release. |
| `AgencyProfile` | [`AgencyProfile`](#agency-profile) | Optional | Agency's profile information. |
| `CreditLimitInfo` | [`AgencyCreditLimitInfo`](#agency-credit-limit-info) | Optional | Agency account information. |

##### Example (as JSON)

```json
{
  "status": null,
  "agencyProfile": null,
  "creditLimitInfo": null
}
```

#### Retrieve Agent Profile Response

Response information for agent profile retrieval operation.

##### Class Name

`RetrieveAgentProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | [`Result2`](#result-2) | Optional | Status of the agent profile retrieval operation. The field is deprecated and will be removed in a subsequent major release. |
| `AgentProfile` | [`AgentProfile`](#agent-profile) | Optional | Agent's profile information. |

##### Example (as JSON)

```json
{
  "result": null,
  "agentProfile": null
}
```

#### Retrieve Profile Response

Response information of profile service.

##### Class Name

`RetrieveProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Profile` | [`UserProfile`](#user-profile) | Optional | Passenger's profile information. |
| `Result` | [`Result7`](#result-7) | Optional | Result status of the profile retrieval. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "profile": null,
  "result": null
}
```

#### Route

Returns available routes.

##### Class Name

`Route`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OriginCode` | `String` | Optional | Origin location code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `DestinationCode` | `String` | Optional | Destination location code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |

##### Example (as JSON)

```json
{
  "originCode": null,
  "destinationCode": null
}
```

#### Rule Information

This model contains evaluation result of the failed rule.

##### Class Name

`RuleInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RuleName` | `String` | Optional | Name of the failing rule. |
| `EvaluationResult` | [`EvaluationResult`](#evaluation-result) | Optional | Evaluation result of the rule. |
| `FailureReason` | `String` | Optional | Reason of the rule failure. |

##### Example (as JSON)

```json
{
  "ruleName": null,
  "evaluationResult": null,
  "failureReason": null
}
```

#### Rules

Rules contains the information about Mini Fare Rules.

##### Class Name

`Rules`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItineraryPart` | [`List<ItineraryPart>`](#itinerary-part) | Optional | Associated itinerary part. |
| `PassengerFareRule` | [`List<PassengerFareRule>`](#passenger-fare-rule) | Optional | Passenger fare rule for each passenger type. |

##### Example (as JSON)

```json
{
  "itineraryPart": null,
  "passengerFareRule": null
}
```

#### Rules Evaluation

PNR evaluation rule details.

##### Class Name

`RulesEvaluation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TripOption` | [`TripOption`](#trip-option) | Optional | Trip option. |
| `RuleName` | `String` | Optional | Rule Name for the trip option. |
| `Enabled` | `Boolean` | Optional | Flag indicating the status of the rule (if enabled). |
| `FailureReason` | `String` | Optional | The reason of the failure (if rule has failed). |

##### Example (as JSON)

```json
{
  "tripOption": null,
  "ruleName": null,
  "enabled": null,
  "failureReason": null
}
```

#### Rules Evaluation Result

This model contains list of applied rules and failed rules to the service.

##### Class Name

`RulesEvaluationResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppliedRules` | `List<String>` | Optional | List of successfully applied rules with rule names. |
| `FailedRules` | [`List<RuleInformation>`](#rule-information) | Optional | List of failed rules. |

##### Example (as JSON)

```json
{
  "appliedRules": null,
  "failedRules": null
}
```

#### Search Itinerary Part

Search itinerary part.

##### Class Name

`SearchItineraryPart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `From` | [`Location`](#location) | Optional | Location information. Code may be city or code. |
| `To` | [`Location`](#location) | Optional | Location information. Code may be city or code. |
| `When` | [`Time`](#time) | Optional | Desired departure time. |
| `SelectedOfferRef` | `Integer` | Optional | Selected branded itinerary part refs. |
| `PlusMinusDays` | `Integer` | Optional | Number of the alternate pricing days that will be shown in the matrix before and after the selected date. In the format plus/minus 2 days for the matrix 5x5. |

##### Example (as JSON)

```json
{
  "from": null,
  "to": null,
  "when": null,
  "selectedOfferRef": null,
  "plusMinusDays": null
}
```

#### Search Result Meta Data

Additional results data.

##### Class Name

`SearchResultMetaData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Branded` | `Boolean` | Optional | Flag indicating if the returned offer is branded. |
| `MultipleDateResult` | `Boolean` | Optional | Flag indicating if there is multiple date result (either with alternative dates or a calendar result). |
| `ComposedResult` | `Boolean` | Optional | Flag indicating if the result is composed of multiple basic search results. This field specifies if some results might no be combinable. |
| `InterlineRoute` | `Boolean` | Optional | Flag indicating if the search result is on the interline route. |
| `ContextShopping` | `Boolean` | Optional | Flag indicating if there is the context shopping search result. |

##### Example (as JSON)

```json
{
  "branded": null,
  "multipleDateResult": null,
  "composedResult": null,
  "interlineRoute": null,
  "contextShopping": null
}
```

#### Seat

Seat/slot details.

##### Class Name

`Seat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SlotCharacteristics` | `List<String>` | Optional | Seat/slot characteristics. |
| `StorefrontSlotCode` | `String` | Optional | Storefront slot code. |
| `Available` | `Boolean` | Optional | Flag indicating if seat/slot is available. |
| `Code` | `String` | Optional | Seat code. |
| `Designations` | `List<String>` | Optional | Seat designations. |
| `Entitled` | `Boolean` | Optional | Flag indicating whether passenger's Frequent Flyer tier level entitles him/her to have a free seat. |
| `FeeWaived` | `Boolean` | Optional | Flag indicating whether passenger's Frequent Flyer tier level entitles him/her to have a fee waiver. |
| `EntitledRuleId` | `String` | Optional | Dynamic retailer rule number which triggers the entitlement. |
| `FeeWaivedRuleId` | `String` | Optional | Dynamic retailer rule number which triggers the fee waiver. |
| `SeatCharacteristics` | `List<String>` | Optional | Seat characteristics. |
| `Limitations` | `List<String>` | Optional | Seat limitations. |
| `RefundIndicator` | [`RefundIndicator1`](#refund-indicator-1) | Optional | Refundable seat status. |
| `FreeOfCharge` | `Boolean` | Optional | Flag indicating if the seat is free. |
| `DiscountInfo` | [`DiscountInfo`](#discount-info) | Optional | Discount info details. |
| `Prices` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Taxes` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Total` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginallySelected` | `Boolean` | Optional | Flag indicating if seat/slot is originally selected. |

##### Example (as JSON)

```json
{
  "slotCharacteristics": null,
  "storefrontSlotCode": null,
  "available": null,
  "code": null,
  "designations": null,
  "entitled": null,
  "feeWaived": null,
  "entitledRuleId": null,
  "feeWaivedRuleId": null,
  "seatCharacteristics": null,
  "limitations": null,
  "refundIndicator": null,
  "freeOfCharge": null,
  "discountInfo": null,
  "prices": null,
  "taxes": null,
  "total": null,
  "originallySelected": null
}
```

#### Seat Map

Seat map details.

##### Class Name

`SeatMap`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RowsDisabledCauses` | `List<String>` | Optional | Rows disabled causes. |
| `Aircraft` | `String` | Optional | Aircraft name. |
| `Cabins` | [`List<Cabin>`](#cabin) | Optional | Seat map cabins. |

##### Example (as JSON)

```json
{
  "rowsDisabledCauses": null,
  "aircraft": null,
  "cabins": null
}
```

#### Seat Operation

Seat selection/removal request details for specific seat, segment and passenger.

##### Class Name

`SeatOperation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Warning/info messages response for the current POST seat map request. |
| `SeatCode` | `String` | Optional | Code of selected/removed seat. To select a seat the request should supply a value for seatCode; to unselect a seat, the request should supply null. |
| `SelectedSegment` | [`SelectedSegment`](#selected-segment) | Optional | Selected segment for seat. |
| `PassengerIndex` | `Integer` | Optional | Index of the selected passenger expressed as a positive integer. |

##### Example (as JSON)

```json
{
  "messages": null,
  "seatCode": null,
  "selectedSegment": null,
  "passengerIndex": null
}
```

#### Seat Operation Result

Seat operation request result for specific seat, selected segment and passenger.

##### Class Name

`SeatOperationResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SeatOperation` | [`SeatOperation`](#seat-operation) | Optional | Seat selection/removal request details for specific seat, segment and passenger. |
| `Successful` | `Boolean` | Optional | Flag indicating if operation finished successfully. |

##### Example (as JSON)

```json
{
  "seatOperation": null,
  "successful": null
}
```

#### Seat Price

Seat price.

##### Class Name

`SeatPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BasePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginalBasePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginalTotalTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `OriginalTotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "basePrice": null,
  "totalTax": null,
  "totalPrice": null,
  "originalBasePrice": null,
  "originalTotalTax": null,
  "originalTotalPrice": null
}
```

#### Seat Request

Seat selection/removal request details.

##### Class Name

`SeatRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SeatOperations` | [`List<SeatOperation>`](#seat-operation) | Optional | List with details for seat operations. The request should contain an instance of seatOperations for each passenger/seat/flight combination that has been selected. |

##### Example (as JSON)

```json
{
  "seatOperations": null
}
```

#### Seat Request Result

Result for specific seat operation.

##### Class Name

`SeatRequestResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Messages pertaining to seat request results. |
| `SeatOperationResults` | [`List<SeatOperationResult>`](#seat-operation-result) | Optional | List with results from seat operations. |

##### Example (as JSON)

```json
{
  "messages": null,
  "seatOperationResults": null
}
```

#### Seat Row

Seat row details.

##### Class Name

`SeatRow`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RowNumber` | `Integer` | Optional | Seat row number. |
| `SeatCodes` | `List<String>` | Optional | Seats code in row. |
| `Seats` | [`List<Seat>`](#seat) | Optional | Seats details in row. |

##### Example (as JSON)

```json
{
  "rowNumber": null,
  "seatCodes": null,
  "seats": null
}
```

#### Seats Itinerary Part

Itinerary seat result.

##### Class Name

`SeatsItineraryPart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentSeatMaps` | [`List<SegmentSeatMap>`](#segment-seat-map) | Optional | Contains segment's seat map details for the itinerary. |

##### Example (as JSON)

```json
{
  "segmentSeatMaps": null
}
```

#### Seats Remaining

Information about remaining seats count and if it is considered low by backend services.

##### Class Name

`SeatsRemaining`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Count` | `Integer` | Optional | Number of remaining seats. |
| `LowAvailability` | `Boolean` | Optional | Flag indicating if current seat count is considered as low. This is just a guideline for the front-end. |

##### Example (as JSON)

```json
{
  "count": null,
  "lowAvailability": null
}
```

#### Seats Result

Seat result.

##### Class Name

`SeatsResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Messages concerning seat result. |
| `SeatsItineraryParts` | [`List<SeatsItineraryPart>`](#seats-itinerary-part) | Optional | Itinerary part which contains segment's seat map data. |
| `SelectedSeats` | [`List<SelectedSeat>`](#selected-seat) | Optional | Selected seat per segment and per passenger. |
| `OldPaidSeats` | [`List<OldPaidSeat>`](#old-paid-seat) | Optional | Information about old paid seats. |

##### Example (as JSON)

```json
{
  "messages": null,
  "seatsItineraryParts": null,
  "selectedSeats": null,
  "oldPaidSeats": null
}
```

#### Security Data

Security information. Contains current timestamp and fingerprint.

##### Class Name

`SecurityData`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Fingerprint` | `String` | Optional | Hex-encoded hash generated for security purposes. |
| `Timestamp` | `Long` | Optional | Current UNIX timestamp (seconds passed since 1970-01-01 UTC). |

##### Example (as JSON)

```json
{
  "fingerprint": null,
  "timestamp": null
}
```

#### Security Question

Passenger's consent information.

##### Class Name

`SecurityQuestion`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QuestionCode` | `String` | Optional | Security question code. |
| `AnswerHash` | `String` | Optional | Answer for security question. |

##### Example (as JSON)

```json
{
  "questionCode": null,
  "answerHash": null
}
```

#### Segment

##### Class Name

`Segment`

##### Inherits From

[`TravelPart`](#travel-part)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentOfferInformation` | [`SegmentOfferInformation`](#segment-offer-information) | Optional | Additional offerings information related to segment. |
| `Duration` | `Long` | Optional | Flight duration expressed in minutes. |
| `CabinClass` | [`CabinClass`](#cabin-class) | Optional | Cabin class name. |
| `Equipment` | `String` | Optional | Aircraft equipment code. |
| `AircraftLeaseText` | `String` | Optional | Aircraft lease disclosure text. |
| `Flight` | [`Flight`](#flight) | Optional | Flight details. |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time, this is local to the origin airport (timestamp format: YYYY-MM-DD'T'HH:MM:SS). |
| `Arrival` | `LocalDateTime` | Optional | Arrival date time, this is local to the destination airport (timestamp format: YYYY-MM-DD'T'HH:MM:SS). |
| `SegmentStatusCode` | [`SegmentStatusCode`](#segment-status-code) | Optional | Information about segment status in the PNR. |
| `BookingClass` | `String` | Optional | Booking class - a single character code (each airline may be different - F and P are usually first class, C and J business and others such as Y, M, B, H, K, Q, L, V, etc. are economy.). |
| `LayoverDuration` | `Long` | Optional | Stops duration for the particular segment. |
| `PreviouslySelectedBookingClass` | `String` | Optional | Booking class which has been changed due to the RBD being sold out between subsequent context search calls. |
| `FareBasis` | `String` | Optional | Fare basis code. |
| `SubjectToGovernmentApproval` | `Boolean` | Optional | Flag indicating that this flight is subjected to government approval. Such flights might be cancelled if approval doesn't get through. |

##### Example (as JSON)

```json
{
  "segmentOfferInformation": null,
  "duration": null,
  "cabinClass": null,
  "equipment": null,
  "aircraftLeaseText": null,
  "flight": null,
  "origin": null,
  "destination": null,
  "departure": null,
  "arrival": null,
  "segmentStatusCode": null,
  "bookingClass": null,
  "layoverDuration": null,
  "previouslySelectedBookingClass": null,
  "fareBasis": null,
  "subjectToGovernmentApproval": null,
  "@type": null
}
```

#### Segment Disclosure

Passenger baggage/carry-on and embargo information for this segment.

##### Class Name

`SegmentDisclosure`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerBaggageDisclosure` | [`List<PassengerBaggageDisclosure>`](#passenger-baggage-disclosure) | Optional | Baggage/carry-on allowance information for each passenger type. |
| `EmbargoInformation` | [`EmbargoInformation`](#embargo-information) | Optional | Embargo information for selected flights. |
| `Segment` | [`SegmentKey`](#segment-key) | Optional | Segment key to associate fare rules, seat map segment etc. |

##### Example (as JSON)

```json
{
  "passengerBaggageDisclosure": null,
  "embargoInformation": null,
  "segment": null
}
```

#### Segment Fare Rules

Segment association of fare rules (multiple segments can have same fare rules).

##### Class Name

`SegmentFareRules`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentKeys` | [`List<SegmentKey>`](#segment-key) | Optional | List of segments associated for those rules. |
| `FareBasisRules` | [`FareBasisRules`](#fare-basis-rules) | Optional | Fare rules for a specific fare basis code. |

##### Example (as JSON)

```json
{
  "segmentKeys": null,
  "fareBasisRules": null
}
```

#### Segment Key

Segment key to associate fare rules, seat map segment etc.

##### Class Name

`SegmentKey`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time, in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `Arrival` | `LocalDateTime` | Optional | Arrival date time, in the format: YYYY-MM-DD'T'HH:MM:SS. |

##### Example (as JSON)

```json
{
  "origin": null,
  "destination": null,
  "departure": null,
  "arrival": null
}
```

#### Segment Offer Information

Additional offerings information related to segment.

##### Class Name

`SegmentOfferInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FlightsMiles` | `Integer` | Optional | Flight miles. |
| `FlightAncillaries` | [`FlightAncillaries`](#flight-ancillaries) | Optional | Contains list of ancillaries available to brand and/or flight. |
| `AwardFare` | `Boolean` | Optional | Flag indicating if this segment is an award fare. |

##### Example (as JSON)

```json
{
  "flightsMiles": null,
  "flightAncillaries": null,
  "awardFare": null
}
```

#### Segment Seat Map

Seat map for segment result.

##### Class Name

`SegmentSeatMap`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Warning/error messages related to the downline response for this segment seat map (for preview seat map). |
| `PassengerSeatMaps` | [`List<PassengerSeatMap>`](#passenger-seat-map) | Optional | Seatmaps for passengers for this segment (does not apply for preview seat map). |
| `Segment` | [`Segment`](#segment) | Optional | - |
| `SeatMap` | [`SeatMap`](#seat-map) | Optional | Seat map details. |

##### Example (as JSON)

```json
{
  "messages": null,
  "passengerSeatMaps": null,
  "segment": null,
  "seatMap": null
}
```

#### Segment Status Code

Information about segment status in the PNR.

##### Class Name

`SegmentStatusCode`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Status code of the segment that is present on the host. |
| `SegmentStatus` | [`SegmentStatus`](#segment-status) | Optional | Name of the segment status that is passed to the Digital Connect. |

##### Example (as JSON)

```json
{
  "code": null,
  "segmentStatus": null
}
```

#### Segment Upgrade Info

Information about segment upgrade.

##### Class Name

`SegmentUpgradeInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Segment` | [`Segment`](#segment) | Optional | - |
| `BookingClass` | `String` | Optional | Booking class this segment is or will be upgraded to. |
| `Status` | [`Status4`](#status-4) | Optional | Status of the upgrade. |
| `PassengerUpgradePrices` | [`List<PassengerUpgradePrice>`](#passenger-upgrade-price) | Optional | Upgrade prices of waitlisted segments per passenger. |

##### Example (as JSON)

```json
{
  "segment": null,
  "bookingClass": null,
  "status": null,
  "passengerUpgradePrices": null
}
```

#### Select Insurance Request

Insurance offer to be selected.

##### Class Name

`SelectInsuranceRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductID` | `String` | Optional | Identifying code for the selected insurance product; must be a valid code. Insurance Product ID from GET insurance request (validated against data returned from GET insurance; value must be the same as previously returned from GET insurance). |

##### Example (as JSON)

```json
{
  "productID": null
}
```

#### Selected Ancillary

Information about selected ancillary.

##### Class Name

`SelectedAncillary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AncillaryCode` | `String` | Optional | Code of the ancillary. |
| `AssignedQuantity` | `Integer` | Optional | Quantity of the specified ancillary. |
| `SsrProperties` | [`SelectedAncillarySSRInfo`](#selected-ancillary-ssr-info) | Optional | PNR Special Service Request Remark about selected ancillary. |

##### Example (as JSON)

```json
{
  "ancillaryCode": null,
  "assignedQuantity": null,
  "ssrProperties": null
}
```

#### Selected Ancillary SSR Info

PNR Special Service Request Remark about selected ancillary.

##### Class Name

`SelectedAncillarySSRInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Ancillary Special Service Request (SSR) code. |
| `Text` | `String` | Optional | Represents PNR ancillary Special Service Request (SSR) full text. |

##### Example (as JSON)

```json
{
  "code": null,
  "text": null
}
```

#### Selected Insurance

Insurance offer selected.

##### Class Name

`SelectedInsurance`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InsuranceOffer` | [`InsuranceOffer`](#insurance-offer) | Optional | Insurance offer details. |
| `Successful` | `Boolean` | Optional | Flag indicating if an insurance offer has been successfully selected. |

##### Example (as JSON)

```json
{
  "insuranceOffer": null,
  "successful": null
}
```

#### Selected Passenger Ancillary

Selected passenger ancillary details.

##### Class Name

`SelectedPassengerAncillary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Index` | `Integer` | Optional | Index of the passenger in the reservation, expressed as a positive integer. |
| `Quantity` | `Integer` | Optional | New quantity of the selected ancillary, set 0 if you want to remove the ancillary. |
| `AncillarySSR` | [`AbstractAncillarySSR`](#abstract-ancillary-ssr) | Optional | Special Service Request information for the ancillary. |
| `AncillaryOverridePrice` | [`AncillaryOverridePrice`](#ancillary-override-price) | Optional | Overridden price for the ancillary offer. Contains base, taxes and override message. |

##### Example (as JSON)

```json
{
  "index": null,
  "quantity": null,
  "ancillarySSR": null,
  "ancillaryOverridePrice": null
}
```

#### Selected Seat

Selected seat details per segment and passenger.

##### Class Name

`SelectedSeat`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SeatCode` | `String` | Optional | Selected seat code. |
| `SegmentKey` | [`SegmentKey`](#segment-key) | Optional | Segment key to associate fare rules, seat map segment etc. |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger expressed as a positive integer. |

##### Example (as JSON)

```json
{
  "seatCode": null,
  "segmentKey": null,
  "passengerIndex": null
}
```

#### Selected Segment

Selected segment for seat.

##### Class Name

`SelectedSegment`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |

##### Example (as JSON)

```json
{
  "origin": null,
  "destination": null,
  "departure": null
}
```

#### Selected Segment Message Details

Selected segment information.

##### Class Name

`SelectedSegmentMessageDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |

##### Example (as JSON)

```json
{
  "origin": null,
  "destination": null,
  "departure": null
}
```

#### Selected Travel Part

Selected travel part.

##### Class Name

`SelectedTravelPart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Departure` | `LocalDateTime` | Optional | Departure date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |
| `Type` | [`Type3`](#type-3) | Optional | Type of the Travel Part. |

##### Example (as JSON)

```json
{
  "origin": null,
  "destination": null,
  "departure": null,
  "type": null
}
```

#### Service Info

Basic information about service.

##### Class Name

`ServiceInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BasePath` | `String` | Optional | Base path of the service where it can be accessed. |
| `Enabled` | `Boolean` | Optional | Flag indicating whether the service is enabled for the storefront or not, using true or false values. True represents the enabled service whereas false means it is not. |

##### Example (as JSON)

```json
{
  "basePath": null,
  "enabled": null
}
```

#### Special Preferences

Passenger Special Preferences.

##### Class Name

`SpecialPreferences`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MealPreference` | [`MealPreference`](#meal-preference) | Optional | Choice of meal. |
| `SeatPreference` | [`SeatPreference`](#seat-preference) | Optional | Seat preference. |
| `SpecialRequests` | `List<String>` | Optional | Special Requests selected by the passenger. |

##### Example (as JSON)

```json
{
  "mealPreference": null,
  "seatPreference": null,
  "specialRequests": null
}
```

#### Special Service Request

Special Service Request (SSR) to be stored in the PNR.

##### Class Name

`SpecialServiceRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger associated with the Special Service Request (SSR), expressed as a positive integer. |
| `PassengerNameNumber` | `String` | Optional | Passenger's name number. Either input passenger name number or passenger index, no need to enter both. |
| `Code` | `String` | Optional | Special Service Request (SSR) code. |
| `Description` | `String` | Optional | Special Service Request (SSR) description. |
| `SegmentKey` | [`SegmentKey`](#segment-key) | Optional | Segment key to associate fare rules, seat map segment etc. |

##### Example (as JSON)

```json
{
  "passengerIndex": null,
  "passengerNameNumber": null,
  "code": null,
  "description": null,
  "segmentKey": null
}
```

#### Stop Airport

Stop airport details.

##### Class Name

`StopAirport`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Airport` | `String` | Optional | Stop airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Arrival` | `LocalDateTime` | Optional | Arrival date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |
| `Departure` | `LocalDateTime` | Optional | Departure date time (timestamp in the format: YYYY-MM-DD'T'HH:MM:SS). |
| `ElapsedTime` | `Integer` | Optional | Flight time from departure airport to layover airport expressed in minutes. |
| `Duration` | `Integer` | Optional | Time at the stop airport expressed in minutes. |

##### Example (as JSON)

```json
{
  "airport": null,
  "arrival": null,
  "departure": null,
  "elapsedTime": null,
  "duration": null
}
```

#### String Message Details

Basic message details in the plain text format.

##### Class Name

`StringMessageDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Value` | `String` | Optional | Message details. |

##### Example (as JSON)

```json
{
  "value": null
}
```

#### Sub Type Info

Configuration definition for basic subtype validation when object can be defined by many types.

##### Class Name

`SubTypeInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `String` | Optional | Name of the type that determines sub-type of the object. |
| `ValidationInfo` | `Map<String, String>` | Optional | Basic validation configuration for the specified field. |
| `ContextualValidation` | [`List<ContextualValidationInfo>`](#contextual-validation-info) | Optional | Configuration definitions for contextual subtypes if there are many contextual validation subtypes. |
| `Fields` | [`List<ObjectConfig>`](#object-config) | Optional | Configuration definition for object fields. |

##### Example (as JSON)

```json
{
  "@type": null,
  "@validationInfo": null,
  "@contextualValidation": null,
  "fields": null
}
```

#### Tax

JSON representation of the tax override parameter.

##### Class Name

`Tax`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Code associated with the tax where the tax amount will be overridden. |
| `Amount` | `Double` | Optional | Tax amount which will override the current tax. |

##### Example (as JSON)

```json
{
  "code": null,
  "amount": null
}
```

#### Tax Breakdown Element

Tax Breakdown Element.

##### Class Name

`TaxBreakdownElement`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `String` | Optional | Label for this breakdown element in the form of machine readable or parsable code. Defined per product type so it can be used in translations. |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "label": null,
  "price": null
}
```

#### Tax Price

Tax price for the ancillary offer.

##### Class Name

`TaxPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Tax code. |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "code": null,
  "price": null
}
```

#### Third Party Redirect Info

##### Class Name

`ThirdPartyRedirectInfo`

##### Inherits From

[`RedirectInfo`](#redirect-info)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PayerAuthenticationRequestForm` | `String` | Optional | Payer authentication request html form. |
| `VerificationResult` | `String` | Optional | Result of the payment verification step. |

##### Example (as JSON)

```json
{
  "payerAuthenticationRequestForm": null,
  "verificationResult": null,
  "transactionId": null,
  "@type": null
}
```

#### Third Party Redirect Return

##### Class Name

`ThirdPartyRedirectReturn`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RedirectData` | [`RedirectData`](#redirect-data) | Optional | 3ds details. |
| `TransactionId` | `String` | Optional | Transaction ID associated with this payment. |
| `Received3rdPartyData` | [`Received3rdPartyData`](#received-3-rd-party-data) | Optional | Data obtained after returning from 3rd party redirection, required for the 2nd AFOP or Dynamic 3DS request. |

##### Example (as JSON)

```json
{
  "redirectData": null,
  "transactionId": null,
  "received3rdPartyData": null,
  "amount": null,
  "@type": null
}
```

#### Ticketing Fee Waiving Reason

Waiver code with reason code and reason description.

##### Class Name

`TicketingFeeWaivingReason`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReasonCode` | `String` | Optional | Reason Code for waive. |
| `ReasonDesc` | `String` | Optional | Reason description for waive. |

##### Example (as JSON)

```json
{
  "reasonCode": null,
  "reasonDesc": null
}
```

#### Ticketing Fee Waiving Reasons

Waiver codes form Ticketing Fee Waiving Reason List.

##### Class Name

`TicketingFeeWaivingReasons`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TicketingFeeWaivingReasonList` | [`List<TicketingFeeWaivingReason>`](#ticketing-fee-waiving-reason) | Optional | List of waiver codes from Ticketing Fee Waiving Reason List. |

##### Example (as JSON)

```json
{
  "ticketingFeeWaivingReasonList": null
}
```

#### Time

Desired departure time.

##### Class Name

`Time`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Date` | `LocalDate` | Optional | Specific date in the format: YYYY-MM-DD. |

##### Example (as JSON)

```json
{
  "date": null
}
```

#### Time to Ticket

Time to ticket.

##### Class Name

`TimeToTicket`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Days` | `Integer` | Optional | Days left. |
| `Hours` | `Integer` | Optional | Hours left. |
| `Minutes` | `Integer` | Optional | Minutes left. |
| `Seconds` | `Integer` | Optional | Seconds left. |

##### Example (as JSON)

```json
{
  "days": null,
  "hours": null,
  "minutes": null,
  "seconds": null
}
```

#### Travel Bank

##### Class Name

`TravelBank`

##### Inherits From

[`Payment`](#payment)

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "amount": null,
  "@type": null
}
```

#### Travel Bank Details

TravelBank account details.

##### Class Name

`TravelBankDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AvailableAmountForTrip` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `AvailableFunds` | [`Amount`](#amount) | Optional | Amount presenting class. |
| `Subbalances` | [`Map<String, Subbalances>`](#subbalances) | Optional | All available subbalances on the account. |
| `BalanceElements` | [`Map<String, BalanceElements>`](#balance-elements) | Optional | Amounts for each PriceComponentApplicability could be paid. |
| `PriceElements` | [`Map<String, PriceElements>`](#price-elements) | Optional | Amounts for each PriceComponentApplicability. |

##### Example (as JSON)

```json
{
  "availableAmountForTrip": null,
  "availableFunds": null,
  "subbalances": null,
  "balanceElements": null,
  "priceElements": null
}
```

#### Travel Bank Refund

##### Class Name

`TravelBankRefund`

##### Inherits From

[`RefundTarget`](#refund-target)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceInfo` | [`AccountBalanceInfo`](#account-balance-info) | Optional | Account balance info before and after transaction. |
| `TravelBankLogin` | `String` | Optional | Travel Bank login ID. |

##### Example (as JSON)

```json
{
  "balanceInfo": null,
  "travelBankLogin": null,
  "refund": null,
  "documentRefs": null,
  "@type": null
}
```

#### Travel Part

Parent class for all travel part data: Segment, ItineraryPart, Itinerary.

##### Class Name

`TravelPart`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `String` | Optional | - |

##### Example (as JSON)

```json
{
  "@type": null
}
```

#### Travel Part Additional Details

Additional details for specific travel part.

##### Class Name

`TravelPartAdditionalDetails`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |
| `Passengers` | [`List<PassengerWithFeatures>`](#passenger-with-features) | Optional | Passengers and related features. |
| `Eligibilities` | [`List<Eligibility>`](#eligibility) | Optional | List of eligibilities for associated travel part. |
| `EligibilitiesCodes` | [`Map<String, EligibilitiesCodes>`](#eligibilities-codes) | Optional | Codes of eligibilities for associated travel part, that UI can translate to a respective info or error message. |

##### Example (as JSON)

```json
{
  "travelPart": null,
  "passengers": null,
  "eligibilities": null,
  "eligibilitiesCodes": null
}
```

#### Travel Part Offer

Ancillary offer limited to a specific travel part.

##### Class Name

`TravelPartOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |
| `PassengerOffers` | [`List<PassengerOffer>`](#passenger-offer) | Optional | List of ancillary offers for passengers. |
| `AvailableInventory` | `Integer` | Optional | Quantity of ancillary available for all passengers on specific travel part. |

##### Example (as JSON)

```json
{
  "travelPart": null,
  "passengerOffers": null,
  "availableInventory": null
}
```

#### Travel Part Upgrade Offer

Upgrade offer information for a specific travel part.

##### Class Name

`TravelPartUpgradeOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TravelPart` | [`TravelPart`](#travel-part) | Optional | - |
| `Status` | [`Status3`](#status-3) | Optional | Status of the upgrade offer for travel part. |
| `Selected` | `Boolean` | Optional | Flag indicating whether this offer has already been selected. |
| `PassengerPrices` | [`List<PassengerUpgradeOfferPrice>`](#passenger-upgrade-offer-price) | Optional | Upgrade offer prices for passengers. |
| `TotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "travelPart": null,
  "status": null,
  "selected": null,
  "passengerPrices": null,
  "totalPrice": null
}
```

#### Travel Preferences

Passenger's travel preferences.

##### Class Name

`TravelPreferences`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SeatPreference` | [`SeatPreference`](#seat-preference) | Optional | Seat preference. |
| `MealPreference` | [`MealPreference1`](#meal-preference-1) | Optional | Choice of meal. |
| `SpecialRequests` | `List<String>` | Optional | List of Special Service Request (SSR) codes from the passenger's profile. |

##### Example (as JSON)

```json
{
  "seatPreference": null,
  "mealPreference": null,
  "specialRequests": null
}
```

#### Trip Contact Info

Trip contact information.

##### Class Name

`TripContactInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TripContactInfoType` | [`TripContactInfoType`](#trip-contact-info-type) |  | Trip contact information address type. |
| `PassengerName` | [`PassengerName`](#passenger-name) | Optional | Passenger name information. |
| `Email` | `String` | Optional | Passenger's contact email address. |
| `Phone` | [`Phone`](#phone) | Optional | Phone details. |
| `Address` | [`AddressDetails`](#address-details) | Optional | Passenger's Address Information. |
| `CompanyName` | `String` | Optional | Passenger's company name. |

##### Example (as JSON)

```json
{
  "tripContactInfoType": "PRIVATE",
  "passengerName": null,
  "email": null,
  "phone": null,
  "address": null,
  "companyName": null
}
```

#### Trip Info

Trip or reservation information.

##### Class Name

`TripInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Pnr` | `String` | Optional | Record locator. |
| `State` | [`State`](#state) | Optional | State of the trip. |
| `Origin` | `String` | Optional | Origin airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `Destination` | `String` | Optional | Destination airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |
| `DepartureDate` | `LocalDateTime` | Optional | Departure date in the format: YYYY-MM-DD'T'HH:MM:SS. |
| `ItineraryParts` | [`List<ItineraryPart>`](#itinerary-part) | Optional | Itinerary parts for the trip. |

##### Example (as JSON)

```json
{
  "pnr": null,
  "state": null,
  "origin": null,
  "destination": null,
  "departureDate": null,
  "itineraryParts": null
}
```

#### Update Agency Profile Request

Input information of agency profile service.

##### Class Name

`UpdateAgencyProfileRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyProfile` | [`AgencyProfile`](#agency-profile) | Optional | Agency's profile information. |

##### Example (as JSON)

```json
{
  "agencyProfile": null
}
```

#### Update Agency Profile Response

Response information of update agency profile service.

##### Class Name

`UpdateAgencyProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgencyProfile` | [`AgencyProfile`](#agency-profile) | Optional | Agency's profile information. |
| `Result` | [`Result4`](#result-4) | Optional | Status of the agency profile update operation. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "agencyProfile": null,
  "result": null
}
```

#### Update Agent Profile Request

An input data for agent profile update request.

##### Class Name

`UpdateAgentProfileRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgentProfile` | [`AgentProfile`](#agent-profile) | Optional | Agent's profile information. |

##### Example (as JSON)

```json
{
  "agentProfile": null
}
```

#### Update Agent Profile Response

Response information for agent profile update operation.

##### Class Name

`UpdateAgentProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | [`Result5`](#result-5) | Optional | Status of the agent profile update operation. The field is deprecated and will be removed in a subsequent major release. |
| `AgentProfile` | [`AgentProfile`](#agent-profile) | Optional | Agent's profile information. |

##### Example (as JSON)

```json
{
  "result": null,
  "agentProfile": null
}
```

#### Update Profile Request

Input information of profile service.

##### Class Name

`UpdateProfileRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Profile` | [`UserProfile`](#user-profile) | Optional | Passenger's profile information. |

##### Example (as JSON)

```json
{
  "profile": null
}
```

#### Update Profile Response

Response information of update profile service.

##### Class Name

`UpdateProfileResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Profile` | [`UserProfile`](#user-profile) | Optional | Passenger's profile information. |
| `Result` | [`Result9`](#result-9) | Optional | Result status of the profile update. The field is deprecated and will be removed in a subsequent major release. |

##### Example (as JSON)

```json
{
  "profile": null,
  "result": null
}
```

#### Upgrade Info

PNR upgrade information.

##### Class Name

`UpgradeInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentUpgradeInfos` | [`List<SegmentUpgradeInfo>`](#segment-upgrade-info) | Optional | List of segments with upgrade information. |
| `TotalWaitlistedSegmentsUpgradePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "segmentUpgradeInfos": null,
  "totalWaitlistedSegmentsUpgradePrice": null
}
```

#### Upgrade Item Group

Upgrade item group details.

##### Class Name

`UpgradeItemGroup`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `String` | Optional | Upgrade group name. |
| `Selected` | `Boolean` | Optional | Flag indicating if the upgrade group is selected. |
| `UpgradeItemMatrix` | [`UpsellUpgradeItemMatrix`](#upsell-upgrade-item-matrix) | Optional | Upsell/upgrade item comparison matrix details. |

##### Example (as JSON)

```json
{
  "name": null,
  "selected": null,
  "upgradeItemMatrix": null
}
```

#### Upgrade Offer

Upgrade offers linking upgrades with passengers and travel parts.

##### Class Name

`UpgradeOffer`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Code of the upgrade offer. |
| `BookingClass` | `String` | Optional | Booking class this offer will upgrade to. |
| `CabinClass` | [`CabinClass3`](#cabin-class-3) | Optional | Cabin class that this offer will upgrade to. |
| `TravelPartUpgradeOffers` | [`List<TravelPartUpgradeOffer>`](#travel-part-upgrade-offer) | Optional | Upgrade offer information for specific travel parts. |

##### Example (as JSON)

```json
{
  "code": null,
  "bookingClass": null,
  "cabinClass": null,
  "travelPartUpgradeOffers": null
}
```

#### Upgrade Offer Operation

Operation request for specific upgrade offer and selected travel part for all passengers.

##### Class Name

`UpgradeOfferOperation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Code of the upgrade offer. |
| `OfferSelected` | `Boolean` | Optional | Flag indicating if the new upgrade offer is selected. Set to false if you want to remove the upgrade offer. |
| `SelectedTravelPart` | [`SelectedTravelPart`](#selected-travel-part) | Optional | Selected travel part. |

##### Example (as JSON)

```json
{
  "code": null,
  "offerSelected": null,
  "selectedTravelPart": null
}
```

#### Upgrade Offer Operation Result

Upgrade offer operation result.

##### Class Name

`UpgradeOfferOperationResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning messages. |
| `Code` | `String` | Optional | Code of the upgrade offer. |
| `SelectedTravelPart` | [`SelectedTravelPart`](#selected-travel-part) | Optional | Selected travel part. |
| `PassengerIndex` | `Integer` | Optional | Index of the passenger associated with the upgrade offer operation, expressed as a positive integer. |
| `Successful` | `Boolean` | Optional | Flag indicating if upgrade operation finished successfully. |

##### Example (as JSON)

```json
{
  "messages": null,
  "code": null,
  "selectedTravelPart": null,
  "passengerIndex": null,
  "successful": null
}
```

#### Upgrade Offer Price

Upgrade offer price.

##### Class Name

`UpgradeOfferPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BasePrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalTax` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `TotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "basePrice": null,
  "totalTax": null,
  "totalPrice": null
}
```

#### Upgrade Offer Request

Upgrade offer operation request.

##### Class Name

`UpgradeOfferRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UpgradeOfferOperations` | [`List<UpgradeOfferOperation>`](#upgrade-offer-operation) | Optional | List with details for upgrade offer operations. |

##### Example (as JSON)

```json
{
  "upgradeOfferOperations": null
}
```

#### Upgrade Offer Request Result

Upgrade offer request result.

##### Class Name

`UpgradeOfferRequestResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UpgradeOfferOperationResults` | [`List<UpgradeOfferOperationResult>`](#upgrade-offer-operation-result) | Optional | List with results from upgrade offer operations. |

##### Example (as JSON)

```json
{
  "upgradeOfferOperationResults": null
}
```

#### Upgrade Offers Result

Upgrade Offers Result.

##### Class Name

`UpgradeOffersResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Information, warning messages. |
| `Passengers` | [`List<AncillaryPassenger>`](#ancillary-passenger) | Optional | Passenger's details associated with upgradeOffers. |
| `Itinerary` | [`Itinerary`](#itinerary) | Optional | - |
| `UpgradeOffers` | [`List<UpgradeOffer>`](#upgrade-offer) | Optional | Upgrade offers linking upgrades with passengers and travel parts. |

##### Example (as JSON)

```json
{
  "messages": null,
  "passengers": null,
  "itinerary": null,
  "upgradeOffers": null
}
```

#### Upgrade Product Information

##### Class Name

`UpgradeProductInformation`

##### Inherits From

[`AbstractAdditionalProductInformation`](#abstract-additional-product-information)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OriginalBookingClass` | `String` | Optional | Original booking class of the travel part. |
| `OriginalCabinClass` | [`OriginalCabinClass`](#original-cabin-class) | Optional | Original cabin class of the travel part. |
| `SelectedBookingClass` | `String` | Optional | Booking class of the upgraded travel part. |
| `SelectedCabinClass` | [`SelectedCabinClass`](#selected-cabin-class) | Optional | Cabin class of the upgraded travel part. |
| `Status` | [`Status5`](#status-5) | Optional | Status of the upgrade offer. |

##### Example (as JSON)

```json
{
  "originalBookingClass": null,
  "originalCabinClass": null,
  "selectedBookingClass": null,
  "selectedCabinClass": null,
  "status": null,
  "@type": null
}
```

#### Upgrade Request

Select upgrade offer request.

##### Class Name

`UpgradeRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RemoveOptionSelected` | `Boolean` | Optional | Flag indicating if items are removed or unselected. Set to true means that system should remove all upgrades from flights specified in selectFlights. |
| `SelectFlights` | `List<Integer>` | Optional | List of selected flight hash codes (it should be a valid basket hash value of selected flight). Values supplied for this parameter are validated against the offers available. |
| `CabinClass` | [`CabinClass4`](#cabin-class-4) | Optional | Name of the cabin class for which we want to make un upgrade. Required when an upgrade is being requested. |

##### Example (as JSON)

```json
{
  "removeOptionSelected": null,
  "selectFlights": null,
  "cabinClass": null
}
```

#### Upgrade Request Result

Upgrade request details for the selected offer.

##### Class Name

`UpgradeRequestResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |
| `Successful` | `Boolean` | Optional | Flag indicating if the request is successful. |
| `UpsellUpgradeMessages` | [`List<UpsellUpgradeMessage>`](#upsell-upgrade-message) | Optional | Upsell/upgrade result messages. |

##### Example (as JSON)

```json
{
  "messages": null,
  "successful": null,
  "upsellUpgradeMessages": null
}
```

#### Upgrade Result

Upgrade details.

##### Class Name

`UpgradeResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |
| `InitiallySelectedHashCodes` | `Map<String, String>` | Optional | List of flight hash codes (flight identifiers) submitted in the request. |
| `UpgradeItemGroups` | [`List<UpgradeItemGroup>`](#upgrade-item-group) | Optional | Upgrade item groups. |
| `UpgradeMode` | [`UpgradeMode`](#upgrade-mode) | Optional | Upgrade mode values. |

##### Example (as JSON)

```json
{
  "messages": null,
  "initiallySelectedHashCodes": null,
  "upgradeItemGroups": null,
  "upgradeMode": null
}
```

#### Upsell Request

Select upsell/upgrade offer request.

##### Class Name

`UpsellRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RemoveOptionSelected` | `Boolean` | Optional | Flag indicating if items are removed or unselected. Set to true means that system should remove all upgrades from flights specified in selectFlights. |
| `SelectFlights` | `List<Integer>` | Optional | List of selected flight hash codes (it should be a valid basket hash value of selected flight). Values supplied for this parameter are validated against the offers available. |

##### Example (as JSON)

```json
{
  "removeOptionSelected": null,
  "selectFlights": null
}
```

#### Upsell Request Result

Upgrade request details for the selected offer.

##### Class Name

`UpsellRequestResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |
| `Successful` | `Boolean` | Optional | Flag indicating if the request is successful. |
| `UpsellUpgradeMessages` | [`List<UpsellUpgradeMessage>`](#upsell-upgrade-message) | Optional | Upsell/upgrade result messages. |

##### Example (as JSON)

```json
{
  "messages": null,
  "successful": null,
  "upsellUpgradeMessages": null
}
```

#### Upsell Result

Upsell details.

##### Class Name

`UpsellResult`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Messages` | [`List<Message>`](#message) | Optional | Additional warning/info messages. |
| `InitiallySelectedHashCodes` | `Map<String, String>` | Optional | List of flight hash codes (flight identifiers) submitted in the request. |
| `UpsellItemMatrix` | [`UpsellUpgradeItemMatrix`](#upsell-upgrade-item-matrix) | Optional | Upsell/upgrade item comparison matrix details. |
| `UpsellMode` | [`UpsellMode`](#upsell-mode) | Optional | Upsell mode values. |

##### Example (as JSON)

```json
{
  "messages": null,
  "initiallySelectedHashCodes": null,
  "upsellItemMatrix": null,
  "upsellMode": null
}
```

#### Upsell Upgrade Item Detail

Upsell upgrade item detail.

##### Class Name

`UpsellUpgradeItemDetail`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `String` | Optional | Item code. |
| `Name` | `String` | Optional | Item name. |
| `ItemPrices` | `Map<String, String>` | Optional | Upsell/upgrade item price map. Format: Key:Value. |
| `FeatureValues` | [`List<UpsellUpgradeItemValue>`](#upsell-upgrade-item-value) | Optional | Item features values. |
| `TotalPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `Selected` | `Boolean` | Optional | Flag indicating if the item is selected. |

##### Example (as JSON)

```json
{
  "code": null,
  "name": null,
  "itemPrices": null,
  "featureValues": null,
  "totalPrice": null,
  "selected": null
}
```

#### Upsell Upgrade Item Matrix

Upsell/upgrade item comparison matrix details.

##### Class Name

`UpsellUpgradeItemMatrix`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Features` | `List<String>` | Optional | Defined features available for upsell/upgrade like Cabin, Free Baggage, Change/Cancellation fee etc. |
| `Items` | [`List<UpsellUpgradeItemDetail>`](#upsell-upgrade-item-detail) | Optional | Upsell/upgrade item list like upsell brands or upgrade cabins. |
| `ComparedPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "features": null,
  "items": null,
  "comparedPrice": null
}
```

#### Upsell Upgrade Item Price

Selected item details.

##### Class Name

`UpsellUpgradeItemPrice`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ItemSelected` | `Boolean` | Optional | Flag indicating if item is selected. |
| `ItemPrice` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |
| `ShoppingBasketHashCode` | `Integer` | Optional | Associated offer basket hash code for item. Values supplied for this parameter are validated against the offers available. |

##### Example (as JSON)

```json
{
  "itemSelected": null,
  "itemPrice": null,
  "shoppingBasketHashCode": null
}
```

#### Upsell Upgrade Item Value

Upsell upgrade item's value detail.

##### Class Name

`UpsellUpgradeItemValue`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type7`](#type-7) | Optional | Item's type. |
| `Text` | `String` | Optional | Item's label if type text. |
| `Checked` | `Boolean` | Optional | Flag indicating if the item is checked. Type checkbox. |
| `Price` | [`ApiPrice`](#api-price) | Optional | Contains price and alternatives to display. |

##### Example (as JSON)

```json
{
  "type": null,
  "text": null,
  "checked": null,
  "price": null
}
```

#### Upsell Upgrade Message

Message code with severity level.

##### Class Name

`UpsellUpgradeMessage`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Level` | [`Level1`](#level-1) | Optional | Level of current message. |
| `Code` | [`Code`](#code) | Optional | Message code. |

##### Example (as JSON)

```json
{
  "level": null,
  "code": null
}
```

#### User

Information about authenticated user of the application.

##### Class Name

`User`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PersonalDetails` | [`PersonalDetails`](#personal-details) | Optional | Passenger's personal information. |
| `LoyaltyDetails` | [`LoyaltyDetails`](#loyalty-details) | Optional | Loyalty (Frequent Flyer) information. |
| `TravelBankDetails` | [`LoginTravelBankDetails`](#login-travel-bank-details) | Optional | Travel Bank account information. |

##### Example (as JSON)

```json
{
  "personalDetails": null,
  "loyaltyDetails": null,
  "travelBankDetails": null
}
```

#### User Info

Passenger's information.

##### Class Name

`UserInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DateOfBirth` | `LocalDate` | Optional | Passenger's date of birth in the format: YYYY-MM-DD. |
| `Gender` | [`Gender1`](#gender-1) | Optional | Passenger's gender. |
| `RedressNumber` | `String` | Optional | Redress number is issued to customers as part the TSA's Secure Flight program to speed identification and security clearance. More information available at www.tsa.gov/stakeholders/secure-flight-program. |
| `KnownTravelerNumber` | `String` | Optional | Known Travler/TSA PreCheck Number. |
| `Emails` | `List<String>` | Optional | List of passenger's emails. |
| `Phones` | [`List<Phone>`](#phone) | Optional | List of passenger's phones. |
| `Addresses` | [`List<Address>`](#address) | Optional | List of passenger's addresses. |

##### Example (as JSON)

```json
{
  "dateOfBirth": null,
  "gender": null,
  "redressNumber": null,
  "knownTravelerNumber": null,
  "emails": null,
  "phones": null,
  "addresses": null
}
```

#### User Profile

Passenger's profile information.

##### Class Name

`UserProfile`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserDetails` | [`PassengerDetails`](#passenger-details) | Optional | Passenger's/Agency user's details. |
| `UserInfo` | [`UserInfo`](#user-info) | Optional | Passenger's information. |
| `FrequentFlyers` | [`List<FrequentFlyerDetails>`](#frequent-flyer-details) | Optional | List of Frequent Flyer accounts associated with the passenger. |
| `Username` | `String` | Optional | Passenger's name. |
| `Password` | `String` | Optional | Passenger's password. |
| `OldPassword` | `String` | Optional | Passenger's old password. |
| `UserID` | `String` | Optional | Auto-generated unique ID of the passenger. |
| `Consents` | [`List<Consent>`](#consent) | Optional | List of consent the passenger agreed upon. |
| `Hobby` | [`Hobby`](#hobby) | Optional | Maintain user hobbies related information. |
| `MaritalStatus` | `String` | Optional | Specifies if the passenger is married/unmarried. |
| `HasChildren` | `Boolean` | Optional | Flag indicating if the passenger has children. |
| `CorporateUser` | `Boolean` | Optional | Flag indicating if the passenger is associated with a corporate company. |
| `TravelPreferences` | [`TravelPreferences`](#travel-preferences) | Optional | Passenger's travel preferences. |
| `SecurityQuestion` | [`SecurityQuestion`](#security-question) | Optional | Passenger's consent information. |
| `DateModified` | `LocalDateTime` | Optional | Date of the last profile modification in format: YYYY-MM-DD. |
| `ProfileType` | [`ProfileType2`](#profile-type-2) | Optional | Passenger's profile type. |
| `PreferredLanguage` | `String` | Optional | Passenger's preferred language. |
| `ProfileStatus` | `Boolean` | Optional | Flag indicating if profile is active/disabled. |
| `UserCreditCards` | [`List<CreditCard>`](#credit-card) | Optional | Credit cards associated with the profile. |
| `TravelDocument` | [`PassengerDocumentInfo`](#passenger-document-info) | Optional | Passenger document information. |
| `Occupation` | [`Occupation`](#occupation) | Optional | Maintains occupation related information. |
| `HomeCountryCode` | `String` | Optional | Passenger's home country code (ISO country code like: https://en.wikipedia.org/?titleISO_3166-1). |
| `HomeAirportCode` | `String` | Optional | Passenger's home airport code (IATA 3 letter code like https://en.wikipedia.org/wiki/List_of_airports_by_IATA_code:_A). |

##### Example (as JSON)

```json
{
  "userDetails": null,
  "userInfo": null,
  "frequentFlyers": null,
  "username": null,
  "password": null,
  "oldPassword": null,
  "userID": null,
  "consents": null,
  "hobby": null,
  "maritalStatus": null,
  "hasChildren": null,
  "corporateUser": null,
  "travelPreferences": null,
  "securityQuestion": null,
  "dateModified": null,
  "profileType": null,
  "preferredLanguage": null,
  "profileStatus": null,
  "userCreditCards": null,
  "travelDocument": null,
  "occupation": null,
  "homeCountryCode": null,
  "homeAirportCode": null
}
```

#### Vendor Info

Details of the Vendor.

##### Class Name

`VendorInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the Vendor. |
| `Code` | `String` | Optional | Code of the Vendor. |
| `CodeContext` | `String` | Optional | Name of the car service provider. |

##### Example (as JSON)

```json
{
  "name": null,
  "code": null,
  "codeContext": null
}
```

#### Vendor Reference

Information identifying this availability quote. Some Provider expect it to match exactly as returned in availability Response for desired Vehicle.

##### Class Name

`VendorReference`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Url` | `String` | Optional | URL that identifies the location associated with the record identified by the unique ID. Provided by the vendor in the car availability response as an encoded string. Hence it will not be validated at this level. |
| `Identifier` | `String` | Optional | Used to provide a required unique identifier. |
| `Type` | `String` | Optional | A reference to the type of the object defined by the Unique ID element. |
| `DateTime` | `LocalDateTime` | Optional | The date and time at which this availability quote was made available. |
| `CompanyDetails` | [`CompanyDetails`](#company-details) | Optional | Company details associated with the unique ID. |
| `Instance` | `String` | Optional | Record identification used in update messages. It assures the server that sent update refers to the most recent modification (of the updated object). |
| `CodeContext` | `String` | Optional | Name of the car service provider. |

##### Example (as JSON)

```json
{
  "url": null,
  "identifier": null,
  "type": null,
  "dateTime": null,
  "companyDetails": null,
  "instance": null,
  "codeContext": null
}
```

#### Voucher

##### Class Name

`Voucher`

##### Inherits From

[`Payment`](#payment)

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `VoucherType` | [`VoucherType`](#voucher-type) | Optional | Voucher enum type. |
| `VoucherNumber` | `String` | Optional | Voucher number. |
| `ExpDate` | `LocalDate` | Optional | Expiration date in the format: YYYY-MM-DD. Required for GIFT_CARD. |
| `Pin` | `String` | Optional | Voucher pin. Required for UATP_VOUCHER. |

##### Example (as JSON)

```json
{
  "voucherType": null,
  "voucherNumber": null,
  "expDate": null,
  "pin": null,
  "amount": null,
  "@type": null
}
```

#### Waive Operation

Waive operation.

##### Class Name

`WaiveOperation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OperationType` | `String` | Optional | Type of an operation. |
| `ObFeeCode` | `String` | Optional | Ob Fee code. |
| `PassengerId` | `Integer` | Optional | Index of the passenger in the reservation, expressed as a positive integer. |
| `ReasonCode` | `String` | Optional | Ob Fee reason code. |

##### Example (as JSON)

```json
{
  "operationType": null,
  "obFeeCode": null,
  "passengerId": null,
  "reasonCode": null
}
```

#### Waive Operations Request

Waive operation request.

##### Class Name

`WaiveOperationsRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Operations` | [`List<WaiveOperation>`](#waive-operation) | Optional | List with details for waive operations. |

##### Example (as JSON)

```json
{
  "operations": null
}
```

### Enumerations

* [Address Type](#address-type)
* [Agency Login Status](#agency-login-status)
* [Agent Type](#agent-type)
* [Allowed Status](#allowed-status)
* [Alternate Search Type](#alternate-search-type)
* [Availability Status](#availability-status)
* [Award Ancillary Toggle Option Status](#award-ancillary-toggle-option-status)
* [Award Switch State](#award-switch-state)
* [Bag Characteristics](#bag-characteristics)
* [Bag Unit](#bag-unit)
* [Baggage Allowance Type](#baggage-allowance-type)
* [Baggage Limit Type](#baggage-limit-type)
* [Baggage Size Unit](#baggage-size-unit)
* [Balance Elements](#balance-elements)
* [Cabin Class](#cabin-class)
* [Cabin Class 1](#cabin-class-1)
* [Cabin Class 2](#cabin-class-2)
* [Cabin Class 3](#cabin-class-3)
* [Cabin Class 4](#cabin-class-4)
* [Car Rental Facility Role](#car-rental-facility-role)
* [Car Size](#car-size)
* [Car Type](#car-type)
* [Category Code](#category-code)
* [Code](#code)
* [Configuration Type](#configuration-type)
* [Confirmation ID Type](#confirmation-id-type)
* [Coupon Status](#coupon-status)
* [Current State](#current-state)
* [Day of Week](#day-of-week)
* [Deck](#deck)
* [Document Type](#document-type)
* [Document Type 1](#document-type-1)
* [Document Type 2](#document-type-2)
* [Drivetrain Type](#drivetrain-type)
* [Eligibilities Codes](#eligibilities-codes)
* [Eligibility](#eligibility)
* [Evaluation Result](#evaluation-result)
* [Exchange Type](#exchange-type)
* [Flight Status](#flight-status-1)
* [Fraud Check Status](#fraud-check-status)
* [Fuel Type](#fuel-type)
* [Fuel Type 1](#fuel-type-1)
* [Gender](#gender)
* [Gender 1](#gender-1)
* [Gender 2](#gender-2)
* [Http Method](#http-method)
* [Industry Code](#industry-code)
* [Installments Source](#installments-source)
* [Journey Apply Type](#journey-apply-type)
* [Level](#level)
* [Level 1](#level-1)
* [Marriage Group](#marriage-group)
* [Meal Preference](#meal-preference)
* [Meal Preference 1](#meal-preference-1)
* [Negotiated Type](#negotiated-type)
* [OAuth Provider Error](#oauth-provider-error)
* [Ob Fees Type R Action](#ob-fees-type-r-action)
* [Option](#option)
* [Original Cabin Class](#original-cabin-class)
* [Passenger Apply Type](#passenger-apply-type)
* [Passenger Type](#passenger-type)
* [Passenger Type 1](#passenger-type-1)
* [Passenger Type 2](#passenger-type-2)
* [Passenger Type 3](#passenger-type-3)
* [Payment Time Type](#payment-time-type)
* [Payment Type](#payment-type)
* [Payment Type 1](#payment-type-1)
* [Period](#period)
* [Prefix](#prefix)
* [Prefix 1](#prefix-1)
* [Prefix 2](#prefix-2)
* [Price Elements](#price-elements)
* [Product Type](#product-type)
* [Product Type 1](#product-type-1)
* [Profile Type](#profile-type)
* [Profile Type 1](#profile-type-1)
* [Profile Type 2](#profile-type-2)
* [Program Id](#program-id)
* [Property Type](#property-type)
* [Rate Qualifier](#rate-qualifier)
* [Refund Indicator](#refund-indicator)
* [Refund Indicator 1](#refund-indicator-1)
* [Request Type](#request-type)
* [Result](#result)
* [Result 1](#result-1)
* [Result 2](#result-2)
* [Result 3](#result-3)
* [Result 4](#result-4)
* [Result 5](#result-5)
* [Result 6](#result-6)
* [Result 7](#result-7)
* [Result 9](#result-9)
* [Search Type](#search-type)
* [Seat Preference](#seat-preference)
* [Segment Status](#segment-status)
* [Selected Cabin Class](#selected-cabin-class)
* [State](#state)
* [Status](#status)
* [Status 1](#status-1)
* [Status 2](#status-2)
* [Status 3](#status-3)
* [Status 4](#status-4)
* [Status 5](#status-5)
* [Status 6](#status-6)
* [Status 7](#status-7)
* [Status 8](#status-8)
* [Subbalances](#subbalances)
* [Suffix](#suffix)
* [Suffix 1](#suffix-1)
* [Suffix 2](#suffix-2)
* [Transmission Type](#transmission-type)
* [Transmission Type 1](#transmission-type-1)
* [Trip Contact Info Type](#trip-contact-info-type)
* [Trip Option](#trip-option)
* [Type](#type)
* [Type 1](#type-1)
* [Type 2](#type-2)
* [Type 3](#type-3)
* [Type 4](#type-4)
* [Type 5](#type-5)
* [Type 6](#type-6)
* [Type 7](#type-7)
* [Type Code](#type-code)
* [Unit](#unit)
* [Upgrade Mode](#upgrade-mode)
* [Upsell Mode](#upsell-mode)
* [Value](#value)
* [Vcr Change Type](#vcr-change-type)
* [Vehicle Size](#vehicle-size)
* [Voucher Type](#voucher-type)

#### Address Type

Address type.

##### Class Name

`AddressType`

##### Fields

| Name |
|  --- |
| `HOME` |
| `INVOICE` |
| `BUSINESS` |
| `OTHER` |
| `RESIDENCE` |
| `AGENCY` |

#### Agency Login Status

Status of the agency's login operation.

##### Class Name

`AgencyLoginStatus`

##### Fields

| Name |
|  --- |
| `SUCCESSFUL` |

#### Agent Type

Type of an agent.

##### Class Name

`AgentType`

##### Fields

| Name |
|  --- |
| `STANDARD` |
| `SUPERAGENT` |

#### Allowed Status

Returns the baggage status.

##### Class Name

`AllowedStatus`

##### Fields

| Name |
|  --- |
| `FREE` |
| `NOTPERMITTED` |
| `UNKNOWN` |

#### Alternate Search Type

Alternate search type when flights are SOLD_OUT, UNAVAILABLE, NO_SCHEDULE for the requested search criteria.

##### Class Name

`AlternateSearchType`

##### Fields

| Name |
|  --- |
| `CALENDAR30` |
| `BRANDED` |
| `LOWESTFARE` |
| `MATRIX` |

#### Availability Status

Defines a set of valid status values, allowing the selection of a specific group based on its availability or just the disclosure of the reservation status.

##### Class Name

`AvailabilityStatus`

##### Fields

| Name |
|  --- |
| `OTHER` |
| `AVAILABLE` |
| `UNAVAILABLE` |
| `ONREQUEST` |
| `CONFIRMED` |
| `ALL` |
| `WAITLIST` |
| `SUPPLIERBOOKED` |

##### Example

```
AVAILABLE
```

#### Award Ancillary Toggle Option Status

Toggle option status.

##### Class Name

`AwardAncillaryToggleOptionStatus`

##### Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |
| `UNAVAILABLE` |

#### Award Switch State

Defines products prices mode: CASH or POINTS. For CASH, products breakdown returned by service will be in cash.
For POINTS, products breakdown will be recalculated to points, if user is logged in and has sufficient balance.
Can be used in B2C flow. Switching to POINTS does not change flow to RBE.

##### Class Name

`AwardSwitchState`

##### Fields

| Name |
|  --- |
| `CASH` |
| `POINTS` |

#### Bag Characteristics

##### Class Name

`BagCharacteristics`

##### Fields

| Name |
|  --- |
| `PIECES` |
| `KILOGRAMS` |
| `POUNDS` |

#### Bag Unit

Weight unit.

##### Class Name

`BagUnit`

##### Fields

| Name |
|  --- |
| `PIECES` |
| `KILOGRAMS` |
| `POUNDS` |

#### Baggage Allowance Type

Type of baggage allowance.

##### Class Name

`BaggageAllowanceType`

##### Fields

| Name |
|  --- |
| `OVERRIDE` |
| `ADDITIONAL` |
| `STANDARD` |

#### Baggage Limit Type

Limit type.

##### Class Name

`BaggageLimitType`

##### Fields

| Name |
|  --- |
| `OVER` |
| `UPTO` |

#### Baggage Size Unit

Size unit.

##### Class Name

`BaggageSizeUnit`

##### Fields

| Name |
|  --- |
| `CENTIMETER` |
| `METER` |
| `INCH` |
| `FEET` |

#### Balance Elements

##### Class Name

`BalanceElements`

##### Fields

| Name |
|  --- |
| `BASE` |
| `TAX` |
| `FEE` |
| `INSURANCE` |
| `NONE` |
| `TICKETINGFEE` |

#### Cabin Class

Cabin class name.

##### Class Name

`CabinClass`

##### Fields

| Name |
|  --- |
| `Economy` |
| `PremiumEconomy` |
| `Business` |
| `First` |

#### Cabin Class 1

Cabin class for this offer.

##### Class Name

`CabinClass1`

##### Fields

| Name |
|  --- |
| `Economy` |
| `PremiumEconomy` |
| `Business` |
| `First` |

#### Cabin Class 2

Specifies cabin class.

##### Class Name

`CabinClass2`

##### Fields

| Name |
|  --- |
| `Economy` |
| `PremiumEconomy` |
| `Business` |
| `First` |

#### Cabin Class 3

Cabin class that this offer will upgrade to.

##### Class Name

`CabinClass3`

##### Fields

| Name |
|  --- |
| `Economy` |
| `PremiumEconomy` |
| `Business` |
| `First` |

#### Cabin Class 4

Name of the cabin class for which we want to make un upgrade. Required when an upgrade is being requested.

##### Class Name

`CabinClass4`

##### Fields

| Name |
|  --- |
| `Economy` |
| `Business` |
| `First` |

#### Car Rental Facility Role

Role of car rental facility.

##### Class Name

`CarRentalFacilityRole`

##### Fields

| Name |
|  --- |
| `PICKUP` |
| `DROPOFF` |

#### Car Size

Size of the vehicle.

##### Class Name

`CarSize`

##### Fields

| Name |
|  --- |
| `Mini` |
| `MiniElite` |
| `Economy` |
| `EconomyElite` |
| `Compact` |
| `CompactElite` |
| `Intermediate` |
| `IntermediateElite` |
| `Standard` |
| `StandardElite` |
| `Fullsize` |
| `FullsizeElite` |
| `Premium` |
| `PremiumElite` |
| `Luxury` |
| `LuxuryElite` |
| `Oversize` |
| `Special` |

#### Car Type

Type of the vehicle.

##### Class Name

`CarType`

##### Fields

| Name |
|  --- |
| `TwoThreeDoor` |
| `TwoFourDoor` |
| `FourFiveDoor` |
| `WagonEstate` |
| `PassengerVan` |
| `Limousine` |
| `Sport` |
| `Convertible` |
| `SUV` |
| `OpenAirAllTerrain` |
| `Special` |
| `PickupRegularCab` |
| `PickupExtendedCab` |
| `SpecialOfferCar` |
| `Coupe` |
| `Monospace` |
| `Recreational` |
| `MotorHome` |
| `WheelVehicle` |
| `Roadster` |
| `Crossover` |
| `CommercialVanTruck` |

#### Category Code

Hobby category code options.

##### Class Name

`CategoryCode`

##### Fields

| Name |
|  --- |
| `ART` |
| `FOD` |
| `SPT` |
| `HOV` |
| `TVL` |

#### Code

Message code.

##### Class Name

`Code`

##### Fields

| Name |
|  --- |
| `PRICECHANGED` |
| `OFFERNOTAVAILABLE` |

#### Configuration Type

##### Class Name

`ConfigurationType`

##### Fields

| Name |
|  --- |
| `DEFAULT` |
| `CONFIGURED` |

#### Confirmation ID Type

Type of Provider's confirmation ID.

##### Class Name

`ConfirmationIDType`

##### Fields

| Name |
|  --- |
| `AGGREGATOR` |
| `SUPPLIER` |

#### Coupon Status

Coupon status.

##### Class Name

`CouponStatus`

##### Fields

| Name |
|  --- |
| `OK` |
| `USED` |
| `EXCHANGED` |
| `VOID` |
| `CHECKEDIN` |
| `CTRL` |
| `LFTD` |
| `PRT` |
| `IROP` |
| `NOGO` |
| `NS` |
| `PRFD` |
| `PRTX` |
| `REFUNDED` |
| `RPRT` |
| `UTL` |

#### Current State

Current selected option.

##### Class Name

`CurrentState`

##### Fields

| Name |
|  --- |
| `CASH` |
| `POINTS` |

#### Day of Week

Day of the week.

##### Class Name

`DayOfWeek`

##### Fields

| Name |
|  --- |
| `MONDAY` |
| `TUESDAY` |
| `WEDNESDAY` |
| `THURSDAY` |
| `FRIDAY` |
| `SATURDAY` |
| `SUNDAY` |

##### Example

```
MONDAY
```

#### Deck

Deck type describing location of the deck.

##### Class Name

`Deck`

##### Fields

| Name |
|  --- |
| `MAIN` |
| `UPPER` |

#### Document Type

Document type.

##### Class Name

`DocumentType`

##### Fields

| Name |
|  --- |
| `P` |
| `A` |
| `C` |
| `F` |
| `M` |
| `N` |
| `T` |
| `V` |
| `I` |
| `IN` |

#### Document Type 1

Document type.

##### Class Name

`DocumentType1`

##### Fields

| Name |
|  --- |
| `VCR` |
| `EMD` |

#### Document Type 2

Type of the document.

##### Class Name

`DocumentType2`

##### Fields

| Name |
|  --- |
| `EnumVirtualCouponRecord` |
| `EnumElectronicMiscDocument` |

#### Drivetrain Type

Type of the drivetrain.

##### Class Name

`DrivetrainType`

##### Fields

| Name |
|  --- |
| `ALLWHEELDRIVE` |
| `FOURWHEELDRIVE` |
| `STANDARD` |
| `OTHER` |

##### Example

```
ALL_WHEEL_DRIVE
```

#### Eligibilities Codes

##### Class Name

`EligibilitiesCodes`

##### Fields

| Name |
|  --- |
| `CANCELFEEWAIVER` |
| `CHANGEFEEWAIVER` |
| `PROMO` |

#### Eligibility

##### Class Name

`Eligibility`

##### Fields

| Name |
|  --- |
| `CANCELFEEWAIVER` |
| `CHANGEFEEWAIVER` |
| `PROMO` |

#### Evaluation Result

Evaluation result of the rule.

##### Class Name

`EvaluationResult`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `FAIL` |
| `NOTAPPLICABLE` |

#### Exchange Type

Specifies an exchange type.

##### Class Name

`ExchangeType`

##### Fields

| Name |
|  --- |
| `Inbound` |
| `Outbound` |
| `Both` |
| `Segment` |
| `Itinerary` |

#### Flight Status

Flight status.

##### Class Name

`FlightStatus`

##### Fields

| Name |
|  --- |
| `ONTIME` |
| `DELAYED` |
| `ARRIVED` |
| `ARRIVEDWITHDELAY` |
| `CANCELLED` |
| `DEPARTED` |
| `DEPARTEDWITHDELAY` |

##### Example

```
ON_TIME
```

#### Fraud Check Status

Fraud check status.

##### Class Name

`FraudCheckStatus`

##### Fields

| Name |
|  --- |
| `OK` |
| `REVIEW` |
| `ACCEPT` |
| `REJECT` |

#### Fuel Type

Type of the fuel a vehicle's engine uses.

##### Class Name

`FuelType`

##### Fields

| Name |
|  --- |
| `UnspecifiedFuel` |
| `Diesel` |
| `Hybrid` |
| `Electric` |
| `LpgGas` |
| `Hydrogen` |
| `MultiFuel` |
| `Petrol` |
| `Ethanol` |

#### Fuel Type 1

Type of the fuel a vehicle's engine uses.

##### Class Name

`FuelType1`

##### Fields

| Name |
|  --- |
| `DIESEL` |
| `HYBRID` |
| `ELECTRIC` |
| `LPGCOMPRESSEDGAS` |
| `HYDROGEN` |
| `MULTIFUEL` |
| `PETROL` |
| `ETHANOL` |
| `OTHER` |

##### Example

```
DIESEL
```

#### Gender

Agent's gender.

##### Class Name

`Gender`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |

#### Gender 1

Passenger's gender.

##### Class Name

`Gender1`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |

#### Gender 2

Purchaser's gender.

##### Class Name

`Gender2`

##### Fields

| Name |
|  --- |
| `MALE` |
| `FEMALE` |

#### Http Method

##### Class Name

`HttpMethod`

##### Fields

| Name |
|  --- |
| `GET` |
| `POST` |
| `PUT` |
| `DELETE` |
| `HEAD` |
| `OPTIONS` |

#### Industry Code

Occupation industry code. Values - AGY:Agency Employee, AGR:Agriculture/Forestry/Fishing, ART:Art, BNK:Banking, BUS:Business, BSC:Business Services and Consulting, CON:Construction, CPR:Chemicals/Petroleum Refining, CLG:College Student, EDU:Education, ELC:Electric, ENR:Entertainment and Recreation, FIN:Finance, FDP:Food Processing, GOV:Government, HLT:Health Services, HTL:Hotel, HPS:Household and Personal Service, HSW:Housewife, HRS:Human Resources, INF:Information Technology, INS:Insurance, LGL:Legal, LEI:Leisure and Hospitality, MFG:Manufacturing, MKT:Marketing, MCE:MFG - Computers/Electronics, MCD:MFG - Consumer Durables, MCN:MFG - Consumer Nondurables, MHE:MFG - Heavy Equipment, MIN:Mining, MUS:Music, NNG:Non-Governmental, OGE:Oil/Gas Exploration, POL:Politics, PST:Post Student, PRO:Professional Services, RLE:Real Estate, REL:Religion, RTR:Retail Trade, SCC:Securities and Commodities, SCL:Social, SFT:Software, SPT:Sport, STU:Student, TEL:Telecommunications, TRD:Trade, TRN:Transportation, TVL:Travel, UTL:Utilities, WTD:Wholesale Trade - Durables, WTN:Wholesale Trade - Nondurables, OTH:Other.

##### Class Name

`IndustryCode`

##### Fields

| Name |
|  --- |
| `AGY` |
| `AGR` |
| `ART` |
| `BNK` |
| `BUS` |
| `BSC` |
| `CON` |
| `CPR` |
| `CLG` |
| `EDU` |
| `ELC` |
| `ENR` |
| `FIN` |
| `FDP` |
| `GOV` |
| `HLT` |
| `HTL` |
| `HPS` |
| `HSW` |
| `HRS` |
| `INF` |
| `INS` |
| `LGL` |
| `LEI` |
| `MFG` |
| `MKT` |
| `MCE` |
| `MCD` |
| `MCN` |
| `MHE` |
| `MIN` |
| `MUS` |
| `NNG` |
| `OGE` |
| `POL` |
| `PST` |
| `PRO` |
| `RLE` |
| `REL` |
| `RTR` |
| `SCC` |
| `SCL` |
| `SFT` |
| `SPT` |
| `STU` |
| `TEL` |
| `TRD` |
| `TRN` |
| `TVL` |
| `UTL` |
| `WTD` |
| `WTN` |
| `OTH` |

#### Installments Source

Source of installments.

##### Class Name

`InstallmentsSource`

##### Fields

| Name |
|  --- |
| `EnumCONFIGURATION` |
| `EnumPAYMENTPROVIDER` |
| `EnumNONE` |

#### Journey Apply Type

Specifies how offering is applied - per segment, itinerary part or whole itinerary.

##### Class Name

`JourneyApplyType`

##### Fields

| Name |
|  --- |
| `PERSECTOR` |
| `PERLEG` |
| `WHOLEJOURNEY` |

#### Level

Severity level.

##### Class Name

`Level`

##### Fields

| Name |
|  --- |
| `Info` |
| `Warn` |
| `Error` |

#### Level 1

Level of current message.

##### Class Name

`Level1`

##### Fields

| Name |
|  --- |
| `Info` |
| `Warn` |
| `Error` |

#### Marriage Group

Marriage group indicator. Default value is 0. Set to 0 means false, set to 1 means true.

##### Class Name

`MarriageGroup`

##### Fields

| Name |
|  --- |
| `Enum0` |
| `Enum1` |

#### Meal Preference

Choice of meal.

##### Class Name

`MealPreference`

##### Fields

| Name |
|  --- |
| `BBML` |
| `CHML` |
| `DBML` |
| `FPML` |
| `GFML` |
| `HNML` |
| `KSML` |
| `LCML` |
| `LFML` |
| `LSML` |
| `MOML` |
| `NLML` |
| `RVML` |
| `SFML` |
| `SPML` |
| `VGML` |
| `VJML` |
| `VLML` |
| `VOML` |

#### Meal Preference 1

Choice of meal.

##### Class Name

`MealPreference1`

##### Fields

| Name |
|  --- |
| `AVML` |
| `BBML` |
| `BLML` |
| `CHML` |
| `DBML` |
| `FPML` |
| `GFML` |
| `HNML` |
| `KSML` |
| `LCML` |
| `LFML` |
| `LSML` |
| `MOML` |
| `NLML` |
| `RVML` |
| `SFML` |
| `SPML` |
| `VGML` |
| `VJML` |
| `VLML` |
| `VOML` |

#### Negotiated Type

Indicator for negotiated fare type.

##### Class Name

`NegotiatedType`

##### Fields

| Name |
|  --- |
| `NONE` |
| `CORPORATE` |
| `NETFARE` |
| `NONTICKETABLE` |
| `OTHER` |

#### OAuth Provider Error

Authorization error codes.

##### Class Name

`OauthProviderError`

##### Fields

| Name | Description |
|  --- | --- |
| `InvalidRequest` | The request is missing a required parameter, includes an unsupported parameter value (other than grant type), repeats a parameter, includes multiple credentials, utilizes more than one mechanism for authenticating the client, or is otherwise malformed. |
| `InvalidClient` | Client authentication failed (e.g., unknown client, no client authentication included, or unsupported authentication method). |
| `InvalidGrant` | The provided authorization grant (e.g., authorization code, resource owner credentials) or refresh token is invalid, expired, revoked, does not match the redirection URI used in the authorization request, or was issued to another client. |
| `UnauthorizedClient` | The authenticated client is not authorized to use this authorization grant type. |
| `UnsupportedGrantType` | The authorization grant type is not supported by the authorization server. |
| `InvalidScope` | The requested scope is invalid, unknown, malformed, or exceeds the scope granted by the resource owner. |

#### Ob Fees Type R Action

Operation type.

##### Class Name

`ObFeesTypeRAction`

##### Fields

| Name |
|  --- |
| `ADD` |
| `REMOVE` |

#### Option

Points or cash selection.

##### Class Name

`Option`

##### Fields

| Name |
|  --- |
| `CASH` |
| `POINTS` |

#### Original Cabin Class

Original cabin class of the travel part.

##### Class Name

`OriginalCabinClass`

##### Fields

| Name |
|  --- |
| `Economy` |
| `PremiumEconomy` |
| `Business` |
| `First` |

#### Passenger Apply Type

Specifies how offering is applied - per passenger, or per all passengers.

##### Class Name

`PassengerApplyType`

##### Fields

| Name |
|  --- |
| `PERPASSENGER` |
| `TOALLPASSENGERS` |

#### Passenger Type

Passenger's type code.

##### Class Name

`PassengerType`

##### Fields

| Name |
|  --- |
| `ADT` |
| `YCB` |
| `YTH` |
| `CHD` |
| `C04` |
| `C11` |
| `INF` |
| `INS` |
| `STU` |
| `MIL` |
| `SRC` |
| `CMA` |
| `CMP` |

#### Passenger Type 1

Passenger type like adult, child etc.

##### Class Name

`PassengerType1`

##### Fields

| Name |
|  --- |
| `ADT` |
| `YCB` |
| `YTH` |
| `CHD` |
| `C04` |
| `C11` |
| `INF` |
| `INS` |
| `STU` |
| `MIL` |
| `SRC` |
| `CMA` |
| `CMP` |

#### Passenger Type 2

Specifies type of the passenger for this breakdown element assignment. Total should be presented for all passengers with this type.

##### Class Name

`PassengerType2`

##### Fields

| Name |
|  --- |
| `ADT` |
| `YCB` |
| `YTH` |
| `CHD` |
| `C04` |
| `C11` |
| `INF` |
| `INS` |
| `STU` |
| `MIL` |
| `SRC` |
| `CMA` |
| `CMP` |

#### Passenger Type 3

Passenger's type.

##### Class Name

`PassengerType3`

##### Fields

| Name |
|  --- |
| `ADT` |
| `YCB` |
| `YTH` |
| `CHD` |
| `C04` |
| `C11` |
| `INF` |
| `INS` |
| `STU` |
| `MIL` |
| `SRC` |
| `CMA` |
| `CMP` |

#### Payment Time Type

Type of payment.

##### Class Name

`PaymentTimeType`

##### Fields

| Name |
|  --- |
| `PREPAID` |
| `POSTPAID` |

#### Payment Type

General payment type.

##### Class Name

`PaymentType`

##### Fields

| Name |
|  --- |
| `CREDITCARD` |
| `PAYPAL` |
| `AWARD` |
| `FREQUENTFLYER` |
| `POLI` |
| `TRAVELBANK` |
| `GIFTCARD` |
| `REMOTE` |
| `RETAIL` |
| `SMLPAYNOW` |
| `SMLPAYLATER` |
| `DIRECTDEBIT` |
| `UATPVOUCHER` |
| `AFOP` |

#### Payment Type 1

Payment type.

##### Class Name

`PaymentType1`

##### Fields

| Name |
|  --- |
| `CREDITCARD` |

#### Period

Time period for which the restriction is defined.

##### Class Name

`Period`

##### Fields

| Name |
|  --- |
| `DAY` |
| `WEEK` |
| `MONTH` |
| `RENTALPERIOD` |
| `OTHER` |

#### Prefix

Agency user's prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted).

##### Class Name

`Prefix`

##### Fields

| Name |
|  --- |
| `Mr` |
| `Mrs` |
| `Ms` |
| `Dr` |
| `MR1` |
| `MRS1` |
| `MS1` |
| `DR1` |

#### Prefix 1

Agent's prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted).

##### Class Name

`Prefix1`

##### Fields

| Name |
|  --- |
| `Mr` |
| `Mrs` |
| `Ms` |
| `Dr` |
| `MR1` |
| `MRS1` |
| `MS1` |
| `DR1` |

#### Prefix 2

Passenger prefix or title, accepts lower and upper case letters (prefix values read from pnr will be in upper case letters to accommodate this, upper case is also accepted).

##### Class Name

`Prefix2`

##### Fields

| Name |
|  --- |
| `Mr` |
| `Mrs` |
| `Ms` |
| `Dr` |
| `MR1` |
| `MRS1` |
| `MS1` |
| `DR1` |

#### Price Elements

##### Class Name

`PriceElements`

##### Fields

| Name |
|  --- |
| `BASE` |
| `TAX` |
| `FEE` |
| `INSURANCE` |
| `NONE` |
| `TICKETINGFEE` |

#### Product Type

Product type.

##### Class Name

`ProductType`

##### Fields

| Name |
|  --- |
| `AIR` |
| `ANCILLARY` |
| `SEATS` |
| `INSURANCE` |
| `HOTEL` |
| `CAR` |
| `ONHOLD` |
| `TOTALDUE` |
| `UPGRADE` |
| `FEE` |

#### Product Type 1

##### Class Name

`ProductType1`

##### Fields

| Name |
|  --- |
| `AIR` |
| `ANCILLARY` |
| `SEATS` |
| `INSURANCE` |
| `HOTEL` |
| `CAR` |
| `ONHOLD` |
| `TOTALDUE` |
| `UPGRADE` |
| `FEE` |

#### Profile Type

User profile type defined in profile system.

##### Class Name

`ProfileType`

##### Fields

| Name |
|  --- |
| `AGY` |
| `AGT` |

#### Profile Type 1

Agent's type.

##### Class Name

`ProfileType1`

##### Fields

| Name |
|  --- |
| `STANDARD` |
| `SUPER` |

#### Profile Type 2

Passenger's profile type.

##### Class Name

`ProfileType2`

##### Fields

| Name |
|  --- |
| `FREQUENTFLYER` |
| `WEB` |
| `AGT` |
| `AGY` |

#### Program Id

Corporate Loyalty program name.

##### Class Name

`ProgramId`

##### Fields

| Name |
|  --- |
| `BlueBiz` |
| `Target` |
| `SkyBonus` |

#### Property Type

Type of ancillary property.

##### Class Name

`PropertyType`

##### Fields

| Name |
|  --- |
| `INT` |
| `DECIMAL` |
| `TEXT` |
| `ENUM` |

#### Rate Qualifier

Indicates the type of rates applicable to the customer.

##### Class Name

`RateQualifier`

##### Fields

| Name |
|  --- |
| `POSTPAIDIN` |
| `POSTPAIDEX` |

#### Refund Indicator

Refund indicator. Can be refundable, exchangeable or non-refundable.

##### Class Name

`RefundIndicator`

##### Fields

| Name |
|  --- |
| `REFUNDABLE` |
| `EXCHANGEABLE` |
| `NONREFUNDABLE` |

#### Refund Indicator 1

Refundable seat status.

##### Class Name

`RefundIndicator1`

##### Fields

| Name |
|  --- |
| `Y` |
| `N` |

#### Request Type

##### Class Name

`RequestType`

##### Fields

| Name |
|  --- |
| `DAY` |
| `WEEK` |

#### Result

Status of the agency profile creation operation. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 1

Status of the agent profile creation operation. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result1`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 2

Status of the agent profile retrieval operation. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result2`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 3

Status of the password reset. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result3`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 4

Status of the agency profile update operation. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result4`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 5

Status of the agent profile update operation. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result5`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 6

User profile creation result status. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result6`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 7

Result status of the profile retrieval. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result7`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Result 9

Result status of the profile update. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Result9`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Search Type

Search type.

##### Class Name

`SearchType`

##### Fields

| Name |
|  --- |
| `CALENDAR30` |
| `BRANDED` |
| `LOWESTFARE` |
| `MATRIX` |
| `FLEXIBLECALENDAR` |

#### Seat Preference

Seat preference.

##### Class Name

`SeatPreference`

##### Fields

| Name |
|  --- |
| `NSSA` |
| `NSSB` |
| `NSSR` |
| `NSST` |
| `NSSW` |

#### Segment Status

Name of the segment status that is passed to the Digital Connect.

##### Class Name

`SegmentStatus`

##### Fields

| Name |
|  --- |
| `CONFIRMED` |
| `STANDBY` |
| `OTHER` |
| `FLOWN` |
| `CANCELLED` |
| `ONHOLD` |
| `SCHEDULECHANGE` |
| `SOLDSOLD` |
| `NEEDNEED` |
| `NONREVENUE` |

#### Selected Cabin Class

Cabin class of the upgraded travel part.

##### Class Name

`SelectedCabinClass`

##### Fields

| Name |
|  --- |
| `Economy` |
| `PremiumEconomy` |
| `Business` |
| `First` |

#### State

State of the trip.

##### Class Name

`State`

##### Fields

| Name |
|  --- |
| `ACTIVE` |
| `INACTIVE` |
| `ONHOLD` |
| `CANCELLED` |
| `FLOWN` |

#### Status

Result status of the agency profile retrieval. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Status`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Status 1

Status of the agents profiles retrieval operation. The field is deprecated and will be removed in a subsequent major release.

##### Class Name

`Status1`

##### Fields

| Name |
|  --- |
| `SUCCESS` |
| `PASSWORDRESETLINKSENT` |

#### Status 2

Offer status.

##### Class Name

`Status2`

##### Fields

| Name |
|  --- |
| `AVAILABLE` |
| `SOLDOUT` |
| `NONESCHEDULED` |
| `UNAVAILABLE` |

#### Status 3

Status of the upgrade offer for travel part.

##### Class Name

`Status3`

##### Fields

| Name |
|  --- |
| `CONFIRMED` |
| `REJECTED` |
| `NOTOFFERED` |
| `WAITLISTED` |
| `ALREADYWAITLISTED` |
| `ALREADYCONFIRMED` |
| `NOTREQUESTED` |

#### Status 4

Status of the upgrade.

##### Class Name

`Status4`

##### Fields

| Name |
|  --- |
| `CONFIRMED` |
| `WAITLISTED` |
| `REJECTED` |
| `NONE` |

#### Status 5

Status of the upgrade offer.

##### Class Name

`Status5`

##### Fields

| Name |
|  --- |
| `CONFIRMED` |
| `REJECTED` |
| `NOTOFFERED` |
| `WAITLISTED` |
| `ALREADYWAITLISTED` |
| `ALREADYCONFIRMED` |
| `NOTREQUESTED` |

#### Status 6

Status of executed transaction.

##### Class Name

`Status6`

##### Fields

| Name |
|  --- |
| `SUCCESSFUL` |
| `CANCELLED` |

#### Status 7

Login status.

##### Class Name

`Status7`

##### Fields

| Name |
|  --- |
| `SUCCESSFUL` |

#### Status 8

Result of the failed authorization operation.

##### Class Name

`Status8`

##### Fields

| Name |
|  --- |
| `DECLINED` |
| `UNAVAILABLE` |
| `CANCELLED` |
| `ERROR` |

#### Subbalances

##### Class Name

`Subbalances`

##### Fields

| Name |
|  --- |
| `FULL` |
| `FARE` |
| `FAREANDMISC` |
| `FULLANDMISC` |
| `MISC` |

#### Suffix

Agency user's suffix, accepts lower and upper case letters (suffix values read from the PNR will be in upper case letters to accommodate this, upper case is also accepted).

##### Class Name

`Suffix`

##### Fields

| Name |
|  --- |
| `Sr` |
| `Jr` |
| `SR1` |
| `JR1` |
| `II` |
| `III` |

#### Suffix 1

Agent's suffix, accepts lower and upper case letters (suffix values read from the PNR will be in upper case letters to accommodate this, upper case is also accepted).

##### Class Name

`Suffix1`

##### Fields

| Name |
|  --- |
| `Sr` |
| `Jr` |
| `SR1` |
| `JR1` |
| `II` |
| `III` |

#### Suffix 2

Passenger suffix, accepts lower and upper case letters (suffix values read from the PNR will be in upper case letters to accommodate this, upper case is also accepted).

##### Class Name

`Suffix2`

##### Fields

| Name |
|  --- |
| `Sr` |
| `Jr` |
| `SR1` |
| `JR1` |
| `II` |
| `III` |

#### Transmission Type

Type of the transmission.

##### Class Name

`TransmissionType`

##### Fields

| Name |
|  --- |
| `ManualDrive` |
| `Manual4WD` |
| `ManualAWD` |
| `AutoDrive` |
| `Auto4WD` |
| `AutoAWD` |

#### Transmission Type 1

Type of the transmission.

##### Class Name

`TransmissionType1`

##### Fields

| Name |
|  --- |
| `MANUAL` |
| `AUTOMATIC` |
| `OTHER` |

##### Example

```
MANUAL
```

#### Trip Contact Info Type

Trip contact information address type.

##### Class Name

`TripContactInfoType`

##### Fields

| Name |
|  --- |
| `PRIVATE` |
| `BUSINESS` |

#### Trip Option

Trip option.

##### Class Name

`TripOption`

##### Fields

| Name |
|  --- |
| `EXCHANGEFLIGHT` |
| `CANCELFLIGHT` |
| `EDITPASSENGER` |
| `ADDMODIFYANCILLARIES` |
| `ADDMODIFYSEATS` |
| `UPGRADE` |
| `CANCELUPGRADE` |
| `SPLITMTO` |
| `CHECKIN` |
| `VOID` |
| `CANCELITINERARY` |
| `PURCHASEONHOLDBOOKING` |
| `OFFLOAD` |
| `ADDINSURANCEPOSTBOOKING` |

#### Type

Phone type.

##### Class Name

`Type`

##### Fields

| Name |
|  --- |
| `WORK` |
| `HOME` |
| `MOBILE` |
| `FAX` |
| `CELLULAR` |
| `AGENCY` |
| `BUSINESS` |

#### Type 1

Passenger's type.

##### Class Name

`Type1`

##### Fields

| Name |
|  --- |
| `ADT` |
| `CHD` |
| `INF` |
| `YTH` |
| `C04` |
| `C11` |
| `INS` |
| `YCD` |
| `YCB` |
| `STU` |
| `MIL` |
| `SRC` |
| `CMP` |
| `CMA` |
| `NRF` |

#### Type 2

IATA-defined Special Service Request (SSR).

##### Class Name

`Type2`

##### Fields

| Name |
|  --- |
| `STRUCTURED` |
| `NOTALLOWED` |
| `OPTIONAL` |
| `REQUIRED` |

#### Type 3

Type of the Travel Part.

##### Class Name

`Type3`

##### Fields

| Name |
|  --- |
| `ITINERARY` |
| `ITINERARYPART` |
| `SEGMENT` |

#### Type 4

Hold option type.

##### Class Name

`Type4`

##### Fields

| Name |
|  --- |
| `FREE` |
| `FEE` |

#### Type 5

Passenger's type.

##### Class Name

`Type5`

##### Fields

| Name |
|  --- |
| `ADT` |
| `YCB` |
| `YTH` |
| `CHD` |
| `C04` |
| `C11` |
| `INF` |
| `INS` |
| `STU` |
| `MIL` |
| `SRC` |
| `CMA` |
| `CMP` |

#### Type 6

Type of the class model.

##### Class Name

`Type6`

##### Fields

| Name |
|  --- |
| `SEDAN` |
| `VAN` |
| `SUV` |
| `CONVERTIBLE` |
| `TRUCK` |
| `LIMO` |
| `STATIONWAGON` |
| `PICKUP` |
| `MOTORHOME` |
| `ALLTERRAIN` |
| `RECREATIONAL` |
| `SPORT` |
| `SPECIAL` |
| `EXTENDEDCABPICKUP` |
| `REGULARCABPICKUP` |
| `SPECIALOFFER` |
| `COUPE` |
| `MONOSPACE` |
| `TWOWHEELVEHICLE` |
| `ROADSTER` |
| `CROSSOVER` |
| `COMMERCIALVANORTRUCK` |
| `OTHER` |

##### Example

```
SEDAN
```

#### Type 7

Item's type.

##### Class Name

`Type7`

##### Fields

| Name |
|  --- |
| `Text` |
| `Checkbox` |
| `Price` |

#### Type Code

Hobby values code options.

##### Class Name

`TypeCode`

##### Fields

| Name |
|  --- |
| `BAL` |
| `CLA` |
| `DNC` |
| `MUS` |
| `OPR` |
| `OTH` |
| `THT` |
| `BER` |
| `COF` |
| `COK` |
| `WIN` |
| `ATL` |
| `BIC` |
| `BSB` |
| `BSK` |
| `CMP` |
| `ECO` |
| `FIT` |
| `FSH` |
| `FTB` |
| `GLF` |
| `HIK` |
| `JOG` |
| `SKI` |
| `SNW` |
| `SOC` |
| `SWM` |
| `TEN` |
| `WGT` |
| `BUS` |
| `CAR` |
| `FAS` |
| `GAM` |
| `MOV` |
| `MSC` |
| `PHO` |
| `REA` |
| `TEC` |
| `ACT` |
| `ALL` |
| `BCH` |
| `CAS` |
| `CRU` |
| `EVT` |
| `FAM` |
| `GOU` |
| `NGT` |
| `ROM` |
| `SHP` |
| `SIG` |
| `SNG` |
| `WKN` |

#### Unit

Unit of the distance.

##### Class Name

`Unit`

##### Fields

| Name |
|  --- |
| `MILES` |
| `KILOMETERS` |

##### Example

```
MILES
```

#### Upgrade Mode

Upgrade mode values.

##### Class Name

`UpgradeMode`

##### Fields

| Name |
|  --- |
| `NONE` |
| `NOTAVAILABLE` |
| `LEG` |
| `ITINERARY` |

#### Upsell Mode

Upsell mode values.

##### Class Name

`UpsellMode`

##### Fields

| Name |
|  --- |
| `NONE` |
| `NOTAVAILABLE` |
| `LEG` |
| `ITINERARY` |

#### Value

Consent value.

##### Class Name

`Value`

##### Fields

| Name |
|  --- |
| `Y` |
| `N` |
| `U` |

##### Example

```
Y
```

#### Vcr Change Type

Type of VCR change.

##### Class Name

`VcrChangeType`

##### Fields

| Name |
|  --- |
| `EVENEXCHANGE` |
| `ADDCOLLECT` |
| `REFUND` |

#### Vehicle Size

Size of the vehicle.

##### Class Name

`VehicleSize`

##### Fields

| Name |
|  --- |
| `MINI` |
| `SUBCOMPACT` |
| `ECONOMY` |
| `COMPACT` |
| `MIDSIZE` |
| `INTERMEDIATE` |
| `STANDARD` |
| `FULLSIZE` |
| `LUXURY` |
| `PREMIUM` |
| `MINIVAN` |
| `VAN12PASSENGER` |
| `VANMOVING` |
| `VAN15PASSENGER` |
| `VANCARGO` |
| `TRUCK12FOOT` |
| `TRUCK20FOOT` |
| `TRUCK24FOOT` |
| `TRUCK26FOOT` |
| `MOPED` |
| `STRETCH` |
| `REGULAR` |
| `UNIQUE` |
| `EXOTIC` |
| `SMALLMEDIUMTRUCK` |
| `LARGETRUCK` |
| `SMALLSUV` |
| `MEDIUMSUV` |
| `LARGESUV` |
| `EXOTICSUV` |
| `FOURWHEELDRIVE` |
| `SPECIAL` |
| `MINIELITE` |
| `ECONOMYELITE` |
| `COMPACTELITE` |
| `INTERMEDIATEELITE` |
| `STANDARDELITE` |
| `FULLSIZEELITE` |
| `PREMIUMELITE` |
| `LUXURYELITE` |
| `OVERSIZE` |
| `COACH50PASSENGER` |
| `OTHER` |

##### Example

```
COMPACT
```

#### Voucher Type

Voucher enum type.

##### Class Name

`VoucherType`

##### Fields

| Name |
|  --- |
| `GIFTCARD` |
| `UATPVOUCHER` |

### Exceptions

* [OAuth Provider](#oauth-provider)

#### OAuth Provider

Authorization endpoint exception.

##### Class Name

`OauthProviderException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`OauthProviderError`](#oauth-provider-error) |  | Error code |
| `ErrorDescription` | `String` | Optional | Human-readable text providing additional information on error.<br>Used to assist the client developer in understanding the error that occurred. |
| `ErrorUri` | `String` | Optional | A URI identifying a human-readable web page with information about the error, used to provide the client developer with additional information about the error |

##### Example (as JSON)

```json
{
  "error": "invalid_request",
  "error_description": null,
  "error_uri": null
}
```


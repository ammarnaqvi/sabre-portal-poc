using DigitalConnect.Standard.Models;
using DigitalConnect.Standard.Utilities;
using System.Net;

namespace DigitalConnect.Standard
{
    public class ClientState
    {
        private AccessToken _accessToken;
        private CookieCollection _cookies;

        public AccessToken AccessToken
        {
            get => ApiHelper.DeepCloneObject(_accessToken);
            set => _accessToken = ApiHelper.DeepCloneObject(value);
        }

        public CookieCollection Cookies
        {
            get => ApiHelper.DeepCloneObject(_cookies);
            set => _cookies = ApiHelper.DeepCloneObject(value);
        }

        public string ExecutionId { get; set; }
    }
}

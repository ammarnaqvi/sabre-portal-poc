using DigitalConnect.Standard.Http.Request;
using DigitalConnect.Standard.Utilities;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DigitalConnect.Standard.Authentication
{
    internal class ExecutionIdManager : IAuthManager, IExecutionIdCredentials
    {
        public ExecutionIdManager(string executionId)
        {
            this.ExecutionId = executionId;
        }

        public string ExecutionId { get; }

        public HttpRequest Apply(HttpRequest httpRequest)
        {
            StringBuilder queryUrl = new StringBuilder(httpRequest.QueryUrl);

            ApiHelper.AppendUrlWithQueryParameters(queryUrl, new Dictionary<string, object>()
            { { "execution", ExecutionId } }, ArrayDeserialization.Plain);

            if (httpRequest.FormParameters?.Count > 0)
            {
                return new HttpRequest(httpRequest.HttpMethod, queryUrl.ToString(), httpRequest.Headers,
                    httpRequest.FormParameters, null, null);
            }
            else
            {
                return new HttpRequest(httpRequest.HttpMethod, queryUrl.ToString(), httpRequest.Headers,
                    httpRequest.Body, null, null);
            }
        }

        public Task<HttpRequest> ApplyAsync(HttpRequest httpRequest)
        {
            StringBuilder queryUrl = new StringBuilder(httpRequest.QueryUrl);

            ApiHelper.AppendUrlWithQueryParameters(queryUrl, new Dictionary<string, object>()
            { { "execution", ExecutionId } }, ArrayDeserialization.Plain);

            if (httpRequest.FormParameters?.Count > 0)
            {
                return Task.FromResult(new HttpRequest(httpRequest.HttpMethod, queryUrl.ToString(), httpRequest.Headers,
                    httpRequest.FormParameters, null, null));
            }
            else
            {
                return Task.FromResult(new HttpRequest(httpRequest.HttpMethod, queryUrl.ToString(), httpRequest.Headers,
                    httpRequest.Body, null, null));
            }
        }
    }
}

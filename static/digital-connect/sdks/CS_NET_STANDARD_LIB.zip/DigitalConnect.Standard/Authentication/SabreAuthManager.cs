using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using DigitalConnect.Standard.Controllers;
using DigitalConnect.Standard.Exceptions;
using DigitalConnect.Standard.Models;
using DigitalConnect.Standard.Http.Client;
using DigitalConnect.Standard.Http.Request;

namespace DigitalConnect.Standard.Authentication
{
    internal class SabreAuthManager : IAuthManager, ISabreAuthCredentials
    {
        private AuthorizationController oAuthApi;
        private IConfiguration config;
        public AccessToken AccessToken { get; set; }

        internal SabreAuthManager(IConfiguration config, IHttpClient httpClient, AccessToken token)
        {
            this.oAuthApi = new AuthorizationController(config, httpClient, new Dictionary<string, IAuthManager>());
            this.config = config;
            AccessToken = token;
        }

        public string BuildBasicAuthheader()
        {
            var clientId = $"V1:{config.UserId}:{config.Group}:{config.Domain}";
            var password = config.Password;

            var encodedClientId = Convert.ToBase64String(Encoding.UTF8.GetBytes(clientId));
            var encodedPassword = Convert.ToBase64String(Encoding.UTF8.GetBytes(password));

            var plainTextBytes = Encoding.UTF8.GetBytes(encodedClientId + ':' + encodedPassword);
            return "Basic " + Convert.ToBase64String(plainTextBytes);
        }

        public bool IsAuthorized()
        {
            return AccessToken != null ||
                (AccessToken?.Expiry != null &&
                AccessToken?.Expiry <= ((DateTimeOffset)DateTime.UtcNow).ToUnixTimeSeconds());
        }

        public string GetAuthorizationHeader()
        {
            return "Bearer " + AccessToken.AccessTokenProp;
        }

        public HttpRequest Apply(HttpRequest httpRequest)
        {
            if (!IsAuthorized())
            {
                string authorizationHeader = BuildBasicAuthheader();
                AccessToken token = oAuthApi.CreateToken(authorizationHeader, config.RedirectUri);
                AccessToken = token;
            }

            httpRequest.AddHeaders(new Dictionary<string, string>{ { "Authorization", GetAuthorizationHeader() } });

            return httpRequest;
        }

        public Task<HttpRequest> ApplyAsync(HttpRequest httpRequest)
        {
            if (!IsAuthorized())
            {
                string authorizationHeader = BuildBasicAuthheader();
                AccessToken token = oAuthApi.CreateToken(authorizationHeader, config.RedirectUri);
                AccessToken = token;
            }

            httpRequest.AddHeaders(new Dictionary<string, string>{ { "Authorization", GetAuthorizationHeader() } });

            return Task.FromResult(httpRequest);
        }
    }
}

using DigitalConnect.Standard.Http.Request;
using System.Threading.Tasks;

namespace DigitalConnect.Standard.Authentication
{
    internal interface IAuthManager
    {
        HttpRequest Apply(HttpRequest httpRequest);

        Task<HttpRequest> ApplyAsync(HttpRequest httpRequest);
    }
}

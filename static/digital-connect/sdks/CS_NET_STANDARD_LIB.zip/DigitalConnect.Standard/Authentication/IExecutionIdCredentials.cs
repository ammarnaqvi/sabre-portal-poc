
namespace DigitalConnect.Standard
{
    public interface IExecutionIdCredentials
    {
        string ExecutionId { get; }
    }
}
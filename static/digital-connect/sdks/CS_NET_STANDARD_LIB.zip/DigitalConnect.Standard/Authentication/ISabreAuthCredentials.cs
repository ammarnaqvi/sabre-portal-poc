using DigitalConnect.Standard.Models;

namespace DigitalConnect.Standard
{
    public interface ISabreAuthCredentials
    {
        AccessToken AccessToken { get; }
    }
}

using DigitalConnect.Standard.Utilities;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;

namespace DigitalConnect.Standard.Http
{
    public class LoggingHandler : DelegatingHandler
    {
        private readonly ILogger logger;

        public LoggingHandler(HttpMessageHandler innerHandler, ILogger logger) : base(innerHandler)
        {
            this.logger = logger;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            logger.Log("Request:");
            logger.Log(request.ToString());
            if (request.Content != null)
            {
                logger.Log("Request Body:");
                logger.Log(await request.Content.ReadAsStringAsync());
            }

            HttpResponseMessage response = await base.SendAsync(request, cancellationToken);

            logger.Log("Response:");
            logger.Log(response.ToString());
            if (response.Content != null)
            {
                logger.Log("Response Body:");
                logger.Log(await response.Content.ReadAsStringAsync());
            }

            return response;
        }
    }
}

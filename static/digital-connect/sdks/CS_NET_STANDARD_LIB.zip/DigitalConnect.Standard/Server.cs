
namespace DigitalConnect.Standard
{
    /// <summary>
    /// Available servers
    /// </summary>
    public enum Server
    {
        Default,
        Auth,
    }
}

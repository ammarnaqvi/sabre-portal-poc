using System;
using System.Net;
using DigitalConnect.Standard.Models;

namespace DigitalConnect.Standard
{
    public interface IConfiguration
    {
        /// <summary>
        /// Http client timeout
        /// </summary>
        TimeSpan Timeout { get; }

        /// <summary>
        /// Storefront ID
        /// </summary>
        string Storefront { get; }

        /// <summary>
        /// Application ID
        /// </summary>
        string ApplicationId { get; }

        /// <summary>
        /// Redirect URI
        /// </summary>
        string RedirectUri { get; }

        /// <summary>
        /// EPR (a.k.a. User ID).
        /// </summary>
        string UserId { get; }

        /// <summary>
        /// PCC (a.k.a. Group).
        /// </summary>
        string Group { get; }

        /// <summary>
        /// Domain ("AA" for Travel Network customers, or your airline code for Airline Solutions customers, e.g. "LA").
        /// </summary>
        string Domain { get; }

        /// <summary>
        /// Sabre APIs password.
        /// </summary>
        string Password { get; }

        /// <summary>
        /// Current API environment
        /// </summary>
        Environment Environment { get; }

        /// <summary>
        /// HostAndPort value
        /// </summary>
        string HostAndPort { get; }

        /// <summary>
        /// ApiContextPath value
        /// </summary>
        string ApiContextPath { get; }

        /// <summary>
        /// AuthContextPath value
        /// </summary>
        string AuthContextPath { get; }

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends it with template parameters
        /// </summary>
        /// <param name="alias">Default value:DEFAULT</param>
        /// <return>Returns the baseurl</return>
        string GetBaseUri(Server alias = Server.Default);
    }
}
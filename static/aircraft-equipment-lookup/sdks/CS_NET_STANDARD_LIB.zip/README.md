# Getting Started with Aircraft Equipment Lookup

## Getting Started

The Aircraft Equipment Lookup API returns the aircraft name associated with a specified IATA aircraft equipment code.

### Install the Package

The SDK is available as a NuGet that you can search for and install using the NuGet GUI. You can also use the following command on the Package Manager Console:

```csharp
Install-Package DigitalConnect -Version 1.0.0
```

You can also view the NuGet at:
https://www.nuget.org/packages/DigitalConnect/1.0.0

If you are building with .NET CLI tools then you can also use the following command:

```bash
dotnet add package DigitalConnect --version 1.0.0
```

### Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

| Name | Value | Description |
|  --- | --- | --- |
| default | `DEFAULT` | **Default**  |
| mock | `MOCK` |  |

### Initialize the API Client

The following parameters are configurable for the API Client.

| Parameter | Type | Description |
|  --- | --- | --- |
| `OauthClientId` | `string` | OAuth 2 Client ID |
| `OauthClientSecret` | `string` | OAuth 2 Client Secret |
| `HostAndPort` | `string` | *Default*: `"api.sabre.com"` |
| `ApiContextPath` | `string` | *Default*: `"v1"` |
| `AuthContextPath` | `string` | *Default*: `"/v2/auth/token"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.Default`** |

The API client can be initialized as following.

```csharp
DigitalConnect.Standard.DigitalConnectClient client = new DigitalConnect.Standard.DigitalConnectClient.Builder()
    .OAuthClientId("OAuthClientId")
    .OAuthClientSecret("OAuthClientSecret")
    .Environment(Environment.Default)
    .HostAndPort("api.sabre.com")
    .ApiContextPath("v1")
    .AuthContextPath("/v2/auth/token")
    .Build();
```

You must now authorize the client.

### Authorization

The SDK uses *OAuth 2.0 Authorization* to authorize the client.

The `Authorize()` method will exchange the OAuth client credentials for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```csharp
try 
{
    OAuthToken token = client.Auth.Authorize();
    Configuration authorizedConfig = client.Config.ToBuilder().WithOAuthToken(token).Build();
    client = new DigitalConnectClient(authorizedConfig);
} 
catch (OAuthProviderException e)
{
    // TODO Handle exception
}
```

The client can now make authorized endpoint calls.

#### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```csharp
// store token
SaveTokenToDatabase(client.Config.OAuthToken)
```

#### Creating a client from a stored token

To authorize a client from a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```csharp
// load token later
OAuthToken token = LoadTokenFromDatabase();

// Set other configuration, then instantiate client
Configuration config = new Configuration.Builder().WithOAuthToken(token).Build();
DigitalConnectClient client = new DigitalConnectClient(config);
```

#### Complete example

```csharp
using DigitalConnect.Standard;
using DigitalConnect.Standard.Models;
using DigitalConnect.Standard.Exceptions;
using System.Collections.Generic;
namespace OAuthTestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // Configuration parameters and credentials
            string oauthClientId = "oauthClientId"; // OAuth 2 Client ID
            string oauthClientSecret = "oauthClientSecret"; // OAuth 2 Client Secret
           
            var configBuilder = new Configuration.Builder();
            Configuration config = configBuilder
                .WithOauthClientId(oauthClientId)
                .WithOauthClientSecret(oauthClientSecret)
                .Build();

            DigitalConnectClient client = new DigitalConnectClient(config);
            
            try
            {
                OAuthToken token = LoadTokenFromDatabase();
                // Set the token if it is not set before                if (token == null)
                {
                    token = client.Auth.Authorize();
                }
                SaveTokenToDatabase(token);
                Configuration authorizedConfig = client.Config.ToBuilder().WithOAuthToken(token).Build();
                client = new DigitalConnectClient(authorizedConfig);
            }
            catch (OAuthProviderException e) 
            {
                // TODO Handle exception
            }
        }

        //function for storing token to database
        static void SaveTokenToDatabase(OAuthToken token)
        {
            //Save token here
        }

        //function for loading token from database
        static OAuthToken LoadTokenFromDatabase()
        {
            OAuthToken token = null;
            //token = Get token here
            return token;
        }
    }
}

// the client is now authorized and you can use controllers to make endpoint calls
```

## API Reference

### List of APIs

* [API](#api)

### API

#### Overview

##### Get instance

An instance of the `APIController` class can be accessed from the API Client.

```
APIController aPIController = client.APIController;
```

#### Aircraft Equipment Lookup

```csharp
AircraftEquipmentLookupAsync(string aircraftcode = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aircraftcode` | `string` | Query, Optional | 3-character IATA aircraft equipment code.<br><br>Multiple values are accepted, delimited with commas.<br>Default: all codes and their corresponding names. |

##### Response Type

[`Task<Models.AircraftEquipmentLookupResponse>`](#aircraft-equipment-lookup-response)

##### Example Usage

```csharp
string aircraftcode = "TU5";

try
{
    AircraftEquipmentLookupResponse result = await aPIController.AircraftEquipmentLookupAsync(aircraftcode);
}
catch (ApiException e){};
```

##### Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request<br>   - Parameter 'aircraftcode' must be a valid value.<br> | `ApiException` |

## Model Reference

### Structures

* [Aircraft Equipment Lookup Response](#aircraft-equipment-lookup-response)
* [Aircraft Info](#aircraft-info)
* [Common Link](#common-link)
* [OAuth Token](#oauth-token)

#### Aircraft Equipment Lookup Response

##### Class Name

`AircraftEquipmentLookupResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AircraftInfo` | [`List<Models.AircraftInfo>`](#aircraft-info) | Optional | Repeats associated aircraft equipment information. |
| `Links` | [`List<Models.CommonLink>`](#common-link) | Optional | - |

##### Example (as JSON)

```json
{
  "AircraftInfo": null,
  "Links": null
}
```

#### Aircraft Info

##### Class Name

`AircraftInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AircraftCode` | `string` | Optional | The aircraft equipment code. |
| `AircraftName` | `string` | Optional | The name and model that corresponds to the specified aircraft equipment code(s). |

##### Example (as JSON)

```json
{
  "AircraftCode": null,
  "AircraftName": null
}
```

#### Common Link

##### Class Name

`CommonLink`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rel` | [`Models.Rel?`](#rel) | Optional | Describes relationship between href and current request. |
| `Href` | `string` | Optional | Link to related API request. |

##### Example (as JSON)

```json
{
  "rel": null,
  "href": null
}
```

#### OAuth Token

OAuth 2 Authorization endpoint response

##### Class Name

`OauthToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` |  | Access token |
| `TokenType` | `string` |  | Type of access token |
| `ExpiresIn` | `long?` | Optional | Time in seconds before the access token expires |
| `Scope` | `string` | Optional | List of scopes granted<br>This is a space-delimited list of strings. |
| `Expiry` | `long?` | Optional | Time of token expiry as unix timestamp (UTC) |

##### Example (as JSON)

```json
{
  "access_token": "access_token8",
  "token_type": "token_type2",
  "expires_in": null,
  "scope": null,
  "expiry": null
}
```

### Enumerations

* [OAuth Provider Error](#oauth-provider-error)
* [Rel](#rel)

#### OAuth Provider Error

OAuth 2 Authorization error codes

##### Class Name

`OauthProviderError`

##### Fields

| Name | Description |
|  --- | --- |
| `InvalidRequest` | The request is missing a required parameter, includes an unsupported parameter value (other than grant type), repeats a parameter, includes multiple credentials, utilizes more than one mechanism for authenticating the client, or is otherwise malformed. |
| `InvalidClient` | Client authentication failed (e.g., unknown client, no client authentication included, or unsupported authentication method). |
| `InvalidGrant` | The provided authorization grant (e.g., authorization code, resource owner credentials) or refresh token is invalid, expired, revoked, does not match the redirection URI used in the authorization request, or was issued to another client. |
| `UnauthorizedClient` | The authenticated client is not authorized to use this authorization grant type. |
| `UnsupportedGrantType` | The authorization grant type is not supported by the authorization server. |
| `InvalidScope` | The requested scope is invalid, unknown, malformed, or exceeds the scope granted by the resource owner. |

#### Rel

Describes relationship between href and current request.

##### Class Name

`Rel`

##### Fields

| Name |
|  --- |
| `Self` |
| `Shop` |
| `Forecast` |
| `AirportsInCity` |
| `AirlineInfo` |
| `Destinations` |
| `View` |
| `Schema` |
| `NextResults` |
| `PrevResults` |
| `LinkTemplate` |
| `ShopTemplate` |
| `TagLookupLinkTemplate` |
| `PaginatedRequestLinkTemplate` |
| `ItemLinkTemplate` |

##### Example

```
self
```

### Exceptions

* [OAuth Provider](#oauth-provider)

#### OAuth Provider

OAuth 2 Authorization endpoint exception

##### Class Name

`OauthProviderException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Models.OauthProviderError`](#oauth-provider-error) |  | Error code |
| `ErrorDescription` | `string` | Optional | Human-readable text providing additional information on error.<br>Used to assist the client developer in understanding the error that occurred. |
| `ErrorUri` | `string` | Optional | A URI identifying a human-readable web page with information about the error, used to provide the client developer with additional information about the error |

##### Example (as JSON)

```json
{
  "error": "invalid_request",
  "error_description": null,
  "error_uri": null
}
```


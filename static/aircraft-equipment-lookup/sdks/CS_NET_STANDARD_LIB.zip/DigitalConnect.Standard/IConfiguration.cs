using System;
using System.Net;
using DigitalConnect.Standard.Models;

namespace DigitalConnect.Standard
{
    public interface IConfiguration
    {
        /// <summary>
        /// Http client timeout
        /// </summary>
        TimeSpan Timeout { get; }

        /// <summary>
        /// OAuth 2 Client ID
        /// </summary>
        string OauthClientId { get; }

        /// <summary>
        /// OAuth 2 Client Secret
        /// </summary>
        string OauthClientSecret { get; }

        /// <summary>
        /// Current API environment
        /// </summary>
        Environment Environment { get; }

        /// <summary>
        /// HostAndPort value
        /// </summary>
        string HostAndPort { get; }

        /// <summary>
        /// ApiContextPath value
        /// </summary>
        string ApiContextPath { get; }

        /// <summary>
        /// AuthContextPath value
        /// </summary>
        string AuthContextPath { get; }

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends it with template parameters
        /// </summary>
        /// <param name="alias">Default value:DEFAULT</param>
        /// <return>Returns the baseurl</return>
        string GetBaseUri(Server alias = Server.Default);
    }
}
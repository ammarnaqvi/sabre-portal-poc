
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using DigitalConnect.Standard.Controllers;
using DigitalConnect.Standard.Exceptions;
using DigitalConnect.Standard.Models;

namespace DigitalConnect.Standard.Utilities
{
    public class AuthManager
    {
        private OauthAuthorizationController oAuthApi;
        private Configuration config;

        public AuthManager(Configuration config) 
        {
            this.oAuthApi = new OauthAuthorizationController(config);
            this.config = config;
        }

        public OauthToken Authorize(Dictionary<string, object> additionalParameters = null)
        {
            string authorizationHeader = BuildBasicAuthheader(config.OauthClientId,
                config.OauthClientSecret);
            OauthToken token = oAuthApi.RequestToken(authorizationHeader,fieldParameters: additionalParameters);
            return token;
        }

        public string BuildBasicAuthheader(string username, string password)
        {
            var plainTextBytes = Encoding.UTF8.GetBytes(username + ':' + password);
            return "Basic " + Convert.ToBase64String(plainTextBytes);
        }
        
        public static bool CheckAuthorization(OAuthToken oAuthToken)
        {
            if (oAuthToken == null)
            {
                return false;
            }
            return true;
        }
    }
}
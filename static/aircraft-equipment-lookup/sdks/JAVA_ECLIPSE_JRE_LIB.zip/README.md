# Getting Started with Aircraft Equipment Lookup

## Getting Started

The Aircraft Equipment Lookup API returns the aircraft name associated with a specified IATA aircraft equipment code.

### Install the Package

Install the SDK by adding the following dependency in your project's pom.xml file:

```xml
<dependency>
  <groupId>io.apimatic.sabre</groupId>
  <artifactId>digital-connect</artifactId>
  <version>1.0.0</version>
</dependency>
```

You can also view the package at:
https://mvnrepository.com/artifact/io.apimatic.sabre/digital-connect/1.0.0

### Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

| Name | Value | Description |
|  --- | --- | --- |
| default | `ENUM_DEFAULT` | **Default**  |
| mock | `MOCK` |  |

### Initialize the API Client

The following parameters are configurable for the API Client.

| Parameter | Type | Description |
|  --- | --- | --- |
| `oauthClientId` | `String` | OAuth 2 Client ID |
| `oauthClientSecret` | `String` | OAuth 2 Client Secret |
| `hostAndPort` | `String` | *Default*: `"api.sabre.com"` |
| `apiContextPath` | `String` | *Default*: `"v1"` |
| `authContextPath` | `String` | *Default*: `"/v2/auth/token"` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.ENUM_DEFAULT`** |

The API client can be initialized as following.

```java
DigitalConnectClient client = new DigitalConnectClient.Builder()
    .oauthClientId("OAuthClientId")
    .oauthClientSecret("OAuthClientSecret")
    .environment(Environment.ENUM_DEFAULT)
    .hostAndPort("api.sabre.com")
    .apiContextPath("v1")
    .authContextPath("/v2/auth/token")
    .build();
```

You must now authorize the client.

### Authorization

The SDK uses *OAuth 2.0 Authorization* to authorize the client.

The `authorize()` method will exchange the OAuth client credentials for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```java
try {
    OauthToken token = client.auth().authorize();
    Configuration authorizedConfig = client.getConfiguration().newBuilder().setOAuthToken(token).build();
    client = new DigitalConnectClient(authorizedConfig);
} catch (Throwable e) {
    // TODO Handle exception
}
```

The client can now make authorized endpoint calls.

#### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```java
// store token
storeAccessToken(client.getConfiguration().getOauthToken)
```

#### Creating a client from a stored token

To authorize a client from a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```java
// load token later...
OauthToken token = loadAccessToken();

// Set other configuration, then instantiate client
Configuration config = new Configuration.Builder().setOAuthToken(token).build();
DigitalConnect client = new DigitalConnectClient(config);
```

#### Complete example

```java
package com.example;

import java.util.LinkedList;
import java.util.List;

public class Main {
    public Main() {
        DigitalConnectClient client = new DigitalConnectClient.Builder()
            .oauthClientId("OAuthClientId")
            .oauthClientSecret("OAuthClientSecret")
            .environment(Environment.ENUM_DEFAULT)
            .hostAndPort("api.sabre.com")
            .apiContextPath("v1")
            .authContextPath("/v2/auth/token")
            .build();
        
        


        try {
            OauthToken token = client.auth().authorize();
            Configuration authorizedConfig = client.getConfiguration().newBuilder().setOAuthToken(token).build();
            client = new DigitalConnectClient(authorizedConfig);
        } catch (Throwable e) {
            // TODO Handle exception
        }

        // the client is now authorized; you can use client to make endpoint calls
    }
}
```

## API Reference

### List of APIs

* [API](#api)

### API

#### Overview

##### Get instance

An instance of the `APIController` class can be accessed from the API Client.

```
APIController aPIController = client.getAPIController();
```

#### Aircraft Equipment Lookup

```java
CompletableFuture<AircraftEquipmentLookupResponse> aircraftEquipmentLookupAsync(
    final String aircraftcode)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aircraftcode` | `String` | Query, Optional | 3-character IATA aircraft equipment code.<br><br>Multiple values are accepted, delimited with commas.<br>Default: all codes and their corresponding names. |

##### Response Type

[`AircraftEquipmentLookupResponse`](#aircraft-equipment-lookup-response)

##### Example Usage

```java
String aircraftcode = "TU5";

aPIController.aircraftEquipmentLookupAsync(aircraftcode).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
    }).exceptionally(exception -> {
        // TODO failed to authorize
        return null;
    });
} catch (ApiException e) {
    e.printStackTrace();
} catch (IOException e) {
    e.printStackTrace();
}
```

##### Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request<br>   - Parameter 'aircraftcode' must be a valid value.<br> | `ApiException` |

## Model Reference

### Structures

* [Aircraft Equipment Lookup Response](#aircraft-equipment-lookup-response)
* [Aircraft Info](#aircraft-info)
* [Common Link](#common-link)
* [OAuth Token](#oauth-token)

#### Aircraft Equipment Lookup Response

##### Class Name

`AircraftEquipmentLookupResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AircraftInfo` | [`List<AircraftInfo>`](#aircraft-info) | Optional | Repeats associated aircraft equipment information. |
| `Links` | [`List<CommonLink>`](#common-link) | Optional | - |

##### Example (as JSON)

```json
{
  "AircraftInfo": null,
  "Links": null
}
```

#### Aircraft Info

##### Class Name

`AircraftInfo`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AircraftCode` | `String` | Optional | The aircraft equipment code. |
| `AircraftName` | `String` | Optional | The name and model that corresponds to the specified aircraft equipment code(s). |

##### Example (as JSON)

```json
{
  "AircraftCode": null,
  "AircraftName": null
}
```

#### Common Link

##### Class Name

`CommonLink`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rel` | [`Rel`](#rel) | Optional | Describes relationship between href and current request. |
| `Href` | `String` | Optional | Link to related API request. |

##### Example (as JSON)

```json
{
  "rel": null,
  "href": null
}
```

#### OAuth Token

OAuth 2 Authorization endpoint response

##### Class Name

`OauthToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `String` |  | Access token |
| `TokenType` | `String` |  | Type of access token |
| `ExpiresIn` | `Long` | Optional | Time in seconds before the access token expires |
| `Scope` | `String` | Optional | List of scopes granted<br>This is a space-delimited list of strings. |
| `Expiry` | `Long` | Optional | Time of token expiry as unix timestamp (UTC) |

##### Example (as JSON)

```json
{
  "access_token": "access_token8",
  "token_type": "token_type2",
  "expires_in": null,
  "scope": null,
  "expiry": null
}
```

### Enumerations

* [OAuth Provider Error](#oauth-provider-error)
* [Rel](#rel)

#### OAuth Provider Error

OAuth 2 Authorization error codes

##### Class Name

`OauthProviderError`

##### Fields

| Name | Description |
|  --- | --- |
| `InvalidRequest` | The request is missing a required parameter, includes an unsupported parameter value (other than grant type), repeats a parameter, includes multiple credentials, utilizes more than one mechanism for authenticating the client, or is otherwise malformed. |
| `InvalidClient` | Client authentication failed (e.g., unknown client, no client authentication included, or unsupported authentication method). |
| `InvalidGrant` | The provided authorization grant (e.g., authorization code, resource owner credentials) or refresh token is invalid, expired, revoked, does not match the redirection URI used in the authorization request, or was issued to another client. |
| `UnauthorizedClient` | The authenticated client is not authorized to use this authorization grant type. |
| `UnsupportedGrantType` | The authorization grant type is not supported by the authorization server. |
| `InvalidScope` | The requested scope is invalid, unknown, malformed, or exceeds the scope granted by the resource owner. |

#### Rel

Describes relationship between href and current request.

##### Class Name

`Rel`

##### Fields

| Name |
|  --- |
| `Self` |
| `Shop` |
| `Forecast` |
| `AirportsInCity` |
| `AirlineInfo` |
| `Destinations` |
| `View` |
| `Schema` |
| `NextResults` |
| `PrevResults` |
| `LinkTemplate` |
| `ShopTemplate` |
| `TagLookupLinkTemplate` |
| `PaginatedRequestLinkTemplate` |
| `ItemLinkTemplate` |

##### Example

```
self
```

### Exceptions

* [OAuth Provider](#oauth-provider)

#### OAuth Provider

OAuth 2 Authorization endpoint exception

##### Class Name

`OauthProviderException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`OauthProviderError`](#oauth-provider-error) |  | Error code |
| `ErrorDescription` | `String` | Optional | Human-readable text providing additional information on error.<br>Used to assist the client developer in understanding the error that occurred. |
| `ErrorUri` | `String` | Optional | A URI identifying a human-readable web page with information about the error, used to provide the client developer with additional information about the error |

##### Example (as JSON)

```json
{
  "error": "invalid_request",
  "error_description": null,
  "error_uri": null
}
```


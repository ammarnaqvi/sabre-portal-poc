# Getting Started with Advanced Calendar Search

## Getting Started

The Advanced Calendar Search API returns the lowest published fares and flight itineraries for a given city pair.

The API uses the Travel Insight engine to retrieve up to 192 days of shopped fare data for a given city pair and length of stay available in the Sabre® cache.

Multiple search preferences are available to sort and filter results, including the ability to:

limit flight options to online itineraries only, include/exclude carriers and specify particular days of the week;
specify multiple lengths of stay, a maximum number of stops;
connecting-flight time or a departure/arrival time window on each flight leg.

### Install the Package

The SDK is available as a NuGet that you can search for and install using the NuGet GUI. You can also use the following command on the Package Manager Console:

```csharp
Install-Package DigitalConnect -Version 1.0.0
```

You can also view the NuGet at:
https://www.nuget.org/packages/DigitalConnect/1.0.0

If you are building with .NET CLI tools then you can also use the following command:

```bash
dotnet add package DigitalConnect --version 1.0.0
```

### Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

| Name | Value | Description |
|  --- | --- | --- |
| default | `DEFAULT` | **Default**  |
| mock | `MOCK` |  |

### Initialize the API Client

The following parameters are configurable for the API Client.

| Parameter | Type | Description |
|  --- | --- | --- |
| `OauthClientId` | `string` | OAuth 2 Client ID |
| `OauthClientSecret` | `string` | OAuth 2 Client Secret |
| `HostAndPort` | `string` | *Default*: `"api.sabre.com"` |
| `ApiContextPath` | `string` | *Default*: `"v1"` |
| `AuthContextPath` | `string` | *Default*: `"/v2/auth/token"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.Default`** |

The API client can be initialized as following.

```csharp
DigitalConnect.Standard.DigitalConnectClient client = new DigitalConnect.Standard.DigitalConnectClient.Builder()
    .OAuthClientId("OAuthClientId")
    .OAuthClientSecret("OAuthClientSecret")
    .Environment(Environment.Default)
    .HostAndPort("api.sabre.com")
    .ApiContextPath("v1")
    .AuthContextPath("/v2/auth/token")
    .Build();
```

You must now authorize the client.

### Authorization

The SDK uses *OAuth 2.0 Authorization* to authorize the client.

The `Authorize()` method will exchange the OAuth client credentials for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```csharp
try 
{
    OAuthToken token = client.Auth.Authorize();
    Configuration authorizedConfig = client.Config.ToBuilder().WithOAuthToken(token).Build();
    client = new DigitalConnectClient(authorizedConfig);
} 
catch (OAuthProviderException e)
{
    // TODO Handle exception
}
```

The client can now make authorized endpoint calls.

#### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```csharp
// store token
SaveTokenToDatabase(client.Config.OAuthToken)
```

#### Creating a client from a stored token

To authorize a client from a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```csharp
// load token later
OAuthToken token = LoadTokenFromDatabase();

// Set other configuration, then instantiate client
Configuration config = new Configuration.Builder().WithOAuthToken(token).Build();
DigitalConnectClient client = new DigitalConnectClient(config);
```

#### Complete example

```csharp
using DigitalConnect.Standard;
using DigitalConnect.Standard.Models;
using DigitalConnect.Standard.Exceptions;
using System.Collections.Generic;
namespace OAuthTestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // Configuration parameters and credentials
            string oauthClientId = "oauthClientId"; // OAuth 2 Client ID
            string oauthClientSecret = "oauthClientSecret"; // OAuth 2 Client Secret
           
            var configBuilder = new Configuration.Builder();
            Configuration config = configBuilder
                .WithOauthClientId(oauthClientId)
                .WithOauthClientSecret(oauthClientSecret)
                .Build();

            DigitalConnectClient client = new DigitalConnectClient(config);
            
            try
            {
                OAuthToken token = LoadTokenFromDatabase();
                // Set the token if it is not set before                if (token == null)
                {
                    token = client.Auth.Authorize();
                }
                SaveTokenToDatabase(token);
                Configuration authorizedConfig = client.Config.ToBuilder().WithOAuthToken(token).Build();
                client = new DigitalConnectClient(authorizedConfig);
            }
            catch (OAuthProviderException e) 
            {
                // TODO Handle exception
            }
        }

        //function for storing token to database
        static void SaveTokenToDatabase(OAuthToken token)
        {
            //Save token here
        }

        //function for loading token from database
        static OAuthToken LoadTokenFromDatabase()
        {
            OAuthToken token = null;
            //token = Get token here
            return token;
        }
    }
}

// the client is now authorized and you can use controllers to make endpoint calls
```

## API Reference

### List of APIs

* [API](#api)

### API

#### Overview

##### Get instance

An instance of the `APIController` class can be accessed from the API Client.

```
APIController aPIController = client.APIController;
```

#### Advanced Calendar Search

```csharp
AdvancedCalendarSearchAsync(
    Models.AdvancedCalendarSearchRequest advancedCalendarSearchRequest,
    string pointofsalecountry = null,
    string view = null,
    bool? enabletagging = false,
    int? limit = 50,
    int? offset = 1)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `advancedCalendarSearchRequest` | [`Models.AdvancedCalendarSearchRequest`](#advanced-calendar-search-request) | Body, Required | The API returns up to 200 lead fares (either nonstop or overall, whichever is lowest) with the corresponding flight itinerary and fare breakdown for each lead fare. |
| `pointofsalecountry` | `string` | Query, Optional | 2-letter ISO 3166 country code.<br><br>Retrieves data specific to a given point of sale country. |
| `view` | `string` | Query, Optional | The response view definition.<br><br>Accepts a Sabre response view or custom response view.<br>Sample Values:<br>- `IF_ITIN_TOTAL_PRICE`: A Sabre response view that excludes numerous response paths for the InstaFlights Search API.<br>- `BFM_ITIN_TOTAL_PRICE`: A Sabre response view that excludes numerous response paths for the Bargain Finder Max. |
| `enabletagging` | `bool?` | Query, Optional | Determines whether itineraries for subsequent calls will be stored in the Sabre Cache.<br><br>When 'enabletagging' is set to true:<br>  - Returns a RequestID for the tagged element data set and stores in the Sabre Cache<br>  - Returns a TagID for each tagged element and stores in the Sabre cache |
| `limit` | `int?` | Query, Optional | The number of tagged elements to retrieve per request |
| `offset` | `int?` | Query, Optional | The starting position in the list of all tagged elements that meet the query criteria |

##### Response Type

[`Task<Models.AdvancedCalendarSearchResponse>`](#advanced-calendar-search-response)

##### Example Usage

```csharp
var advancedCalendarSearchRequest = new AdvancedCalendarSearchRequest();
string pointofsalecountry = "US";
int? limit = 5;

try
{
    AdvancedCalendarSearchResponse result = await aPIController.AdvancedCalendarSearchAsync(advancedCalendarSearchRequest, pointofsalecountry, null, null, limit, null);
}
catch (ApiException e){};
```

##### Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request<br><br>- Parameter 'limit' must be of type 'number', or string equal to 'None'.<br>- Parameter 'limit' must be between 1 and 2147483647.<br>- Parameter 'offset' must be of type 'number'.<br>- Parameter 'offset' must be between 1 and 2147483647.<br>- View does not exist.<br> | `ApiException` |
| 404 | Not Found<br><br>- No results were found.<br> | `ApiException` |

#### Flights by Request Id

Pagination Request Endpoint

```csharp
FlightsByRequestIdAsync(
    string requestid,
    string view = null,
    int? limit = 50,
    int? offset = 1)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestid` | `string` | Template, Required | The Request ID.<br><br>The Pagination Request endpoint has a required requestid URI variable which retrieves the set of tags associated with a given Request ID. Any valid Request ID can be substituted for {requestid}. A Request ID is returned for the data set when enabletagging=true is used in a previous Advanced Calendar Search API request. |
| `view` | `string` | Query, Optional | The response view definition.<br><br>Accepts a Sabre response view or custom response view.<br>Sample Values:<br>- `IF_ITIN_TOTAL_PRICE`: A Sabre response view that excludes numerous response paths for the InstaFlights Search API.<br>- `BFM_ITIN_TOTAL_PRICE`: A Sabre response view that excludes numerous response paths for the Bargain Finder Max. |
| `limit` | `int?` | Query, Optional | The number of tagged elements to retrieve per request. |
| `offset` | `int?` | Query, Optional | The starting position in the list of all tagged elements that meet the query criteria. |

##### Response Type

[`Task<Models.AdvancedCalendarSearchByRequestIDResponse>`](#advanced-calendar-search-by-request-id-response)

##### Example Usage

```csharp
string requestid = "BargainFinderMax_ADCRQ~c78cdd4f-08c1-461b-b99b-e28b7dbd1881";
string view = "BFM_ITIN_TOTAL_PRICE";

try
{
    AdvancedCalendarSearchByRequestIDResponse result = await aPIController.FlightsByRequestIdAsync(requestid, view, null, null);
}
catch (ApiException e){};
```

##### Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request<br><br>- Parameter 'limit' must be of type 'number', or string equal to 'None'.<br>- Parameter 'limit' must be between 1 and 2147483647.<br>- Parameter 'offset' must be of type 'number'.<br>- Parameter 'offset' must be between 1 and 2147483647.<br>- View does not exist.<br> | `ApiException` |
| 404 | Not Found<br><br>- No tag ID named 'tagid' is defined<br> | `ApiException` |

#### Flights by Tag Id

Tag ID Lookup Endpoint

```csharp
FlightsByTagIdAsync(string tagid, string view = null)
```

##### Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tagid` | `string` | Template, Required | The tagged element ID.<br><br>The Tag ID Lookup endpoint has a required tagid URI variable which retrieves the tagged element for a given Tag ID. Any valid Tag ID can be substituted for {tagid}. A Tag ID is returned with each tagged element when enabletagging=true is used in a previous Advanced Calendar Search API request. |
| `view` | `string` | Query, Optional | The response view definition.<br><br>Accepts a Sabre response view or custom response view.<br>Sample Values:<br>- `IF_ITIN_TOTAL_PRICE`: A Sabre response view that excludes numerous response paths for the InstaFlights Search API.<br>- `BFM_ITIN_TOTAL_PRICE`: A Sabre response view that excludes numerous response paths for the Bargain Finder Max. |

##### Response Type

[`Task<Models.AdvancedCalendarSearchByTagIDResponse>`](#advanced-calendar-search-by-tag-id-response)

##### Example Usage

```csharp
string tagid = "BargainFinderMax_ADCRQ~c78cdd4f-08c1-461b-b99b-e28b7dbd1881~1";
string view = "BFM_ITIN_TOTAL_PRICE";

try
{
    AdvancedCalendarSearchByTagIDResponse result = await aPIController.FlightsByTagIdAsync(tagid, view);
}
catch (ApiException e){};
```

##### Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request<br><br>- View does not exist.<br> | `ApiException` |
| 404 | Not Found<br><br>- No tag ID named 'tagid' is defined<br> | `ApiException` |

## Model Reference

### Structures

* [Advanced Calendar Search by Request ID Response](#advanced-calendar-search-by-request-id-response)
* [Advanced Calendar Search by Tag ID Response](#advanced-calendar-search-by-tag-id-response)
* [Advanced Calendar Search Request](#advanced-calendar-search-request)
* [Advanced Calendar Search Response](#advanced-calendar-search-response)
* [Air Itinerary Type](#air-itinerary-type)
* [Air Traveler Avail](#air-traveler-avail)
* [Company Name](#company-name)
* [Days Range](#days-range)
* [Departure Dates](#departure-dates)
* [Destination Location](#destination-location)
* [Intelli Sell Transaction](#intelli-sell-transaction)
* [Link](#link)
* [Link 2](#link-2)
* [OAuth Token](#oauth-token)
* [Origin Destination Information](#origin-destination-information)
* [Origin Location](#origin-location)
* [OTA Air Low Fare Search RQ](#ota-air-low-fare-search-rq)
* [OTA Air Low Fare Search RS](#ota-air-low-fare-search-rs)
* [OTA Air Low Fare Search RS1](#ota-air-low-fare-search-rs1)
* [Page](#page)
* [Passenger Type Quantity](#passenger-type-quantity)
* [POS](#pos)
* [Price Request Information](#price-request-information)
* [Priced Itinerary](#priced-itinerary)
* [Priced Itinerary 1](#priced-itinerary-1)
* [Request Type](#request-type)
* [Requestor ID](#requestor-id)
* [Segment Type](#segment-type)
* [Source](#source)
* [Ticketing Info](#ticketing-info)
* [TPA Extensions](#tpa-extensions)
* [TPA Extensions 1](#tpa-extensions-1)
* [TPA Extensions 3](#tpa-extensions-3)
* [Travel Preferences](#travel-preferences)
* [Traveler Info Summary](#traveler-info-summary)
* [Warning](#warning)
* [Warnings](#warnings)

#### Advanced Calendar Search by Request ID Response

##### Class Name

`AdvancedCalendarSearchByRequestIDResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestID` | `string` | Optional | - |
| `Page` | [`Models.Page`](#page) | Optional | - |
| `OTAAirLowFareSearchRS` | [`Models.OTAAirLowFareSearchRS1`](#ota-air-low-fare-search-rs1) | Optional | - |
| `Links` | [`List<Models.Link>`](#link) | Optional | Array of links for different types of relations, e.g. self, linkTemplate, shop |

##### Example (as JSON)

```json
{
  "RequestID": null,
  "Page": null,
  "OTA_AirLowFareSearchRS": null,
  "Links": null
}
```

#### Advanced Calendar Search by Tag ID Response

##### Class Name

`AdvancedCalendarSearchByTagIDResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SequenceNumber` | `int?` | Optional | - |
| `AirItinerary` | [`Models.AirItineraryType`](#air-itinerary-type) | Optional | Please see full specification in json schema and json schema description files - API resources |
| `AirItineraryPricingInfo` | `object` | Optional | Please see full specification in json schema and json schema description files - API resources |
| `TicketingInfo` | [`Models.TicketingInfo`](#ticketing-info) | Optional | Please see full specification in json schema and json schema description files - API resources |
| `TPAExtensions` | [`Models.TPAExtensions`](#tpa-extensions) | Optional | Please see full specification in json schema and json schema description files - API resources |
| `Links` | [`List<Models.Link2>`](#link-2) | Optional | Array of links for different types of relations, e.g. self, linkTemplate, shop |

##### Example (as JSON)

```json
{
  "SequenceNumber": null,
  "AirItinerary": null,
  "AirItineraryPricingInfo": null,
  "TicketingInfo": null,
  "TPA_Extensions": null,
  "Links": null
}
```

#### Advanced Calendar Search Request

##### Class Name

`AdvancedCalendarSearchRequest`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OTAAirLowFareSearchRQ` | [`Models.OTAAirLowFareSearchRQ`](#ota-air-low-fare-search-rq) | Optional | The Low Fare Search Response message contains a number of Priced Itinerary options.<br>Each includes:<br>  - A set of available flights matching the client's request.<br>  - Pricing information including taxes and full fare breakdown for each passenger type.<br>  - Ticketing information<br>  - Fare Basis Codes and the information necessary to make a rules entry.<br>This message contains similar information to a standard airline CRS or GDS Low Fare Search Response message. |

##### Example (as JSON)

```json
{
  "OTA_AirLowFareSearchRQ": null
}
```

#### Advanced Calendar Search Response

##### Class Name

`AdvancedCalendarSearchResponse`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OTAAirLowFareSearchRS` | [`Models.OTAAirLowFareSearchRS`](#ota-air-low-fare-search-rs) | Optional | - |
| `Links` | [`List<Models.Link>`](#link) | Optional | Array of links for different types of relations, e.g. self, linkTemplate, shop |

##### Example (as JSON)

```json
{
  "OTA_AirLowFareSearchRS": null,
  "Links": null
}
```

#### Air Itinerary Type

Please see full specification in json schema and json schema description files - API resources

##### Class Name

`AirItineraryType`

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "DirectionInd": "Return",
  "OriginDestinationOptions": {
    "OriginDestinationOption": [
      {
        "ElapsedTime": 382,
        "FlightSegment": [
          {
            "DepartureDateTime": "2018-04-11T07:00:00",
            "ArrivalDateTime": "2018-04-11T10:22:00",
            "StopQuantity": 0,
            "FlightNumber": "1399",
            "ResBookDesigCode": "R",
            "ElapsedTime": 382,
            "DepartureAirport": {
              "LocationCode": "JFK",
              "TerminalID": "7"
            },
            "ArrivalAirport": {
              "LocationCode": "LAX",
              "TerminalID": "6"
            },
            "OperatingAirline": {
              "CompanyShortName": "VIRGIN AMERICA",
              "Code": "VX",
              "FlightNumber": "1399"
            },
            "Equipment": [
              {
                "AirEquipType": "320"
              }
            ],
            "MarketingAirline": {
              "Code": "AS"
            },
            "MarriageGrp": "O",
            "DepartureTimeZone": {
              "GMTOffset": -4
            },
            "ArrivalTimeZone": {
              "GMTOffset": -7
            },
            "OnTimePerformance": {
              "Percentage": "82"
            },
            "TPA_Extensions": {
              "eTicket": {
                "Ind": true
              },
              "Mileage": {
                "Amount": 2475
              }
            }
          }
        ]
      },
      {
        "ElapsedTime": 574,
        "FlightSegment": [
          {
            "DepartureDateTime": "2018-04-18T17:25:00",
            "ArrivalDateTime": "2018-04-18T18:33:00",
            "StopQuantity": 0,
            "FlightNumber": "1480",
            "ResBookDesigCode": "R",
            "ElapsedTime": 68,
            "DepartureAirport": {
              "LocationCode": "LAX",
              "TerminalID": "6"
            },
            "ArrivalAirport": {
              "LocationCode": "LAS",
              "TerminalID": "3"
            },
            "OperatingAirline": {
              "CompanyShortName": "VIRGIN AMERICA",
              "Code": "VX",
              "FlightNumber": "1480"
            },
            "Equipment": [
              {
                "AirEquipType": "321"
              }
            ],
            "MarketingAirline": {
              "Code": "AS"
            },
            "MarriageGrp": "O",
            "DepartureTimeZone": {
              "GMTOffset": -7
            },
            "ArrivalTimeZone": {
              "GMTOffset": -7
            },
            "OnTimePerformance": {
              "Percentage": "91"
            },
            "TPA_Extensions": {
              "eTicket": {
                "Ind": true
              },
              "Mileage": {
                "Amount": 236
              }
            }
          },
          {
            "DepartureDateTime": "2018-04-18T22:00:00",
            "ArrivalDateTime": "2018-04-19T05:59:00",
            "StopQuantity": 0,
            "FlightNumber": "1260",
            "ResBookDesigCode": "R",
            "ElapsedTime": 299,
            "DepartureAirport": {
              "LocationCode": "LAS",
              "TerminalID": "3"
            },
            "ArrivalAirport": {
              "LocationCode": "JFK",
              "TerminalID": "7"
            },
            "OperatingAirline": {
              "CompanyShortName": "VIRGIN AMERICA",
              "Code": "VX",
              "FlightNumber": "1260"
            },
            "Equipment": [
              {
                "AirEquipType": "320"
              }
            ],
            "MarketingAirline": {
              "Code": "AS"
            },
            "MarriageGrp": "O",
            "DepartureTimeZone": {
              "GMTOffset": -7
            },
            "ArrivalTimeZone": {
              "GMTOffset": -4
            },
            "OnTimePerformance": {
              "Percentage": "92"
            },
            "TPA_Extensions": {
              "eTicket": {
                "Ind": true
              },
              "Mileage": {
                "Amount": 2248
              }
            }
          }
        ]
      }
    ]
  }
}
```

#### Air Traveler Avail

##### Class Name

`AirTravelerAvail`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PassengerTypeQuantity` | [`List<Models.PassengerTypeQuantity>`](#passenger-type-quantity) | Optional | - |

##### Example (as JSON)

```json
{
  "PassengerTypeQuantity": null
}
```

#### Company Name

##### Class Name

`CompanyName`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Optional | Identifies a company by the company code. |

##### Example (as JSON)

```json
{
  "Code": null
}
```

#### Days Range

##### Class Name

`DaysRange`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FromDate` | `string` | Optional | This date should be of the form YYYY-MM-DD. |
| `ToDate` | `string` | Optional | This date should be of the form YYYY-MM-DD. |

##### Example (as JSON)

```json
{
  "FromDate": null,
  "ToDate": null
}
```

#### Departure Dates

##### Class Name

`DepartureDates`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DaysRange` | [`List<Models.DaysRange>`](#days-range) | Optional | - |

##### Example (as JSON)

```json
{
  "DaysRange": null
}
```

#### Destination Location

##### Class Name

`DestinationLocation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LocationCode` | `string` | Optional | Location identifying code. Required unless AirportsGroup or AllAirports is specified. Cannot appear with AirportsGroup nor AllAirports. |

##### Example (as JSON)

```json
{
  "LocationCode": null
}
```

#### Intelli Sell Transaction

##### Class Name

`IntelliSellTransaction`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestType` | [`Models.RequestType`](#request-type) | Optional | - |

##### Example (as JSON)

```json
{
  "RequestType": null
}
```

#### Link

##### Class Name

`Link`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rel` | [`Models.Rel?`](#rel) | Optional | Describes relationship between href and current request. |
| `Href` | `string` | Optional | Link to related API request. |

##### Example (as JSON)

```json
{
  "rel": null,
  "href": null
}
```

#### Link 2

##### Class Name

`Link2`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rel` | [`Models.Rel2?`](#rel-2) | Optional | Describes relationship between href and current request. |
| `Href` | `string` | Optional | Link to related API request. |

##### Example (as JSON)

```json
{
  "rel": null,
  "href": null
}
```

#### OAuth Token

OAuth 2 Authorization endpoint response

##### Class Name

`OauthToken`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` |  | Access token |
| `TokenType` | `string` |  | Type of access token |
| `ExpiresIn` | `long?` | Optional | Time in seconds before the access token expires |
| `Scope` | `string` | Optional | List of scopes granted<br>This is a space-delimited list of strings. |
| `Expiry` | `long?` | Optional | Time of token expiry as unix timestamp (UTC) |

##### Example (as JSON)

```json
{
  "access_token": "access_token8",
  "token_type": "token_type2",
  "expires_in": null,
  "scope": null,
  "expiry": null
}
```

#### Origin Destination Information

##### Class Name

`OriginDestinationInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RPH` | `string` | Optional | A placeholder for OriginDestinationInformation to be referenced wihin the OTA_AirLowFareSearchRS message. PricedItineraryType carries the reference to this RPH. |
| `DepartureDates` | [`Models.DepartureDates`](#departure-dates) | Optional | - |
| `OriginLocation` | [`Models.OriginLocation`](#origin-location) | Optional | - |
| `DestinationLocation` | [`Models.DestinationLocation`](#destination-location) | Optional | - |
| `TPAExtensions` | [`Models.TPAExtensions3`](#tpa-extensions-3) | Optional | - |

##### Example (as JSON)

```json
{
  "RPH": null,
  "DepartureDates": null,
  "OriginLocation": null,
  "DestinationLocation": null,
  "TPA_Extensions": null
}
```

#### Origin Location

##### Class Name

`OriginLocation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LocationCode` | `string` | Optional | Location identifying code. Required unless AirportsGroup or AllAirports is specified. Cannot appear with AirportsGroup nor AllAirports. |

##### Example (as JSON)

```json
{
  "LocationCode": null
}
```

#### OTA Air Low Fare Search RQ

The Low Fare Search Response message contains a number of Priced Itinerary options.
Each includes:
  - A set of available flights matching the client's request.
  - Pricing information including taxes and full fare breakdown for each passenger type.
  - Ticketing information
  - Fare Basis Codes and the information necessary to make a rules entry.
This message contains similar information to a standard airline CRS or GDS Low Fare Search Response message.

##### Class Name

`OTAAirLowFareSearchRQ`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `POS` | [`Models.POS`](#pos) | Optional | - |
| `OriginDestinationInformation` | [`List<Models.OriginDestinationInformation>`](#origin-destination-information) | Optional | - |
| `TravelPreferences` | [`Models.TravelPreferences`](#travel-preferences) | Optional | - |
| `TravelerInfoSummary` | [`Models.TravelerInfoSummary`](#traveler-info-summary) | Optional | - |
| `TPAExtensions` | [`Models.TPAExtensions1`](#tpa-extensions-1) | Optional | - |

##### Example (as JSON)

```json
{
  "POS": null,
  "OriginDestinationInformation": null,
  "TravelPreferences": null,
  "TravelerInfoSummary": null,
  "TPA_Extensions": null
}
```

#### OTA Air Low Fare Search RS

##### Class Name

`OTAAirLowFareSearchRS`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricedItinCount` | `double?` | Optional | - |
| `BrandedOneWayItinCount` | `double?` | Optional | - |
| `SimpleOneWayItinCount` | `double?` | Optional | - |
| `DepartedItinCount` | `double?` | Optional | - |
| `SoldOutItinCount` | `double?` | Optional | - |
| `AvailableItinCount` | `double?` | Optional | - |
| `Version` | `string` | Optional | - |
| `Success` | `object` | Optional | - |
| `Warnings` | [`Models.Warnings`](#warnings) | Optional | - |
| `PricedItineraries` | [`List<Models.PricedItinerary>`](#priced-itinerary) | Optional | - |

##### Example (as JSON)

```json
{
  "PricedItinCount": null,
  "BrandedOneWayItinCount": null,
  "SimpleOneWayItinCount": null,
  "DepartedItinCount": null,
  "SoldOutItinCount": null,
  "AvailableItinCount": null,
  "Version": null,
  "Success": null,
  "Warnings": null,
  "PricedItineraries": null
}
```

#### OTA Air Low Fare Search RS1

##### Class Name

`OTAAirLowFareSearchRS1`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricedItineraries` | [`List<Models.PricedItinerary>`](#priced-itinerary) | Optional | - |

##### Example (as JSON)

```json
{
  "PricedItineraries": null
}
```

#### Page

##### Class Name

`Page`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Size` | `int?` | Optional | - |
| `TotalTags` | `int?` | Optional | - |
| `Offset` | `int?` | Optional | - |

##### Example (as JSON)

```json
{
  "Size": null,
  "TotalTags": null,
  "Offset": null
}
```

#### Passenger Type Quantity

##### Class Name

`PassengerTypeQuantity`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Optional | Specify traveler type code. |
| `Quantity` | `double?` | Optional | Used to define a quantity of an associated element or attribute. |

##### Example (as JSON)

```json
{
  "Code": null,
  "Quantity": null
}
```

#### POS

##### Class Name

`POS`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Source` | [`List<Models.Source>`](#source) | Optional | - |

##### Example (as JSON)

```json
{
  "Source": null
}
```

#### Price Request Information

##### Class Name

`PriceRequestInformation`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TPAExtensions` | `object` | Optional | - |

##### Example (as JSON)

```json
{
  "TPA_Extensions": null
}
```

#### Priced Itinerary

##### Class Name

`PricedItinerary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricedItinerary` | [`Models.PricedItinerary1`](#priced-itinerary-1) | Optional | - |

##### Example (as JSON)

```json
{
  "PricedItinerary": null
}
```

#### Priced Itinerary 1

##### Class Name

`PricedItinerary1`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SequenceNumber` | `int?` | Optional | - |
| `AirItinerary` | [`Models.AirItineraryType`](#air-itinerary-type) | Optional | Please see full specification in json schema and json schema description files - API resources |
| `AirItineraryPricingInfo` | `object` | Optional | Please see full specification in json schema and json schema description files - API resources |
| `TicketingInfo` | [`Models.TicketingInfo`](#ticketing-info) | Optional | Please see full specification in json schema and json schema description files - API resources |
| `TPAExtensions` | [`Models.TPAExtensions`](#tpa-extensions) | Optional | Please see full specification in json schema and json schema description files - API resources |

##### Example (as JSON)

```json
{
  "SequenceNumber": null,
  "AirItinerary": null,
  "AirItineraryPricingInfo": null,
  "TicketingInfo": null,
  "TPA_Extensions": null
}
```

#### Request Type

##### Class Name

`RequestType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Identifier of the type of request. |

##### Example (as JSON)

```json
{
  "Name": null
}
```

#### Requestor ID

##### Class Name

`RequestorID`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ID` | `string` | Optional | - |
| `Type` | `string` | Optional | - |
| `CompanyName` | [`Models.CompanyName`](#company-name) | Optional | - |

##### Example (as JSON)

```json
{
  "ID": null,
  "Type": null,
  "CompanyName": null
}
```

#### Segment Type

##### Class Name

`SegmentType`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Optional | - |

##### Example (as JSON)

```json
{
  "Code": null
}
```

#### Source

##### Class Name

`Source`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PseudoCityCode` | `string` | Optional | An identification code assigned to an office/agency by a reservation system. |
| `RequestorID` | [`Models.RequestorID`](#requestor-id) | Optional | - |

##### Example (as JSON)

```json
{
  "PseudoCityCode": null,
  "RequestorID": null
}
```

#### Ticketing Info

Please see full specification in json schema and json schema description files - API resources

##### Class Name

`TicketingInfo`

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "TicketType": "eTicket",
  "ValidInterline": "Yes"
}
```

#### TPA Extensions

Please see full specification in json schema and json schema description files - API resources

##### Class Name

`TPAExtensions`

##### Fields

|  |
| 

##### Example (as JSON)

```json
{
  "ValidatingCarrier": {
    "Code": "AS"
  }
}
```

#### TPA Extensions 1

##### Class Name

`TPAExtensions1`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IntelliSellTransaction` | [`Models.IntelliSellTransaction`](#intelli-sell-transaction) | Optional | - |

##### Example (as JSON)

```json
{
  "IntelliSellTransaction": null
}
```

#### TPA Extensions 3

##### Class Name

`TPAExtensions3`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SegmentType` | [`Models.SegmentType`](#segment-type) | Optional | - |

##### Example (as JSON)

```json
{
  "SegmentType": null
}
```

#### Travel Preferences

##### Class Name

`TravelPreferences`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TPAExtensions` | `object` | Optional | - |

##### Example (as JSON)

```json
{
  "TPA_Extensions": null
}
```

#### Traveler Info Summary

##### Class Name

`TravelerInfoSummary`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SeatsRequested` | `List<int>` | Optional | - |
| `AirTravelerAvail` | [`List<Models.AirTravelerAvail>`](#air-traveler-avail) | Optional | - |
| `PriceRequestInformation` | [`Models.PriceRequestInformation`](#price-request-information) | Optional | - |

##### Example (as JSON)

```json
{
  "SeatsRequested": null,
  "AirTravelerAvail": null,
  "PriceRequestInformation": null
}
```

#### Warning

##### Class Name

`Warning`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | - |
| `ShortText` | `string` | Optional | - |
| `Code` | `string` | Optional | - |
| `MessageClass` | [`Models.MessageClass?`](#message-class) | Optional | - |

##### Example (as JSON)

```json
{
  "Type": null,
  "ShortText": null,
  "Code": null,
  "MessageClass": null
}
```

#### Warnings

##### Class Name

`Warnings`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Warning` | [`List<Models.Warning>`](#warning) | Optional | - |

##### Example (as JSON)

```json
{
  "Warning": null
}
```

### Enumerations

* [Message Class](#message-class)
* [OAuth Provider Error](#oauth-provider-error)
* [Rel](#rel)
* [Rel 2](#rel-2)

#### Message Class

##### Class Name

`MessageClass`

##### Fields

| Name |
|  --- |
| `D` |
| `E` |
| `I` |
| `W` |

#### OAuth Provider Error

OAuth 2 Authorization error codes

##### Class Name

`OauthProviderError`

##### Fields

| Name | Description |
|  --- | --- |
| `InvalidRequest` | The request is missing a required parameter, includes an unsupported parameter value (other than grant type), repeats a parameter, includes multiple credentials, utilizes more than one mechanism for authenticating the client, or is otherwise malformed. |
| `InvalidClient` | Client authentication failed (e.g., unknown client, no client authentication included, or unsupported authentication method). |
| `InvalidGrant` | The provided authorization grant (e.g., authorization code, resource owner credentials) or refresh token is invalid, expired, revoked, does not match the redirection URI used in the authorization request, or was issued to another client. |
| `UnauthorizedClient` | The authenticated client is not authorized to use this authorization grant type. |
| `UnsupportedGrantType` | The authorization grant type is not supported by the authorization server. |
| `InvalidScope` | The requested scope is invalid, unknown, malformed, or exceeds the scope granted by the resource owner. |

#### Rel

Describes relationship between href and current request.

##### Class Name

`Rel`

##### Fields

| Name |
|  --- |
| `Self` |
| `PrevResults` |
| `NextResults` |
| `LinkTemplate` |
| `TagLookupLinkTemplate` |

##### Example

```
self
```

#### Rel 2

Describes relationship between href and current request.

##### Class Name

`Rel2`

##### Fields

| Name |
|  --- |
| `Self` |
| `LinkTemplate` |

##### Example

```
self
```

### Exceptions

* [OAuth Provider](#oauth-provider)

#### OAuth Provider

OAuth 2 Authorization endpoint exception

##### Class Name

`OauthProviderException`

##### Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Models.OauthProviderError`](#oauth-provider-error) |  | Error code |
| `ErrorDescription` | `string` | Optional | Human-readable text providing additional information on error.<br>Used to assist the client developer in understanding the error that occurred. |
| `ErrorUri` | `string` | Optional | A URI identifying a human-readable web page with information about the error, used to provide the client developer with additional information about the error |

##### Example (as JSON)

```json
{
  "error": "invalid_request",
  "error_description": null,
  "error_uri": null
}
```

